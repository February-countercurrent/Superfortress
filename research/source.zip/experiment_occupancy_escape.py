"""Two fixed escape policies on fresh paired maps; no training."""
import argparse
from datetime import datetime, timezone
import os
from pathlib import Path
import shutil
import sys

import numpy as np

from occupancy_experiment import ROOT, ARMS, SCENES, read, save, digest, run, analyze


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--name', default='occupancy_escape_v1')
    parser.add_argument('--rounds', type=int, default=60)
    parser.add_argument('--seed', type=int, default=307002)
    args = parser.parse_args()
    assert Path(args.name).name == args.name and args.name not in ('.', '..') and args.rounds > 0
    candidate = read(ROOT / 'CURRENT_CANDIDATE.json')
    model = ROOT / candidate['model']
    checks = read(ROOT / 'experiments/occupancy_checks_v1/verification.json')
    assert candidate['agent'] == 'q_guard' and candidate['episodes'] == 1150 and checks['verified']
    assert checks['model_sha256'] == candidate['model_sha256'] == digest(model)
    assert all(digest(ROOT / p) == h for p, h in {**checks['protected_sha256'], **checks['code_sha256']}.items())
    if args.rounds > 2:
        smoke = read(ROOT / 'experiments/occupancy_smoke_v1/review_verification.json')
        assert smoke['verified'] and smoke['matches'] == 8
    output = ROOT / 'experiments' / args.name
    output.mkdir(parents=True, exist_ok=False)
    workspace = output / 'workspace'
    shutil.copytree(ROOT, workspace, ignore=shutil.ignore_patterns('.git', 'experiments', 'release', 'logs', '__pycache__'))
    (workspace / 'logs').mkdir(exist_ok=True)
    locked = {str(p.relative_to(workspace)): digest(p) for p in list(workspace.glob('*.py')) + list((workspace / 'agent_code').rglob('*.py'))}
    protected = {**checks['protected_sha256'], **checks['code_sha256']}
    config = dict(started_at=datetime.now(timezone.utc).isoformat(), pid=os.getpid(), arms=ARMS,
        primary='occupancy_minus_control', training=False, rounds_each_scene=args.rounds,
        total_matches=4 * args.rounds, evaluation_seeds=[args.seed, args.seed + 1], bootstrap_seed=args.seed + 2,
        model_episodes=1150, model_sha256=digest(model), rng_protocol='round_isolated_v1',
        source_sha256=protected, locked_sha256=locked, python=sys.version, numpy=np.__version__)
    save(output / 'config.json', config)
    completed, summary = 0, {}

    def status(phase, **extra):
        save(output / 'status.json', dict(phase=phase, pid=os.getpid(), completed_batches=completed,
            total_batches=4, updated_at=datetime.now(timezone.utc).isoformat(), **extra))

    try:
        for arm in ARMS:
            (output / arm).mkdir()
            shutil.copy2(model, output / arm / 'model.json')
        for i, scene in enumerate(SCENES):
            for arm, agent in ARMS.items():
                status(arm + '_' + scene)
                folder = output / arm
                result = run(workspace, folder, scene, agent, folder / 'model.json', args.rounds, args.seed + i)
                summary[arm + '_' + scene] = result
                print(arm, scene, result, flush=True)
                assert digest(folder / 'model.json') == config['model_sha256']
                assert all(digest(ROOT / p) == h for p, h in protected.items())
                assert all(digest(workspace / p) == h for p, h in locked.items())
                completed += 1
                save(output / 'summary.json', summary)
        result = analyze(output)
        save(output / 'verification.json', dict(verified=True, no_training=True, matches=4 * args.rounds,
            maps_paired=True, traces_checked=True, protected_unchanged=True,
            output_sha256={'comparison.json': digest(output / 'comparison.json'), **result['raw_sha256']}))
        status('complete', needs_review=True)
        print(result['raw_counts'], flush=True)
    except Exception as exc:
        status('failed', error=repr(exc))
        raise


if __name__ == '__main__':
    main()
