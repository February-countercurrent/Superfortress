# Frozen tactical-tree escape diagnosis

Replay all 120 joint-tree holdout games (mixed seed 567102, strong 567103,
60 each, policy seed 42), including wins. These maps become development data.
Checkpoint SHA256: 397045e64700cb64b3413c1145c3ace4bad258e53ed8db2657feaed8d1ce5ed9.
No retraining, submission changes, or promotion in this stage.

Record full public observations, selected actions, learned values, static and
dynamic masks, and post-step events. Bomb ownership in post-step world records
is diagnostic only and must never enter inference. Verify every map hash,
full-match action hash, score, outcome, survival and step count against the
original evaluation. Compute geometry outside the timed policy callback.

Inspect all 18 suicides, especially the last bomb placement and the transition
from a viable escape to no static escape. Distinguish insufficient observation,
moving opponents, failed moves, waiting, route ranking, and unavoidable terminal
states. Alternative actions evaluated on recorded observations are hypotheses,
not proof of rescue. Any proposed change must be frozen before fresh paired
evaluation and preserve the learned checkpoint and previously submitted agent.
