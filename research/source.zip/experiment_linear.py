"""Matched from-scratch tabular and additive linear Q-learning pilot."""
import json
import shutil
import sys
from pathlib import Path
import numpy as np
from agent_code.q_linear.callbacks import BLOCKS
from agent_code.q_linear.features import ACTIONS
import run_fighter_experiment as runner

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'experiments/linear_v1'
ENV = dict(QF_ALPHA='.15', QF_GAMMA='.9', QF_EPSILON='.35', QF_DECAY='.99',
           QF_SHAPING='0', QF_PROGRESS='.8', QF_DEATH_PENALTY='25', QF_SHIELD='1',
           QF_ANTICIPATE='0', QF_ATTACK_FEATURES='0', QF_ESCAPE_RISK='1',
           QF_BOMB_COST='0', QF_BOMB_COST_MODE='off', QF_CONTEST_SCALE='1',
           QL_BOOTSTRAP_DYNAMIC='0', QL_SYMMETRY='0', QL_N_STEP='1')  # Historical controls.


def main():
    OUT.mkdir(parents=True, exist_ok=False)
    workspace = OUT / 'workspace'
    shutil.copytree(ROOT, workspace, ignore=shutil.ignore_patterns(
        '.git', 'experiments', 'release', 'logs', '__pycache__'))
    (workspace / 'logs').mkdir(exist_ok=True)
    runner.ROOT = workspace
    config = dict(training_rounds_each=300, evaluation_rounds=60, training_seed=27001,
        evaluation_seeds=[27002, 27003], environment=ENV, blocks=BLOCKS,
        python=sys.version, numpy=np.__version__,
        initialization='Both zero Q, empty visits, no pretrained prior; final model is a separate reference.',
        limitation='One training seed; feature grouping and normalized linear update are tested together.')
    (OUT / 'config.json').write_text(json.dumps(config, indent=2))
    mixed = ['rule_based_agent', 'coin_collector_agent', 'peaceful_agent']
    results = {}
    def record(label, model, opponents, rounds, seed, agent, train=False):
        (OUT / 'status.json').write_text(json.dumps(dict(phase=label)))
        results[label] = runner.run(OUT, label, model, opponents, rounds, seed, train,
                                    agent, environment=ENV)
        (OUT / 'summary.json').write_text(json.dumps(results, indent=2))
    try:
        for agent, label, version in [('q_linear', 'linear', 5), ('q_fighter', 'table', 4)]:
            model = OUT / f'{label}.json'
            data = dict(version=version, actions=list(ACTIONS), episodes=0, q={}, prior={}, visits={})
            if version == 5:
                data['blocks'] = BLOCKS
            model.write_text(json.dumps(data))
            shutil.copy2(model, OUT / f'{label}_initial.json')
            record(label + '_training', model, mixed, 300, 27001, agent, True)
            for scenario, opponents, seed in [('mixed', mixed, 27002), ('strong', ['rule_based_agent'] * 3, 27003)]:
                record(label + '_' + scenario, model, opponents, 60, seed, agent)
        for scenario, opponents, seed in [('mixed', mixed, 27002), ('strong', ['rule_based_agent'] * 3, 27003)]:
            record('final_' + scenario, workspace / 'agent_code/q_final/model.json', opponents, 60, seed, 'q_final')
        (OUT / 'status.json').write_text(json.dumps(dict(phase='complete')))
    except Exception as exc:
        (OUT / 'status.json').write_text(json.dumps(dict(phase='failed', error=repr(exc))))
        raise


if __name__ == '__main__':
    main()
