"""Per-training-seed paired results; avoid treating repeated maps as independent."""
import json
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'experiments/linear_multiseed_v1'


def main():
    config = json.loads((OUT / 'config.json').read_text())
    summary = json.loads((OUT / 'summary.json').read_text())
    report = {}
    rng = np.random.default_rng(37004)
    for scenario in ['mixed', 'strong']:
        matrices = {metric: [] for metric in ['win', 'score', 'survived']}
        per_seed = []
        for seed in config['training_seeds']:
            folder = OUT / f'seed_{seed}'
            rows = {name: [json.loads(x) for x in (folder / f'{name}_{scenario}.rounds.jsonl').read_text().splitlines()]
                    for name in ['linear', 'table']}
            assert all(len(v) == 100 for v in rows.values())
            maps = [r['map_hash'] for r in rows['linear']]
            assert maps == [r['map_hash'] for r in rows['table']]
            if per_seed:
                assert maps == reference_maps
            reference_maps = maps
            entry = dict(seed=seed)
            for metric in matrices:
                delta = [float(a[metric]) - float(b[metric]) for a, b in zip(rows['linear'], rows['table'])]
                matrices[metric].append(delta)
                entry[metric + '_difference'] = float(np.mean(delta))
            per_seed.append(entry)
        reference = [json.loads(x) for x in (OUT / f'reference/final_{scenario}.rounds.jsonl').read_text().splitlines()]
        assert [r['map_hash'] for r in reference] == reference_maps
        # Resample seed pairs and shared map columns, retaining cross-seed map dependence.
        seed_ix = rng.integers(0, len(per_seed), size=(10000, len(per_seed)))
        map_ix = rng.integers(0, 100, size=(10000, 100))
        differences = {}
        for metric, values in matrices.items():
            a = np.array(values)
            boot = a[seed_ix[:, :, None], map_ix[:, None, :]].mean(axis=(1, 2))
            differences[metric] = dict(mean_difference=float(a.mean()),
                exploratory_two_way_bootstrap_95ci=np.percentile(boot, [2.5, 97.5]).tolist())
        means = {name: {metric: float(np.mean([summary[f'seed_{seed}/{name}_{scenario}'][metric]
                    for seed in config['training_seeds']]))
                    for metric in ['strict_win_rate', 'mean_score', 'survival_rate', 'suicide_rate']}
                 for name in ['linear', 'table']}
        report[scenario] = dict(per_seed=per_seed, differences=differences, means=means,
                               final_reference=summary[f'reference/final_{scenario}'])
    report['limitations'] = 'Only three training seeds. Two-way bootstrap is exploratory; no automatic promotion or best-seed selection.'
    (OUT / 'analysis.json').write_text(json.dumps(report, indent=2))
    print(json.dumps(report, indent=2), flush=True)


if __name__ == '__main__':
    main()
