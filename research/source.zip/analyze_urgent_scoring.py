"""Descriptive score and opportunity audit of the accepted urgent policy."""
from collections import Counter, defaultdict
import gzip
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace
import numpy as np
import settings
from agent_code.q_urgent import callbacks as cb
from agent_code.q_urgent.features import ACTIONS, DELTAS, blast, distance_map
from agent_code.q_tactical.tactics import timeline, endpoints
from diagnose_symavg_survival import stable_rows

ROOT = Path(__file__).resolve().parent
OUT = ROOT/'experiments/urgent_scoring_v1'
NAME = 'q_urgent'


def category(row):
    return ('alive_' if row['survived'] else 'dead_') + ('win' if row['win'] else 'tie' if row['tie_for_first'] else 'loss')


def round_frames(path):
    batch = []; number = None
    with gzip.open(path,'rt',encoding='utf-8') as handle:
        for line in handle:
            frame = json.loads(line)
            if number is not None and frame['round'] != number:
                yield number,batch
                batch = []
            number = frame['round']; batch.append(frame)
    if batch:
        yield number,batch


def state_arrays(frame):
    s = frame['state']
    return {**s,'field':np.array(s['field']),'explosion_map':np.array(s['explosion_map']),
            'bombs':[(tuple(p),t) for p,t in s['bombs']],
            'self':(*s['self'][:3],tuple(s['self'][3])),
            'others':[(*o[:3],tuple(o[3])) for o in s['others']],
            'coins':[tuple(p) for p in s['coins']]}


def attack_geometry(state):
    """Optimistic enemy routes; descriptive geometry, not kill probability."""
    ray = set(blast(state['field'],state['self'][3]))
    targets = [o for o in state['others'] if tuple(o[3]) in ray]
    horizon = max([settings.BOMB_TIMER+settings.EXPLOSION_TIMER,int(state['explosion_map'].max())]
                  + [t+settings.EXPLOSION_TIMER for _,t in state['bombs']])
    base = timeline(state,False,horizon); planted = timeline(state,True,horizon)
    result = []
    for target in targets:
        before = int(endpoints(target[3],base).sum())
        after = int(endpoints(target[3],planted).sum())
        result.append(dict(name=target[0],before=before,after=after,new_trap=before>0 and after==0))
    return result


def inspect(scene):
    folder = OUT/scene
    matches = stable_rows(folder/'match.rounds.jsonl')
    reference = stable_rows(ROOT/f'experiments/urgent_escape_v1/urgent_{scene}.rounds.jsonl')
    assert len(matches) == len(reference) == 60 and matches == reference
    by_round = {r['round']:r for r in matches}
    categories = Counter(category(r) for r in matches)
    aggregate = defaultdict(Counter); gaps = Counter(); rounds = []; examples = defaultdict(list)
    data = json.loads((OUT/'model.json').read_text())
    policy = SimpleNamespace(q={tuple(map(int,k.split(','))):np.array(v) for k,v in data['q'].items()})
    checked = 0
    for number,frames in round_frames(folder/'score_frames.jsonl.gz'):
        row = by_round[number]; group = category(row); own = row['agents'][NAME]
        # The first highest-scoring opponent in framework order is fixed for
        # decomposition. Tied leaders may have different coin/kill mixtures.
        opponent_name = max((n for n in row['agents'] if n != NAME),key=lambda n:row['agents'][n]['score'])
        leader = row['agents'][opponent_name]
        leaders = [n for n,a in row['agents'].items() if n != NAME and a['score'] == leader['score']]
        if group == 'alive_loss':
            gaps.update(dict(rounds=1,score_gap=leader['score']-own['score'],
                coin_gap=leader.get('coins',0)-own.get('coins',0),kill_gap=leader.get('kills',0)-own.get('kills',0),
                leader_more_coins=int(leader.get('coins',0)>own.get('coins',0)),
                leader_more_kills=int(leader.get('kills',0)>own.get('kills',0)),
                own_zero_kills=int(own.get('kills',0)==0),tied_opponent_leaders=int(len(leaders)>1)))
        # Check actual urgent-policy scores, including the corrected states.
        for f in frames:
            if f.get('urgent_escape_corrected') or (f['step']-1)%100 == 0:
                mask,scores,corrected = cb.scored_actions(policy,state_arrays(f))
                np.testing.assert_array_equal(mask,f['candidate_mask'])
                np.testing.assert_allclose(scores,f['adjusted_q'],rtol=0,atol=1e-12)
                assert corrected == f.get('urgent_escape_corrected',False)
                chosen = ACTIONS.index(f['chosen'])
                assert mask[chosen] and np.isclose(scores[chosen],scores[mask].max())
                checked += 1
        if not row['survived']:
            continue
        c = Counter(); bombs = []; latest_bomb = None; last_gain = 0; last_coin = 0; last_kill = 0
        for index,f in enumerate(frames):
            s = f['state']; info = f['info']; action = ACTIONS.index(f['chosen'])
            calm = not info['threatened']; late = f['step']>200
            mask = np.array(f['candidate_mask'],dtype=bool)
            coins_gained = f['events'].count('COIN_COLLECTED'); kills_gained = f['events'].count('KILLED_OPPONENT')
            gain = coins_gained*settings.REWARD_COIN+kills_gained*settings.REWARD_KILL
            c['steps'] += 1; c['action_'+f['chosen']] += 1
            c['coins'] += coins_gained; c['kills'] += kills_gained; c['score'] += gain
            if gain: last_gain = f['step']
            if coins_gained: last_coin = f['step']
            if kills_gained: last_kill = f['step']
            if late:
                c['late_steps'] += 1; c['late_coins'] += coins_gained; c['late_kills'] += kills_gained; c['late_score'] += gain
                c['late_threatened'] += int(not calm)
                c['late_no_coins_no_crates'] += int(not s['coins'] and f['crates_remaining']==0)
                c['late_coins_visible'] += int(bool(s['coins']))
                c['late_crates_remaining'] += int(f['crates_remaining']>0)
            if index>=2 and s['self'][3]==frames[index-2]['state']['self'][3] and s['self'][3]!=frames[index-1]['state']['self'][3]:
                c['two_step_returns'] += 1
                c['late_two_step_returns'] += int(late)
                c['calm_two_step_returns'] += int(calm and not frames[index-1]['info']['threatened'])
            if calm and mask[5] and info['enemy_hits']>0:
                c['calm_safe_ray_attack_opportunities'] += 1
                c['calm_safe_ray_bombs_chosen'] += int(action==5)
            if calm and mask[5] and info['yield']>0:
                c['calm_safe_productive_bomb_opportunities'] += 1
                c['productive_bombs_chosen'] += int(action==5)
                if info['target']==2:
                    c['crate_target_bomb_opportunities'] += 1
                    c['crate_target_bombs_chosen'] += int(action==5)
            if 'BOMB_DROPPED' in f['events']:
                latest_bomb = dict(step=f['step'],late=late,ray_attack=info['enemy_hits']>0,
                    crate_yield=info['yield'],kills=0,detonated=None)
                if latest_bomb['ray_attack']:
                    geometry = attack_geometry(state_arrays(f))
                    latest_bomb['all_targets_have_escape'] = bool(geometry) and all(t['after']>0 for t in geometry)
                    latest_bomb['new_trap'] = any(t['new_trap'] for t in geometry)
                bombs.append(latest_bomb)
            if latest_bomb is not None:
                latest_bomb['kills'] += kills_gained
                if 'BOMB_EXPLODED' in f['events']:
                    latest_bomb['detonated'] = f['step']
            if not calm or not s['coins']:
                continue
            state = state_arrays(f); field = state['field']; pos = state['self'][3]
            free = field==0
            for p,_ in state['bombs']: free[p] = False
            for o in state['others']: free[o[3]] = False
            free[pos] = True
            distances = distance_map(free,state['coins']); distance = int(distances[pos])
            if distance<=0: continue
            c['calm_reachable_coin_steps'] += 1
            toward = np.zeros(6,dtype=bool)
            for j,(dx,dy) in enumerate(DELTAS):
                p = pos[0]+dx,pos[1]+dy
                toward[j] = free[p] and 0<=distances[p]<distance
            permitted = mask & toward
            if not permitted.any():
                c['calm_coin_no_permitted_approach'] += 1
                continue
            c['safe_coin_approach_opportunities'] += 1
            c['coin_approach_chosen'] += int(permitted[action])
            c['near_coin_approach_opportunities'] += int(distance<=2)
            c['near_coin_approach_chosen'] += int(distance<=2 and permitted[action])
            if permitted[action]: continue
            c['coin_approach_skipped'] += 1
            c['coin_skip_target_'+str(info['target'])] += 1
            c['coin_skip_action_'+f['chosen']] += 1
            c['coin_skip_productive_bomb'] += int(action==5 and (info['yield']>0 or info['enemy_hits']>0))
            if len(examples[group])<8:
                q = np.array(f['adjusted_q'])
                examples[group].append(dict(round=number,step=f['step'],position=list(pos),distance=distance,
                    target=info['target'],action=f['chosen'],permitted_toward=[ACTIONS[j] for j in np.flatnonzero(permitted)],
                    chosen_score=float(q[action]),best_coin_score=float(q[permitted].max()),
                    enemy_hits=info['enemy_hits'],crate_yield=info['yield']))
        assert c['coins']==own.get('coins',0) and c['kills']==own.get('kills',0) and c['score']==own['score']
        assert len(bombs)==own.get('bombs',0)
        assert sum(b['kills'] for b in bombs)==own.get('kills',0)
        for b in bombs:
            # A final bomb with unobserved dangerous flame ticks is censored.
            resolved = b['detonated'] is not None and b['detonated']+settings.EXPLOSION_TIMER-1<=frames[-1]['step']
            c['bombs'] += 1; c['late_bombs'] += int(b['late'])
            c['resolved_bombs'] += int(resolved)
            if not b['ray_attack']: continue
            c['ray_attack_bombs'] += 1
            c['ray_attack_all_targets_have_escape'] += int(b['all_targets_have_escape'])
            c['ray_attack_new_trap'] += int(b['new_trap'])
            if not resolved: continue
            c['resolved_ray_bombs'] += 1
            c['resolved_ray_bombs_with_kill'] += int(b['kills']>0)
            c['resolved_ray_bomb_kills'] += b['kills']
            c['late_resolved_ray_bombs'] += int(b['late'])
            c['late_resolved_ray_bombs_with_kill'] += int(b['late'] and b['kills']>0)
        c['rounds'] = 1
        c['rounds_no_score_after_200'] = int(c['late_steps']>0 and c['late_score']==0)
        c['rounds_no_coin_after_200'] = int(c['late_steps']>0 and c['late_coins']==0)
        c['rounds_no_kill_after_200'] = int(c['late_steps']>0 and c['late_kills']==0)
        aggregate[group].update(c)
        rounds.append(dict(round=number,category=group,own_score=own['score'],leader=opponent_name,
            leader_score=leader['score'],score_gap=leader['score']-own['score'],own_coins=own.get('coins',0),
            leader_coins=leader.get('coins',0),own_kills=own.get('kills',0),leader_kills=leader.get('kills',0),
            end_step=row['steps'],last_score_step=last_gain,last_coin_step=last_coin,last_kill_step=last_kill,
            final_scoreless_steps=frames[-1]['step']-last_gain,
            final_visible_coins=frames[-1]['visible_coins'],final_crates=frames[-1]['crates_remaining'],
            counters=dict(c)))
    result = dict(scene=scene,rounds=60,replay_exact_except_timing=True,policy_frames_verified=checked,
        categories=dict(categories),alive_loss_gap=dict(gaps),survivor_groups={g:dict(c) for g,c in aggregate.items()},
        survivor_rounds=rounds,coin_examples=dict(examples),
        limitations='Outcome-conditioned descriptive groups, not causal comparisons. Per-step observations are correlated. '
        'Coin opportunities use current snapshot distances and the deployed mask, not guaranteed future collection. '
        'Enemy escape searches ignore player occupancy and future new bombs; escape existence is not a predicted policy. '
        'Bomb kills refer to the last own bomb, verified against round totals for surviving agents; end-censored bombs excluded from conversion ratios. '
        'Score gap decomposition uses the first highest-scoring opponent in framework order if leaders tie.')
    (folder/'scoring_analysis.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    return result


def main():
    assert json.loads((OUT/'status.json').read_text())['phase'] in ('replay_complete','complete')
    results = {s:inspect(s) for s in ('mixed','strong')}
    totals = Counter(); gaps = Counter(); groups = defaultdict(Counter)
    for r in results.values():
        totals.update(r['categories']); gaps.update(r['alive_loss_gap'])
        for g,c in r['survivor_groups'].items(): groups[g].update(c)
    manifest = json.loads((ROOT/'CURRENT_CANDIDATE.json').read_text())
    assert manifest['agent']=='q_urgent'
    assert all(hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h for p,h in manifest['code_sha256'].items())
    report = dict(rounds=120,categories=dict(totals),alive_loss_gap=dict(gaps),
        survivor_groups={g:dict(c) for g,c in groups.items()},
        scenes={s:dict(categories=r['categories'],alive_loss_gap=r['alive_loss_gap']) for s,r in results.items()},
        policy_frames_verified=sum(r['policy_frames_verified'] for r in results.values()),limitations=results['mixed']['limitations'])
    (OUT/'analysis.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    (OUT/'status.json').write_text(json.dumps(dict(phase='complete',completed_scenes=2,total_scenes=2)))
    print(json.dumps(report,indent=2))


if __name__=='__main__':
    main()
