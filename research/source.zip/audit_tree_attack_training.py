"""Count existing training support; do not infer bomb outcomes from step rewards."""
from collections import defaultdict
from pathlib import Path
import numpy as np
from experiment_tree_fqi_batches import save
from finalize_guard_release import digest

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'experiments/tree_attack_diagnosis_v1'


def main():
    groups=defaultdict(list);hashes={}
    folder=ROOT/'experiments/tree_teacher_v1/data'
    for p in sorted(folder.glob('round_*.npz')):
        hashes[p.name]=digest(p)
        with np.load(p,allow_pickle=False) as archive:
            d={n:archive[n].copy() for n in ('round','tactical_x','a','mask')}
        episode=int(d['round'][0])
        source='teacher_mixed' if 201<=episode<=300 else 'random_strong' if episode>300 else 'random_mixed'
        split='diagnostic' if episode%5==0 else 'training'
        groups[(source,split)].append(d)
    result={}
    for (source,split),episodes in groups.items():
        x=np.concatenate([d['tactical_x'] for d in episodes]);a=np.concatenate([d['a'] for d in episodes])
        mask=np.concatenate([d['mask'] for d in episodes]);ray=x[:,14]>0
        bombs=a==5;opportunity=ray&mask[:,5]&(x[:,5]==2)
        result[source+'_'+split]=dict(episodes=len(episodes),transitions=len(a),bombs=int(bombs.sum()),
            ray_enemy_states=int(ray.sum()),safe_ray_bomb_opportunities=int(opportunity.sum()),
            bomb_with_ray_enemy=int((bombs&ray).sum()),
            attack_only_bombs=int((bombs&ray&(x[:,11]==0)).sum()),
            by_enemy_exit={str(n):dict(states=int((opportunity&(x[:,16]==n)).sum()),
                bombs=int((bombs&ray&(x[:,16]==n)).sum()),
                unique_bomb_keys=len(np.unique(x[bombs&ray&(x[:,16]==n)],axis=0))) for n in (0,1,2)})
    save(OUT/'training_support.json',dict(groups=result,data_sha256=hashes,
        note='Original data only; immediate reward does not identify later bomb kill credit. Counts do not prove sufficiency.'))
    print(result)


if __name__=='__main__': main()
