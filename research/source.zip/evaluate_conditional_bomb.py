"""Frozen-weight inference ablation; selection precedes fresh-map evaluation."""
import hashlib
import json
from pathlib import Path
import shutil
from run_fighter_experiment import run

ROOT = Path(__file__).parent
OUT = ROOT / 'experiments/conditional_bomb_v1'
VARIANTS = {'full': 'full', 'off': 'off', 'late_behind': 'late_behind'}


def main():
    OUT.mkdir(exist_ok=False)
    source = ROOT / 'experiments/gamma_fresh_v1/gamma_09/model.json'
    model = OUT / 'model.json'
    shutil.copy2(source, model)
    digest = hashlib.sha256(model.read_bytes()).hexdigest()
    shutil.copytree(ROOT / 'agent_code/q_fighter', OUT / 'source',
                    ignore=shutil.ignore_patterns('logs', '__pycache__', '*.json'))
    config = {'training': False, 'model_source': str(source), 'model_sha256': digest,
              'variants': VARIANTS, 'validation_seed': 115001, 'holdout_seed': 115002,
              'rounds_per_evaluation': 60,
              'selection': 'Highest validation mean score, then strict win rate; ties retain full rules.'}
    (OUT / 'config.json').write_text(json.dumps(config, indent=2))
    results = {}
    def evaluate(label, variant, seed):
        mode = VARIANTS[variant]
        results[label] = run(OUT, label, model, ['rule_based_agent'] * 3, 60, seed,
            environment={'QF_ESCAPE_RISK': '1', 'QF_ANTICIPATE': '0', 'QF_SHIELD': '1',
                         'QF_BOMB_COST': '1', 'QF_CONTEST_SCALE': '1', 'QF_ATTACK_FEATURES': '0', 'QF_BOMB_COST_MODE': mode})
        (OUT / 'summary.json').write_text(json.dumps(results, indent=2))
    for variant in VARIANTS:
        evaluate('validation_' + variant, variant, 115001)
    winner = max(VARIANTS, key=lambda v: (results['validation_' + v]['mean_score'],
                                         results['validation_' + v]['strict_win_rate']))
    (OUT / 'selection.json').write_text(json.dumps({'selected': winner}, indent=2))
    evaluate('holdout_full', 'full', 115002)
    if winner != 'full':
        evaluate('holdout_selected', winner, 115002)
    assert hashlib.sha256(model.read_bytes()).hexdigest() == digest
    (OUT / 'status.json').write_text(json.dumps({'phase': 'complete', 'selected': winner}))


if __name__ == '__main__':
    main()
