"""Matched-map evaluation of the frozen Q table with/without escape costs."""
import json
from pathlib import Path
import shutil
from run_fighter_experiment import run

root = Path(__file__).parent
output = root / 'experiments/escape_v1'
output.mkdir(exist_ok=False)
model = output / 'model.json'
shutil.copy2(root / 'agent_code/q_fighter/model.json', model)
shutil.copytree(root / 'agent_code/q_fighter', output / 'source', ignore=shutil.ignore_patterns('__pycache__', '*.json'))
results = {}
for label, opponents, rounds, seed in [('development', ['rule_based_agent'] * 3, 30, 8802),
                                      ('fresh', ['rule_based_agent'] * 3, 60, 9917),
                                      ('duel', ['rule_based_agent'], 30, 9918)]:
    for variant in ('baseline', 'escape'):
        name = label + '_' + variant
        results[name] = run(output, name, model, opponents, rounds, seed,
            environment={'QF_ESCAPE_RISK': str(int(variant == 'escape')), 'QF_ANTICIPATE': '0', 'QF_SHIELD': '1'})
        (output / 'summary.json').write_text(json.dumps(results, indent=2))
