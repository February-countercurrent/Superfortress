"""Fixed checkpoints: accepted policy, full residual, and tie-only residual."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys

import numpy as np

from experiment_direction_residual import verify_model
import run_fighter_experiment as runner

ROOT = Path(__file__).resolve().parent
ARMS = {'frozen': 'q_urgent', 'full': 'q_direction', 'tie': 'q_direction_tie'}
SCENES = {'mixed': ['rule_based_agent', 'coin_collector_agent', 'peaceful_agent'],
          'strong': ['rule_based_agent'] * 3}
METRICS = ('win', 'score', 'survived', 'suicides', 'coins', 'kills', 'crates', 'move_collisions')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, data):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(data, indent=2), encoding='utf-8')
    temp.replace(path)


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def analyze(output, rounds, seed):
    summary = read(output / 'summary.json')
    records = {}; measurements = {}; comparisons = {}; row_hashes = {}
    for arm, agent in ARMS.items():
        measurements[arm] = {}
        for scene in SCENES:
            path = output / f'{arm}_{scene}.rounds.jsonl'
            rows = [json.loads(line) for line in path.read_text().splitlines()]
            assert len(rows) == rounds and [r['round'] for r in rows] == list(range(1, rounds + 1))
            records[arm, scene] = rows
            row_hashes[path.name] = digest(path)
            assert [r['map_hash'] for r in rows] == [r['map_hash'] for r in records['frozen', scene]]
            assert len({r['map_hash'] for r in rows}) == rounds
            for row in rows:
                own = row['agents'][agent]
                opponents = [v['score'] for k, v in row['agents'].items() if k != agent]
                assert row['score'] == own['score'] == own.get('coins', 0) + 5 * own.get('kills', 0)
                assert row['win'] == (row['score'] > max(opponents))
                assert row['tie_for_first'] == (row['score'] == max(opponents))
                assert row['survived'] == own['survived']
            measurements[arm][scene] = {m: float(np.mean([
                row[m] if m in ('win', 'score', 'survived') else row['agents'][agent].get(m, 0)
                for row in rows])) for m in METRICS}
            measured = measurements[arm][scene]
            for field, metric in {'strict_win_rate': 'win', 'mean_score': 'score', 'survival_rate': 'survived',
                                  'suicide_rate': 'suicides', 'mean_coins': 'coins', 'mean_kills': 'kills',
                                  'mean_crates': 'crates', 'mean_move_collisions': 'move_collisions'}.items():
                assert np.isclose(summary[f'{arm}_{scene}'][field], measured[metric])
        measurements[arm]['combined'] = {m: float(np.mean([measurements[arm][s][m] for s in SCENES])) for m in METRICS}
    rng = np.random.default_rng(seed + 2)
    for reference in ('frozen', 'full'):
        by_scene = {}; boot = {}
        for scene in SCENES:
            indices = rng.integers(0, rounds, (10000, rounds))
            by_scene[scene] = {}
            for metric in METRICS:
                def value(row, arm):
                    return float(row[metric] if metric in ('win', 'score', 'survived') else row['agents'][ARMS[arm]].get(metric, 0))
                difference = np.array([value(b, 'tie') - value(a, reference)
                                       for a, b in zip(records[reference, scene], records['tie', scene])])
                boot[scene, metric] = difference[indices].mean(axis=1)
                by_scene[scene][metric] = dict(difference=float(difference.mean()),
                    paired_map_95ci=np.percentile(boot[scene, metric], [2.5, 97.5]).tolist())
        by_scene['combined'] = {m: dict(difference=float(np.mean([by_scene[s][m]['difference'] for s in SCENES])),
            paired_map_95ci=np.percentile(sum(boot[s, m] for s in SCENES) / 2, [2.5, 97.5]).tolist()) for m in METRICS}
        comparisons['tie_minus_' + reference] = by_scene
    report = dict(measurements=measurements, comparisons=comparisons, raw_rows_sha256=row_hashes,
                  limitation='One fixed residual learned with the earlier full-residual behavior, no retraining. Fresh matched maps within scenes; trajectories diverge. Exploratory bootstrap intervals, no correction for multiple experiments. No automatic adoption or further evaluation.')
    save(output / 'comparison.json', report)
    lines = ['# Direction tie-only evaluation', '',
             '| Arm | Mixed win | Strong win | Combined win | Mean score | Suicide | Survival |',
             '|---|---:|---:|---:|---:|---:|---:|']
    for arm, metrics in measurements.items():
        c = metrics['combined']
        lines.append(f"| {arm} | {metrics['mixed']['win']:.1%} | {metrics['strong']['win']:.1%} | {c['win']:.1%} | {c['score']:.3f} | {c['suicides']:.1%} | {c['survived']:.1%} |")
    (output / 'RESULTS.md').write_text('\n'.join(lines + ['', report['limitation']]) + '\n', encoding='utf-8')
    return report


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--name', default='direction_tie_v1')
    parser.add_argument('--rounds', type=int, default=60)
    parser.add_argument('--seed', type=int, default=217002)
    args = parser.parse_args()
    assert Path(args.name).name == args.name and args.name not in ('.', '..') and args.rounds > 0
    manifest = read(ROOT / 'CURRENT_CANDIDATE.json')
    assert manifest['agent'] == 'q_urgent' and manifest['episodes'] == 1150
    source = ROOT / manifest['model']
    trained = ROOT / 'experiments/direction_residual_v1/direction/model.json'
    assert digest(source) == manifest['model_sha256']
    assert all(digest(ROOT / p) == h for p, h in manifest['code_sha256'].items())
    previous = read(ROOT / 'experiments/direction_residual_v1/config.json')
    assert all(digest(ROOT / p) == h for p, h in previous['locked_sha256'].items() if p.startswith('agent_code'))
    assert digest(trained) == read(ROOT / 'experiments/direction_residual_v1/verification.json')['model_sha256']['direction']
    verify_model(trained, read(source), 'direction', 1300)
    checks = read(ROOT / 'experiments/direction_tie_checks_v1/verification.json')
    assert checks['verified'] and checks['checkpoint_sha256'] == digest(trained)
    assert digest(ROOT / 'agent_code/q_direction_tie/model.json') == digest(trained)
    output = ROOT / 'experiments' / args.name
    output.mkdir(parents=True, exist_ok=False)
    workspace = output / 'workspace'
    shutil.copytree(ROOT, workspace, ignore=shutil.ignore_patterns('.git', 'experiments', 'release', 'logs', '__pycache__'))
    (workspace / 'logs').mkdir(exist_ok=True)
    runner.ROOT = workspace
    models = {'frozen': output / 'frozen_model.json', 'full': output / 'residual_model.json', 'tie': output / 'residual_model.json'}
    shutil.copy2(source, models['frozen']); shutil.copy2(trained, models['full'])
    files = list(workspace.glob('*.py')) + list((workspace / 'agent_code').rglob('*.py'))
    locked = {str(p.relative_to(output)): digest(p) for p in files}
    locked.update({p.name: digest(p) for p in set(models.values())})
    source_hashes = {str(p.relative_to(ROOT)): digest(p) for p in (source, trained, ROOT / 'CURRENT_CANDIDATE.json')}
    config = dict(started_at=datetime.now(timezone.utc).isoformat(), rounds_each=args.rounds,
                  total_matches=6 * args.rounds, training=False, evaluation_seeds=[args.seed, args.seed + 1],
                  arms=ARMS, source_hashes=source_hashes, locked_sha256=locked,
                  python=sys.version, numpy=np.__version__, environment={'BM_TRACK_COLLISIONS': '1'},
                  design='Keep the accepted seven-block policy and urgent correction. Only calm attack states whose accepted greedy set consists entirely of at least two moves can use residual-only ranking within that set. Unique choices and any tie involving WAIT/BOMB remain unchanged. Both residual arms share the fixed final 1300-episode checkpoint; no checkpoint or threshold search.',
                  primary_metric='Equal-scene strict win rate; report score, suicide, survival, coins, kills and collisions.',
                  checks=checks)
    save(output / 'config.json', config)
    save(output / 'process.json', dict(pid=os.getpid(), started_at=config['started_at']))
    summary = {}; completed = 0
    def status(phase, **more):
        save(output / 'status.json', dict(phase=phase, pid=os.getpid(), updated_at=datetime.now(timezone.utc).isoformat(),
                                         completed_batches=completed, total_batches=6, **more))
    try:
        for i, (scene, opponents) in enumerate(SCENES.items()):
            for arm, agent in ARMS.items():
                label = arm + '_' + scene
                status(label)
                summary[label] = runner.run(output, label, models[arm], opponents, args.rounds,
                                            args.seed + i, agent=agent, environment=config['environment'])
                assert all(digest(ROOT / p) == h for p, h in source_hashes.items())
                assert all(digest(output / p) == h for p, h in locked.items())
                completed += 1
                save(output / 'summary.json', summary)
        status('analyzing')
        analyze(output, args.rounds, args.seed)
        save(output / 'verification.json', dict(verified=True, matches=6 * args.rounds,
            maps_paired=True, raw_summaries_checked=True, snapshot_and_models_unchanged=True,
            accepted_candidate_unchanged=True, model_sha256={a: digest(p) for a, p in models.items()}))
        status('complete', needs_review=True)
    except Exception as exc:
        status('failed', error=repr(exc))
        raise


if __name__ == '__main__':
    main()
