"""Reproducible descriptive classification of every frozen-tree suicide."""
import gzip
import json
from pathlib import Path
import numpy as np
from agent_code.tree_escape.escape_wait import retreat_options
from agent_code.tree_escape.features import describe
from experiment_tree_fqi import read
from experiment_tree_fqi_batches import save

ROOT=Path(__file__).resolve().parent
DIAG=ROOT/'experiments/tree_escape_diagnosis_v1'
OUT=ROOT/'experiments/tree_escape_v1'


def main():
    summaries={};cases=[]
    for scene in ('mixed','strong'):
        with gzip.open(DIAG/'replay'/scene/'trace.jsonl.gz','rt',encoding='utf-8') as f:
            rr=[json.loads(x) for x in f]
        by_round={};triggers=set()
        for r in rr:
            s=r['state'];s['field']=np.asarray(s['field']);s['explosion_map']=np.asarray(s['explosion_map'])
            s['self']=(*s['self'][:3],tuple(s['self'][3]))
            s['others']=[(*o[:3],tuple(o[3])) for o in s['others']]
            s['bombs']=[(tuple(p),t) for p,t in s['bombs']]
            s['coins']=[tuple(p) for p in s['coins']]
            info=dict(threatened=r['threatened'],safe=np.array(r['safe']))
            options,_=retreat_options(s,info,np.array(r['mask']),np.array(r['q']))
            if options: triggers.add((r['round'],r['step']))
            by_round.setdefault(r['round'],[]).append(r)
        summaries[scene]=dict(actions=len(rr),potential_interventions=len(triggers),
            games_with_potential_interventions=len({r for r,s in triggers}))
        outcomes=read(DIAG/'replay'/scene/'analysis.json')
        for death in outcomes['deaths']:
            assert death['suicide']
            round_id,end=death['round'],death['step']
            history=by_round[round_id]
            window=[r for r in history if end-5<=r['step']<=end]
            active=[r for r in window if (round_id,r['step']) in triggers]
            blocked=[r['step'] for r in window if r['action']<4 and 'INVALID_ACTION' in r['after']['events']]
            fallback_wait=[r['step'] for r in active if r['fallback']]
            unsafe=[r for r in window if not any(r['safe'])]
            first=unsafe[0] if unsafe else None
            # Descriptive geometry check, not a real counterfactual opponent policy.
            restored=None
            if first is not None:
                predicted={**first['state'],'others':[]}
                restored=bool(describe(predicted)['safe'].any())
            category=('wait_during_dynamic_fallback' if fallback_wait else
                      'earlier_wait_then_failed_move' if active and blocked else
                      'wait_before_loss_of_escape' if active else
                      'failed_move_without_recent_guard_trigger' if blocked else
                      'route_blocked_without_recent_guard_trigger')
            cases.append(dict(scene=scene,round=round_id,death_step=end,
                last_own_bomb=death['last_bomb_step'],category=category,
                guard_trigger_steps=[r['step'] for r in active],failed_move_steps=blocked,
                first_no_static_escape=first['step'] if first else None,
                forecast_has_escape_if_opponents_removed=restored))
    counts={label:sum(c['category']==label for c in cases) for label in sorted({c['category'] for c in cases})}
    result=dict(summary=summaries,categories=counts,cases=cases,
        note='Observed last six decisions; overlapping mechanisms are simplified by category precedence. Removing opponents only tests the forecast geometry, not a playable intervention or guaranteed rescue.')
    save(OUT/'diagnostic_details.json',result)
    print(json.dumps(dict(summary=summaries,categories=counts,opponents_removed_restores_escape=
        sum(c['forecast_has_escape_if_opponents_removed'] is True for c in cases)),indent=2))


if __name__=='__main__':main()
