"""Observation-only replay instrumentation for frozen q_switch policies."""
import argparse
from collections import deque
import contextlib
import hashlib
import gzip
import json
from pathlib import Path
import pickle
import sys

import numpy as np

from agent_code.q_fighter.features import ACTIONS, describe, prior_key
from agent_code.q_fighter.callbacks import values_for


def encode(value):
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    raise TypeError(type(value).__name__)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--rounds', type=int, default=60)
    parser.add_argument('--seed', type=int, default=9901)
    parser.add_argument('--model', type=Path, default=Path(__file__).parent / 'agent_code/q_fighter/model.json')
    parser.add_argument('--score-details', action='store_true')
    parser.add_argument('--agent', choices=['q_switch'], default='q_switch')
    parser.add_argument('--opponents', nargs='+', default=['rule_based_agent'] * 3)
    args = parser.parse_args()
    if args.agent == 'q_switch':
        from agent_code.q_switch.features import describe, prior_key
        from agent_code.q_switch.base import averaged_values as values_for
    elif args.agent == 'q_urgent':
        from agent_code.q_urgent.features import describe, prior_key
        from agent_code.q_urgent.callbacks import averaged_values as values_for
    elif args.agent == 'q_symavg':
        from agent_code.q_symavg.features import describe, prior_key
        from agent_code.q_symavg.callbacks import averaged_values as values_for
    elif args.agent in ('q_linear', 'q_dynamic'):
        from agent_code.q_linear.features import describe, prior_key
        from agent_code.q_linear.callbacks import values_for
    elif args.agent == 'q_final':
        from agent_code.q_final.features import describe, prior_key
        def values_for(policy, key):
            return policy.q.get(key, policy.prior.get(prior_key(key), np.zeros(6)))
    else:
        from agent_code.q_fighter.features import describe, prior_key
        from agent_code.q_fighter.callbacks import values_for
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    model = args.model.resolve()
    frozen = output / 'model.json'
    frozen.write_bytes(model.read_bytes())
    (output / 'manifest.json').write_text(json.dumps({
        'seed': args.seed, 'rounds': args.rounds,
        'model_sha256': hashlib.sha256(model.read_bytes()).hexdigest(),
        'training': False, 'agent': args.agent, 'opponents': args.opponents,
    }, indent=2))
    from environment import BombeRLeWorld as World
    originals = {name: getattr(World, name) for name in (
        'new_round', 'poll_and_run_agents', 'perform_agent_action',
        'update_bombs', 'evaluate_explosions', 'do_step', 'end_round')}
    steps = (output / 'decisions.jsonl').open('w', encoding='utf-8')
    full = gzip.open(output / 'score_frames.jsonl.gz', 'wt', encoding='utf-8') if args.score_details else None

    def new_round(world):
        originals['new_round'](world)
        world.diag_ring = deque(maxlen=12)
        world.diag_bombs = {}
        world.diag_explosions = {}
        world.diag_frame = None

    def poll(world):
        agent = world.agents[0]
        world.diag_frame = None
        if not agent.dead:
            state = world.get_state_for_agent(agent)
            world.diag_frame = {'round': world.round, 'step': world.step,
                                'state': state, 'actions': [], 'lethal': []}
        originals['poll_and_run_agents'](world)
        if world.diag_frame is not None:
            policy = agent.backend.runner.fake_self
            info = describe(state, getattr(policy, 'anticipate', False), getattr(policy, 'attack_features', False))
            key = info['key']
            world.diag_frame.update({
                'info': info, 'chosen': agent.last_action,
                'q': values_for(policy, key).copy(),
                'q_source': 'symmetry_average' if args.agent in ('q_symavg', 'q_urgent', 'q_switch') else 'linear_blocks' if args.agent in ('q_linear', 'q_dynamic') else 'learned' if key in policy.q else (
                    'prior' if prior_key(key) in policy.prior else 'zero'),
                'visits': getattr(policy, 'visits', {}).get(key, np.zeros(6, dtype=int)),
            })
            from agent_code.q_linear.features import allowed
            mask = allowed(info, True)
            world.diag_frame['base_mask'] = mask.copy()
            if args.agent in ('q_dynamic', 'q_symavg', 'q_urgent', 'q_switch'):
                from agent_code.q_dynamic.dynamic import candidate_mask
                mask = candidate_mask(state, info, mask)
            world.diag_frame['candidate_mask'] = mask
            if args.score_details:
                from agent_code.q_fighter.escape import escape_costs, effective_bomb_cost
                values = values_for(policy, key).copy()
                if args.agent in ('q_linear', 'q_dynamic', 'q_symavg', 'q_urgent', 'q_switch'):
                    costs = escape_costs(state, info, 0., 1.)
                elif args.agent == 'q_final':
                    costs = escape_costs(state, info, policy.policy['bomb_cost'], 1.)
                else:
                    cost = effective_bomb_cost(state, policy.bomb_cost, policy.bomb_cost_mode, policy.highest_seen_score)
                    costs = escape_costs(state, info, cost, policy.contest_scale) if policy.escape_risk and policy.shield else np.zeros(6)
                adjusted = values - costs
                if args.agent in ('q_urgent', 'q_switch'):
                    from agent_code.q_switch.base import scored_actions
                    actual_mask, adjusted, corrected = scored_actions(policy, state)
                    assert np.array_equal(actual_mask, mask)
                    costs = values - adjusted
                    world.diag_frame['urgent_escape_corrected'] = corrected
                world.diag_frame.update({'adjusted_q': adjusted, 'costs': costs,
                    'visible_coins': len(state['coins']), 'crates_remaining': int((state['field'] == 1).sum())})
                if args.agent == 'q_symavg':
                    from agent_code.q_symavg.callbacks import values_for as original_values
                    world.diag_frame['unaveraged_q'] = original_values(policy, key).copy()

    def perform(world, agent, action):
        before = (agent.x, agent.y)
        count = len(agent.events)
        originals['perform_agent_action'](world, agent, action)
        for bomb in world.bombs:
            if bomb not in world.diag_bombs:
                world.diag_bombs[bomb] = {'owner': bomb.owner.name,
                    'position': (bomb.x, bomb.y), 'placed': world.step}
        if world.diag_frame is not None:
            world.diag_frame['actions'].append({'agent': agent.name,
                'action': action, 'before': before, 'after': (agent.x, agent.y),
                'events': list(agent.events[count:])})

    def bombs(world):
        detonating = [b for b in world.bombs if b.timer <= 0]
        count = len(world.explosions)
        originals['update_bombs'](world)
        for explosion, bomb in zip(world.explosions[count:], detonating):
            world.diag_explosions[explosion] = world.diag_bombs[bomb]

    def explosions(world):
        agent = world.agents[0]
        if world.diag_frame is not None:
            world.diag_frame['lethal'] = [world.diag_explosions[exp]
                for exp in world.explosions if exp.is_dangerous()
                and (agent.x, agent.y) in exp.blast_coords]
        originals['evaluate_explosions'](world)

    def step(world, user_input='WAIT'):
        originals['do_step'](world, user_input)
        frame = world.diag_frame
        if frame is None:
            return
        agent = world.agents[0]
        frame.update({'dead': agent.dead, 'events': list(agent.events),
                      'after_position': (agent.x, agent.y)})
        if not agent.dead:
            post = world.get_state_for_agent(agent)
            frame['post_safe'] = describe(post)['safe']
        world.diag_ring.append(frame)
        compact = {k: v for k, v in frame.items() if k != 'state'}
        steps.write(json.dumps(compact, default=encode) + '\n')
        if full is not None:
            full.write(json.dumps(frame, default=encode) + '\n')
        if agent.dead:
            (output / f'death_{world.round:03d}.json').write_text(
                json.dumps(list(world.diag_ring), default=encode), encoding='utf-8')

    def end(world):
        originals['end_round'](world)
        with (output / f'replay_{world.round:03d}.pt').open('wb') as handle:
            pickle.dump({**world.replay, 'n_steps': world.step}, handle)

    for name, method in [('new_round', new_round), ('poll_and_run_agents', poll),
                         ('perform_agent_action', perform), ('update_bombs', bombs),
                         ('evaluate_explosions', explosions), ('do_step', step), ('end_round', end)]:
        setattr(World, name, method)
    import run_fighter_match
    sys.argv = ['run_fighter_match.py', '--agent', args.agent, '--model', str(frozen), '--output', str(output / 'match.json'),
                '--rounds', str(args.rounds), '--seed', str(args.seed),
                '--opponents', *args.opponents]
    with (output / 'run.log').open('w') as log, contextlib.redirect_stdout(log), contextlib.redirect_stderr(log):
        run_fighter_match.main()
    steps.close()
    if full is not None:
        full.close()


if __name__ == '__main__':
    main()
