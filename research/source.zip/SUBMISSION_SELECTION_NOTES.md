# 固定提交候选的独立地图确认

根据 opponent_pool_v1 同地图开发排序，多步900领先，但胜率优势仍不确定。用户目标是提交尽可能高胜率版本，本轮停止训练，在新地图上直接比较四个预先指定的固定模型：

| 标签 | 模型 |
|---|---|
| multistep | experiments/multistep_v1/multistep/model.json，900 局 |
| symmetry | experiments/symmetry_v1/symmetry/model.json，750 局 |
| small_rate | experiments/small_rate_v1/checkpoints/step_300.json，600 局 |
| final | agent_code/q_final/model.json，旧提交版 |

执行 `python evaluate_submission_selection.py`。混合与强对手各 200 张新地图（127002/127003），四版本共 1600 局。权重及推理代码哈希锁定，每批结束验证；q_final 从隔离工作区的自身目录加载，验证其权重与登记副本一致。评估无训练。

预定工程选择标准：两个场景等权平均严格独占第一胜率，平局优先强对手胜率，再看平均得分。该比例不代表官方对手分布。分别报告多步候选对三种参考的配对地图 bootstrap 差异区间，同时观察得分、金币、击杀、炸箱、生存、自杀和平均延迟。

此处独立指地图未用于之前训练和候选筛选。若根据本轮四选一，最高观测值仍有选择偏差；区间只包含地图抽样不确定性，不含重新训练方差，多重比较未校正。不同版本历史训练预算不同，本轮用于选择固定提交模型，不是隔离所有设计因素的算法因果比较。

进度 `experiments/submission_selection_v1/status.json`，8 个批次，`phase=complete` 才表示全部完成。各批逐局文件与日志可查看进行中的数量。最终 `summary.json`、`analysis.json`、`RESULTS.md`。预计 30–40 分钟。不覆盖现有提交包。
