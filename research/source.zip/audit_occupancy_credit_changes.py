"""Track the same opponents' alternate fates across exact paired replays."""
from collections import Counter, defaultdict
from analyze_occupancy_losses import OUT, frames_by_round
from occupancy_experiment import ARMS, SCENES, read, save


def main():
    assert read(OUT / 'review_verification.json')['verified']
    rounds = {}
    for arm, agent in ARMS.items():
        for scene in SCENES:
            for n, frames in frames_by_round(OUT / arm / scene / 'frames.jsonl.gz'):
                by_victim = defaultdict(list)
                for f in frames:
                    for h in f['hits']:
                        by_victim[h['victim']].append(dict(step=f['step'], **h))
                rounds[arm, scene, n] = dict(hits=by_victim, after=frames[-1]['after'])
    summary, changes = Counter(), []
    for scene in SCENES:
        for number in range(1, 61):
            a, b = rounds['control', scene, number], rounds['occupancy', scene, number]
            opponents = set(a['after']) - {'q_guard'}
            assert opponents == set(b['after']) - {'q_guard_occ'}
            for victim in sorted(opponents):
                old = [h for h in a['hits'][victim] if h['owner'] == 'q_guard']
                new = [h for h in b['hits'][victim] if h['owner'] == 'q_guard_occ']
                assert len(old) <= 1 and len(new) <= 1
                if bool(old) == bool(new):
                    continue
                lost = bool(old)
                opposite = b if lost else a
                hits = opposite['hits'][victim]
                if not opposite['after'][victim]['dead']:
                    assert not hits
                    fate = 'survived'
                elif any(h['suicide'] for h in hits) and any(not h['suicide'] for h in hits):
                    fate = 'self_and_other_credit'
                elif any(h['suicide'] for h in hits):
                    fate = 'selfkill_only'
                else:
                    assert hits
                    fate = 'other_enemy_credit'
                direction = 'lost' if lost else 'gained'
                summary[direction] += 1
                summary[direction + '_' + fate] += 1
                changes.append(dict(scene=scene, round=number, victim=victim, direction=direction,
                    other_trajectory_fate=fate, original_credits=a['hits'][victim], candidate_credits=b['hits'][victim]))
    assert summary['lost'] - summary['gained'] == 19
    result = dict(verified=True, summary=dict(summary), changes=changes,
        limitation='Same opponent identity, different trajectories. Alternate death credit is not proof of a stolen kill or an isolated positional cause.')
    save(OUT / 'victim_credit_changes.json', result)
    print(dict(summary))


if __name__ == '__main__':
    main()
