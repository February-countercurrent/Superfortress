"""Independent same-data reference, declared before screening results were viewed."""
from pathlib import Path
import numpy as np
from experiment_tree_tactical import OUT,ROOT,run
from experiment_tree_fqi import read,rows,summarize
from experiment_tree_fqi_batches import save
from finalize_guard_release import digest


def main():
    assert read(OUT/'status.json')['phase']=='complete'
    plan=read(OUT/'same_data_predeclaration.json')
    assert all(digest(ROOT/n)==h for n,h in plan['source_sha256'].items())
    selected=read(OUT/'selection.json')['selected']
    frozen=digest(OUT/'selection.json');decision=digest(OUT/'decision.json')
    assert not (OUT/'same_data_comparison.json').exists()
    timings=[]
    if selected!='control':
        for scene in ('mixed','strong'):
            print('Same-data control:',scene,flush=True)
            timings.append(run('control','holdout',scene,60))
    data={a:{s:rows(OUT/'holdout'/a/(s+'.rounds.jsonl')) for s in ('mixed','strong')}
          for a in (selected,'control')}
    for scene in ('mixed','strong'):
        c,r=data[selected][scene],data['control'][scene]
        assert len(c)==len(r)==60
        assert [x['map_hash'] for x in c]==[x['map_hash'] for x in r]
    result={a:summarize(sum(scenes.values(),[]),'tree_fqi') for a,scenes in data.items()}
    rng=np.random.default_rng(567902);comparisons={}
    for metric in ('win','score'):
        ds=[np.array([float(c[metric])-float(r[metric]) for c,r in zip(data[selected][s],data['control'][s])])
            for s in ('mixed','strong')]
        boot=np.mean([d[rng.integers(0,60,(10000,60))].mean(axis=1) for d in ds],axis=0)
        comparisons[metric]=dict(difference=float(np.mean(ds)),paired_95ci=np.quantile(boot,[.025,.975]).tolist())
    assert digest(OUT/'selection.json')==frozen and digest(OUT/'decision.json')==decision
    save(OUT/'same_data_comparison.json',dict(selected=selected,results=result,
        candidate_minus_control=comparisons,timings=timings,paired=True,
        original_selection_and_decision_unchanged=True,bootstrap_seed=567902,
        predeclaration_sha256=digest(OUT/'same_data_predeclaration.json')))
    lines=['# 独立同数据对照','','| 模型 | 胜场/120 | 胜率 | 均分 | 自杀 |',
           '|---|---:|---:|---:|---:|']
    for a,c in result.items():
        lines.append(f"| {a} | {c['totals']['win']} | {c['win_rate']:.1%} | {c['mean_score']:.3f} | {c['totals']['suicides']} |")
    w=comparisons['win'];s=comparisons['score']
    lines+=['',f"候选减原结构同数据对照：胜率差{w['difference']*100:+.2f}个百分点，配对95%区间"
        f"[{w['paired_95ci'][0]*100:+.2f},{w['paired_95ci'][1]*100:+.2f}]；均分差{s['difference']:+.3f}，"
        f"区间[{s['paired_95ci'][0]:+.3f},{s['paired_95ci'][1]:+.3f}]。",'',
        '候选选择、主要比较和晋级判断保持不变。本项在查看筛选胜率之前声明，使用冻结的模型和新地图。'
        '它检验组合变化，不能分离特征、容量、动作分组和奖励各自的贡献。','']
    (OUT/'SAME_DATA_RESULTS.md').write_text('\n'.join(lines),encoding='utf-8')
    print({a:(c['totals']['win'],c['mean_score']) for a,c in result.items()},flush=True)


if __name__=='__main__':main()
