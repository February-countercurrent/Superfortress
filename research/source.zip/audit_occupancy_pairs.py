"""Verify that each paired trajectory first diverges at the intended filter."""
from collections import Counter, defaultdict
import json

from occupancy_experiment import ROOT, SCENES, read, save, rows


def main():
    folder = ROOT / 'experiments/occupancy_escape_v1'
    assert read(folder / 'review_verification.json')['verified']
    counts, records = Counter(), []
    for scene in SCENES:
        grouped = {}
        for arm in ('control', 'occupancy'):
            grouped[arm] = defaultdict(list)
            for r in rows(folder / arm / (scene + '.trace.jsonl')):
                grouped[arm][r['round']].append(r)
        control = rows(folder / 'control' / (scene + '.rounds.jsonl'))
        candidate = rows(folder / 'occupancy' / (scene + '.rounds.jsonl'))
        for a, b in zip(control, candidate):
            n = a['round']
            first = None
            before, after = grouped['control'][n], grouped['occupancy'][n]
            for f, g in zip(before, after):
                filtered = {k: v for k, v in g.items() if k not in ('occupancy', 'bomb_available')}
                if f['action'] == g['action']:
                    assert f == filtered
                    counts['identical_prefix_steps'] += 1
                    continue
                assert {k: v for k, v in f.items() if k not in ('action', 'changed')} == \
                       {k: v for k, v in filtered.items() if k not in ('action', 'changed')}
                assert g['occupancy']['eligible'] and g['occupancy']['changed']
                assert f['action'] == g['baseline_action']
                assert not g['occupancy']['candidate_mask'][('UP', 'RIGHT', 'DOWN', 'LEFT', 'WAIT', 'BOMB').index(f['action'])]
                first = dict(step=f['step'], position=f['position'], before=f['action'], after=g['action'])
                break
            if first is None:
                assert len(before) == len(after) and a['action_sha256'] == b['action_sha256']
                counts['unchanged_pairs'] += 1
            else:
                assert a['action_sha256'] != b['action_sha256']
                counts['changed_pairs'] += 1
            own_a, own_b = a['agents']['q_guard'], b['agents']['q_guard_occ']
            transition = ('win' if a['win'] else 'tie' if a['tie_for_first'] else 'loss') + '_to_' + \
                         ('win' if b['win'] else 'tie' if b['tie_for_first'] else 'loss')
            selfdeath = str(int(own_a.get('suicides', 0))) + '_to_' + str(int(own_b.get('suicides', 0)))
            counts['suicide_' + selfdeath] += 1
            records.append(dict(scene=scene, round=n, first_divergence=first,
                outcome_transition=transition, score_before=a['score'], score_after=b['score'],
                suicide_transition=selfdeath, survived_before=a['survived'], survived_after=b['survived']))
    result = dict(verified=True, counts=dict(counts), rounds=records,
        limitation='First divergence isolates the tested change; later outcome differences include opponent responses and random trajectory divergence, not a guaranteed saved-game count.')
    save(folder / 'paired_divergence_audit.json', result)
    print(json.dumps(result['counts'], indent=2))


if __name__ == '__main__':
    main()
