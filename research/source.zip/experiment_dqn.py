"""Small, isolated, from-scratch Double DQN pilot with paired evaluation maps."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import torch
import numpy as np
from agent_code.dqn_agent.network import QNetwork
from agent_code.dqn_agent.train import CONFIG
import run_fighter_experiment as runner

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'experiments/dqn_v1'


def main():
    OUT.mkdir(parents=True, exist_ok=False)
    workspace = OUT / 'workspace'
    shutil.copytree(ROOT, workspace, ignore=shutil.ignore_patterns(
        '.git', 'experiments', 'release', 'logs', '__pycache__'))
    (workspace / 'logs').mkdir(exist_ok=True)
    runner.ROOT = workspace
    torch.set_num_threads(1)
    torch.manual_seed(26001)
    net = QNetwork()
    initial = OUT / 'initial.pt'
    model = OUT / 'model.pt'
    torch.save(dict(version=1, network=net.state_dict(), episodes=0, steps=0,
                    updates=0, config=CONFIG, seed=26001), initial)
    shutil.copy2(initial, model)
    config = dict(training=CONFIG, training_rounds=300, training_seed=26001,
        evaluation_rounds=60, evaluation_seeds=[26002, 26003], python=sys.version,
        torch=torch.__version__, numpy=np.__version__, parameters=sum(p.numel() for p in net.parameters()),
        initial_sha256=hashlib.sha256(initial.read_bytes()).hexdigest(),
        note='One from-scratch seed; Q-final has a larger prior training budget. Pilot, not a convergence or architecture-only comparison.')
    (OUT / 'config.json').write_text(json.dumps(config, indent=2))
    mixed = ['rule_based_agent', 'coin_collector_agent', 'peaceful_agent']
    strong = ['rule_based_agent'] * 3
    results = {}
    def record(label, checkpoint, opponents, rounds, seed, train=False, agent='dqn_agent'):
        (OUT / 'status.json').write_text(json.dumps(dict(phase=label)))
        results[label] = runner.run(OUT, label, checkpoint, opponents, rounds, seed, train, agent,
            environment={'OMP_NUM_THREADS': '1', 'MKL_NUM_THREADS': '1', 'OPENBLAS_NUM_THREADS': '1'})
        (OUT / 'summary.json').write_text(json.dumps(results, indent=2))
    try:
        record('training', model, mixed, 300, 26001, True)
        for name, opponents, seed in [('mixed', mixed, 26002), ('strong', strong, 26003)]:
            record('trained_' + name, model, opponents, 60, seed)
            record('initial_' + name, initial, opponents, 60, seed)
            record('q_final_' + name, workspace / 'agent_code/q_final/model.json', opponents, 60, seed, agent='q_final')
        (OUT / 'status.json').write_text(json.dumps(dict(phase='complete')))
    except Exception as exc:
        (OUT / 'status.json').write_text(json.dumps(dict(phase='failed', error=repr(exc))))
        raise


if __name__ == '__main__':
    main()
