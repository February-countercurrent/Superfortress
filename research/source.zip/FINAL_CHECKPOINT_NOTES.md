# Deadline checkpoint selection (frozen before evaluation)

Keep the adopted q_guard policy (16 features, 7 blocks, D4, dynamic escape,
urgent correction, resource guards E), with submission-local model and fixed
tie seed42. No additional training or new heuristic. Do not merge weights.

Exactly three weights: adopted1150, learning_alignment_v1/average1250, and
learning_alignment_replication_v1/average1250. Earlier results did NOT establish
that either1250 model improves the adopted weights. This is a limited last
check under the current guarded deployment policy, not a new learning method.

Screen: each model30 mixed +30 three-rule games, map seeds327002/327003.
Rank by combined strict wins, then score; exact ties favor adopted1150, then A.
A candidate advances only with at least3 more wins out of60 and nonnegative
total score difference. Otherwise retain1150 and run a final120-game estimate.

If advanced, freeze that ONE candidate before opening independent seeds337002/
337003 (60 games per scene for baseline and candidate). Recommend replacement
only if paired stratified bootstrap95% lower bound of win difference is >0,
mean score is not lower, and neither scenario has a negative win difference.
No retry with the other checkpoint after a failed holdout. Otherwise retain1150.
Screen and holdout are reported separately, never pool selection with validation.

Both phases use fixed agent seed42; map/opponent streams remain round_isolated_v1.
Report score, wins, survival, suicides, kills, latency and map pairing. The
historical53.9% used map-specific agent seeds and is not an exact estimate of
the newly packaged fixed-seed artifact. Keep old ZIP and adopted source intact.

Budget: stop starting optional work90 minutes after experiment start; retain
the already built and verified adopted release on failure or incomplete checks.
No uploads, automatic training, architecture changes, or further parameter search.
