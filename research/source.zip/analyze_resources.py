"""Resource opportunity diagnostics from unchanged recorded policy trajectories."""
from collections import Counter
import gzip
import json
from pathlib import Path
import numpy as np
from agent_code.q_linear.features import ACTIONS, DELTAS, distance_map

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'experiments/resource_diagnosis_v1'


def rows(path):
    data = [json.loads(x) for x in path.read_text().splitlines()]
    for row in data:
        for agent in row['agents'].values():
            agent.pop('time', None)
    return data


def inspect(folder, reference, agent):
    matches = rows(folder / 'match.rounds.jsonl')
    assert len(matches) == 40 and matches == rows(reference)[:40], 'Replay diverged'
    counts = Counter()
    examples = []
    crate_examples = []
    by_round = {}
    with gzip.open(folder / 'score_frames.jsonl.gz', 'rt') as handle:
        for line in handle:
            frame = json.loads(line)
            by_round.setdefault(frame['round'], []).append(frame)
    for frames in by_round.values():
        for i, f in enumerate(frames):
            s = f['state']
            pos = tuple(s['self'][3])
            action = ACTIONS.index(f['chosen'])
            counts['observed_steps'] += 1
            counts['wait_steps'] += action == 4
            counts['bomb_steps'] += action == 5
            counts['threatened_steps'] += bool(f['info']['threatened'])
            crates = int(f['crates_remaining'])
            resource_phase = bool(crates or s['coins'])
            counts['resource_remaining_steps'] += resource_phase
            counts['calm_resource_remaining_steps'] += resource_phase and not f['info']['threatened']
            if i and tuple(f['after_position']) == tuple(frames[i-1]['state']['self'][3]) and tuple(f['after_position']) != pos:
                counts['immediate_return_moves'] += 1
                counts['returns_resources_remaining'] += resource_phase
                counts['returns_calm_resources_remaining'] += resource_phase and not f['info']['threatened']
                counts[f'returns_target_{f["info"]["target"]}'] += 1
                counts['returns_no_visible_coins_with_crates'] += bool(crates and not s['coins'])
            if not f['info']['threatened'] and f['candidate_mask'][5] and f['info']['yield'] > 0:
                counts['calm_safe_productive_bomb_opportunities'] += 1
                counts['productive_bomb_chosen'] += action == 5
                counts[f'productive_bomb_opportunity_target_{f["info"]["target"]}'] += 1
                if int(f['info']['target']) == 2:
                    counts['crate_target_productive_opportunities'] += 1
                    counts['crate_target_productive_bomb_chosen'] += action == 5
                    if action != 5:
                        counts['crate_target_skip_bomb_strict_q_preference'] += f['adjusted_q'][action] > f['adjusted_q'][5] + 1e-8
                        if len(crate_examples) < 6:
                            crate_examples.append(dict(round=f['round'], step=f['step'], position=pos,
                                action=f['chosen'], crate_yield=f['info']['yield'], key=f['info']['key'],
                                raw_q=f['q'], costs=f['costs'], adjusted_q=f['adjusted_q'],
                                candidate_mask=f['candidate_mask']))
            if 'COIN_FOUND' in f['events']:
                counts['coin_found_steps'] += 1
                future = frames[i+1:i+9]
                counts['coin_found_then_any_coin_collected_within_8_steps'] += any('COIN_COLLECTED' in x['events'] for x in future)
            if not s['coins']:
                continue
            counts['visible_coin_steps'] += 1
            field = np.array(s['field'])
            free = field == 0
            for p, _ in s['bombs']:
                free[tuple(p)] = False
            for other in s['others']:
                free[tuple(other[3])] = False
            free[pos] = True
            distances = distance_map(free, s['coins'])
            distance = int(distances[pos])
            if distance <= 0:
                continue
            counts['reachable_coin_steps'] += 1
            toward = np.zeros(6, dtype=bool)
            for j, (dx, dy) in enumerate(DELTAS):
                p = pos[0]+dx, pos[1]+dy
                toward[j] = free[p] and 0 <= distances[p] < distance
            base = toward & np.array(f['base_mask'])
            permitted = toward & np.array(f['candidate_mask'])
            if f['info']['threatened']:
                continue
            counts['calm_reachable_coin_steps'] += 1
            counts['calm_coin_moves_all_removed_by_dynamic'] += bool(base.any() and not permitted.any())
            if not permitted.any():
                continue
            counts['calm_safe_coin_opportunities'] += 1
            target = int(f['info']['target'])
            counts[f'opportunity_target_{target}'] += 1
            approach = bool(permitted[action])
            counts['opportunity_chosen_toward_coin'] += approach
            if approach:
                continue
            counts['opportunity_not_chosen_toward_coin'] += 1
            counts[f'not_toward_action_{f["chosen"]}'] += 1
            counts[f'not_toward_target_{target}'] += 1
            values = np.array(f['adjusted_q'])
            counts['not_toward_strictly_higher_adjusted_q'] += values[action] > values[permitted].max() + 1e-8
            if len(examples) < 8:
                examples.append(dict(round=f['round'], step=f['step'], position=pos, coin_distance=distance,
                    target=target, action=f['chosen'], coins=s['coins'], safe_coin_actions=[ACTIONS[j] for j in np.flatnonzero(permitted)],
                    chosen_q=float(values[action]), best_coin_q=float(values[permitted].max())))
    totals = {k: sum(r['agents'][agent].get(k, 0) for r in matches) for k in ['coins', 'crates', 'kills', 'suicides', 'bombs']}
    return dict(replay_verified=True, rounds=40, totals=totals,
        mean_score=float(np.mean([r['score'] for r in matches])), win_rate=float(np.mean([r['win'] for r in matches])),
        counts={k: int(v) for k, v in counts.items()}, examples=examples, crate_examples=crate_examples,
        fraction_approaching_when_calm_safe_coin_available=counts['opportunity_chosen_toward_coin']/max(1, counts['calm_safe_coin_opportunities']))


def main():
    result = {}
    result['final'] = inspect(OUT / 'final', ROOT / 'experiments/dynamic_holdout_v1/reference/q_final_mixed.rounds.jsonl', 'q_final')
    for seed in [27001, 28001, 29001]:
        result[f'seed_{seed}'] = inspect(OUT / f'seed_{seed}', ROOT / f'experiments/dynamic_holdout_v1/seed_{seed}/q_dynamic_mixed.rounds.jsonl', 'q_dynamic')
    result['limitations'] = ('40 preselected maps, differing policy trajectories; step counts are correlated and not causal effects. '
        'Coin approach means reducing current snapshot shortest-path distance, not guaranteed collection. '
        'Coin-found follow-up tracks any coin and can be censored by death/end; it is not attribution of a specific revealed coin. '
        'These prior holdout maps now serve as diagnostic development data.')
    (OUT / 'analysis.json').write_text(json.dumps(result, indent=2))
    lines = ['# 资源获取诊断', '', '四组各重放混合场景前 40 局，除动作计时外与原始测试逐局一致。', '',
        '| 模型 | 平均金币 | 平均箱子 | 平均击杀 | 平静且可安全接近金币的步数 | 其中选择接近金币 |',
        '|---|---:|---:|---:|---:|---:|']
    for name, r in result.items():
        if name == 'limitations':
            continue
        lines.append(f"| {name} | {r['totals']['coins']/40:.2f} | {r['totals']['crates']/40:.2f} | {r['totals']['kills']/40:.2f} | {r['counts'].get('calm_safe_coin_opportunities',0)} | {r['fraction_approaching_when_calm_safe_coin_available']:.1%} |")
    lines += ['', '“平静”指当前不在已知炸弹爆炸射线或火焰内；“可接近”指当前可行走快照中，至少一个候选动作能缩短到可见金币的最短距离。不是无风险或必得金币的保证。',
        '不同策略进入的局面不同，步数和比例仅用于定位行为，不可把它们直接当作同状态因果对照。详细目标类别、动作、Q 值例子及计数见 analysis.json。',
        '金币被发现后八步内收集的指标不追踪特定金币，且死亡/终局会截断观察；不能据此单独认定“自己炸出的金币被抢”。']
    (OUT / 'RESULTS.md').write_text('\n'.join(lines)+'\n', encoding='utf-8')
    print(json.dumps({k: v.get('totals') for k, v in result.items() if isinstance(v, dict)}), flush=True)


if __name__ == '__main__':
    main()
