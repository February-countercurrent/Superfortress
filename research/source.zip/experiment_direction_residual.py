"""Frozen base, bearing-blind residual, and directional residual pilot."""
import argparse
import csv
from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys

import numpy as np
from migrate_direction import migrate
from agent_code.q_direction.callbacks import frozen_base_digest
import run_fighter_experiment as runner
import experiment_attack_reward as comparison

ROOT=Path(__file__).resolve().parent
AGENT='q_direction'
ARMS=('frozen','blind','direction')
SCENES={'mixed':['rule_based_agent','coin_collector_agent','peaceful_agent'],
        'strong':['rule_based_agent']*3}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path,content):
    temporary=path.with_suffix('.tmp')
    temporary.write_text(json.dumps(content,indent=2),encoding='utf-8')
    temporary.replace(path)


def verify_model(path,base,mode,episodes):
    model=json.loads(path.read_text())
    assert model['version']==8 and model['episodes']==episodes and model['direction_mode']==mode
    legacy={k:v for k,v in model['q'].items() if int(k.split(',')[0])<7}
    assert legacy==base['q'], 'Legacy weights must remain exactly frozen'
    q={tuple(map(int,k.split(','))):np.array(v) for k,v in model['q'].items()}
    assert frozen_base_digest(q)==model['frozen_base_sha256']
    assert all(np.isfinite(v).all() for v in q.values())
    assert all(np.all(v[4:]==0) for k,v in q.items() if k[0]==7)
    assert all(len(k.split(','))==16 for k in model['visits'])
    return model


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--name',default='direction_residual_v1')
    parser.add_argument('--train-rounds',type=int,default=150)
    parser.add_argument('--eval-rounds',type=int,default=60)
    parser.add_argument('--seed',type=int,default=207001)
    args=parser.parse_args()
    assert Path(args.name).name==args.name and args.name not in ('.','..')
    assert args.train_rounds>0 and args.eval_rounds>0
    manifest=json.loads((ROOT/'CURRENT_CANDIDATE.json').read_text())
    assert manifest['agent']=='q_urgent'
    source=ROOT/manifest['model']; source_hash=digest(source)
    assert source_hash==manifest['model_sha256']
    assert all(digest(ROOT/p)==h for p,h in manifest['code_sha256'].items())
    base=json.loads(source.read_text()); assert base['episodes']==1150
    assert json.loads((ROOT/'experiments/direction_checks_v1/verification.json').read_text())['verified']
    output=ROOT/'experiments'/args.name
    output.mkdir(parents=True,exist_ok=False)
    workspace=output/'workspace'
    shutil.copytree(ROOT,workspace,ignore=shutil.ignore_patterns('.git','experiments','release','logs','__pycache__'))
    (workspace/'logs').mkdir(exist_ok=True); runner.ROOT=workspace
    files=list((workspace/'agent_code/q_direction').glob('*.py'))
    files += [workspace/n for n in ('run_fighter_match.py','run_fighter_experiment.py',
        'experiment_direction_residual.py','experiment_attack_reward.py','migrate_direction.py','environment.py','settings.py')]
    locked={str(p.relative_to(workspace)):digest(p) for p in files}
    env={**json.loads((ROOT/'experiments/target_learning_curve_v1/config.json').read_text())['environment'],
         'QF_EPSILON':'.05','QL_SNAPSHOT_DIR':'','BM_TRACK_COLLISIONS':'1'}
    config=dict(source=str(source),source_sha256=source_hash,initial_episodes=1150,arms=list(ARMS),
        train_rounds_each=args.train_rounds,evaluation_rounds_each=args.eval_rounds,
        training_seed=args.seed,evaluation_seeds=[args.seed+1,args.seed+2],environment=env,
        locked_sha256=locked,python=sys.version,numpy=np.__version__,
        started_at=datetime.now(timezone.utc).isoformat(),
        feature='Four dominant-axis enemy sectors: nearest Manhattan distance 1-2, 3-5, or >=6; diagonal ties belong to both sectors, absent=0.',
        residual='One block (5,13,16,17,18,19), active only in calm target=3 states and only for movement actions. Seven original blocks frozen. Original event and shaping rewards.',
        control='Blind residual uses the same gate, training, seed, inherited 16-feature visit schedule and update budget, but zeroes the four new bearings before learning and inference.',
        design='Fixed final checkpoint. Both training arms start with identical base predictions and zero residual. Train 150 episodes by default; evaluate both scenes on matched new maps. No automatic promotion or follow-on training.',
        limitations='One continuation seed and small evaluation sets. Direction versus blind also changes state partition and sharing. Frozen weights do not guarantee unchanged future trajectories or safety outcomes.')
    save(output/'config.json',config)
    save(output/'process.json',dict(pid=os.getpid(),started_at=config['started_at']))
    results={}; verified={}
    def status(phase,**more):
        save(output/'status.json',dict(phase=phase,pid=os.getpid(),updated_at=datetime.now(timezone.utc).isoformat(),**more))
    def record(arm,label,model,opponents,rounds,seed,training=False):
        status(arm+'_'+label,rounds=rounds)
        settings={**env,'QL_SNAPSHOT_DIR':str(output/arm/'checkpoints') if training else ''}
        results[arm+'_'+label]=runner.run(output/arm,label,model,opponents,rounds,seed,
                                         train=training,agent=AGENT,environment=settings)
        save(output/'summary.json',results)
    try:
        for arm in ARMS:
            folder=output/arm; folder.mkdir(); (folder/'checkpoints').mkdir()
            model=folder/'model.json'; mode='blind' if arm=='blind' else 'direction'
            save(model,migrate(base,mode)); verify_model(model,base,mode,1150)
            shutil.copy2(model,folder/'initial_model.json')
            if arm!='frozen':
                record(arm,'training',model,['rule_based_agent','training_coin_pool','training_peace_pool'],
                       args.train_rounds,args.seed,True)
                data=verify_model(model,base,mode,1150+args.train_rounds)
                for k,value in dict(n_step=3,symmetry=True,bootstrap_dynamic=True,attack_shaping='original',
                                    frozen_base=True,behavior_policy='d4_average_urgent_escape').items():
                    assert data['config'][k]==value
                visits=lambda d:sum(sum(v) for v in d['visits'].values())
                metrics=json.loads(model.with_suffix('.backup_metrics.json').read_text())
                assert visits(data)-visits(base)==metrics['updates']
                residual=json.loads(model.with_suffix('.residual_metrics.json').read_text())
                assert 0<residual['eligible_real_updates']<=metrics['updates'] and residual['residual_tiles']>0
                with model.with_suffix('.csv').open(newline='') as handle: rows=list(csv.DictReader(handle))
                assert len(rows)==args.train_rounds
                assert [int(r['episode']) for r in rows]==list(range(1151,1151+args.train_rounds))
                assert all(float(r['epsilon'])==.05 for r in rows)
                verified[arm]=dict(updates=metrics['updates'],**residual)
            model_hash=digest(model)
            for i,(scene,opponents) in enumerate(SCENES.items()):
                record(arm,'pilot_'+scene,model,opponents,args.eval_rounds,args.seed+1+i)
            assert digest(model)==model_hash
            for scene in SCENES:
                rows=[json.loads(s) for s in (folder/f'pilot_{scene}.rounds.jsonl').read_text().splitlines()]
                assert len(rows)==args.eval_rounds
        status('analyzing')
        comparison.AGENT=AGENT
        report=comparison.compare(output,'pilot',list(ARMS),candidate='direction')
        for arm in ARMS:
            verify_model(output/arm/'model.json',base,'blind' if arm=='blind' else 'direction',
                         1150 if arm=='frozen' else 1150+args.train_rounds)
        assert digest(source)==source_hash
        assert all(digest(workspace/p)==h for p,h in locked.items())
        save(output/'verification.json',dict(verified=True,source_unchanged=True,legacy_blocks_frozen=True,
            snapshot_hashes_match=True,maps_paired=True,training=verified,
            model_sha256={a:digest(output/a/'model.json') for a in ARMS}))
        lines=['# Direction residual pilot','', '| Arm | Mixed win | Strong win | Combined win | Mean score | Suicide |',
               '|---|---:|---:|---:|---:|---:|']
        for arm,m in report['measurements'].items():
            c=m['combined']
            lines.append(f"| {arm} | {m['mixed']['win']:.1%} | {m['strong']['win']:.1%} | {c['win']:.1%} | {c['score']:.3f} | {c['suicides']:.1%} |")
        lines+=['','Candidate-minus-frozen and candidate-minus-blind paired intervals are in pilot_comparison.json.',
                '',config['limitations'],'','The frozen accepted model has not been replaced.']
        (output/'RESULTS.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
        status('complete',needs_review=True)
    except Exception as exc:
        status('failed',error=repr(exc)); raise


if __name__=='__main__':
    main()
