"""Locked-policy independent 200-map evaluation, including frozen final agent."""
import hashlib
import json
from pathlib import Path
import shutil
import sys
import numpy as np
import run_fighter_experiment as runner
import evaluate_dynamic as comparison

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'experiments/dynamic_holdout_v1'
SEEDS = [27001, 28001, 29001]
SCENARIOS = [('mixed', ['rule_based_agent', 'coin_collector_agent', 'peaceful_agent'], 57002),
             ('strong', ['rule_based_agent'] * 3, 57003)]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def analyze():
    comparison.ROOT, comparison.OUT = ROOT, OUT
    result = comparison.analyze(rounds=200)
    summary = json.loads((OUT / 'summary.json').read_text())
    rng = np.random.default_rng(57004)
    for scenario, _, _ in SCENARIOS:
        final = [json.loads(x) for x in (OUT / f'reference/q_final_{scenario}.rounds.jsonl').read_text().splitlines()]
        assert len(final) == 200
        matrices = {k: [] for k in ['win', 'score', 'survived', 'suicides']}
        per_seed = []
        for seed in SEEDS:
            rows = [json.loads(x) for x in (OUT / f'seed_{seed}/q_dynamic_{scenario}.rounds.jsonl').read_text().splitlines()]
            assert len(rows) == 200
            assert [r['map_hash'] for r in rows] == [r['map_hash'] for r in final]
            entry = dict(seed=seed)
            for metric in matrices:
                def value(row, agent):
                    return row['agents'][agent].get('suicides', 0) if metric == 'suicides' else row[metric]
                d = [float(value(a, 'q_dynamic')) - float(value(b, 'q_final')) for a, b in zip(rows, final)]
                matrices[metric].append(d)
                entry[metric] = float(np.mean(d))
            per_seed.append(entry)
        si = rng.integers(0, 3, (10000, 3))
        mi = rng.integers(0, 200, (10000, 200))
        diff = {}
        for metric, values in matrices.items():
            a = np.array(values)
            boot = a[si[:, :, None], mi[:, None, :]].mean(axis=(1, 2))
            diff[metric] = dict(mean=float(a.mean()), exploratory_95ci=np.percentile(boot, [2.5, 97.5]).tolist())
        result[scenario]['final_reference'] = summary[f'reference/q_final_{scenario}']
        result[scenario]['dynamic_minus_final'] = dict(differences=diff, per_seed=per_seed)
    result['limitations'] += ' Final reference is one fixed previously trained policy, not three independent final models; repeated final outcomes retained as shared map columns.'
    (OUT / 'analysis.json').write_text(json.dumps(result, indent=2))
    lines = ['# 独立测试结果', '', '每个场景 200 张新地图，三组冻结分块权重，无训练或参数调整。', '',
             '| 场景 | 策略 | 胜率 | 平均得分 | 生存率 | 自杀率 |', '|---|---|---:|---:|---:|---:|']
    notes = []
    for scenario, _, _ in SCENARIOS:
        data = result[scenario]
        for name, metrics in [*data['means'].items(), ('q_final', data['final_reference'])]:
            lines.append(f"| {scenario} | {name} | {metrics['strict_win_rate']:.1%} | {metrics['mean_score']:.2f} | {metrics['survival_rate']:.1%} | {metrics['suicide_rate']:.1%} |")
        for label, differences in [('原分块', data['differences']), ('最终版', data['dynamic_minus_final']['differences'])]:
            w = differences['win']
            lo, hi = w['exploratory_95ci']
            notes.append(f"{scenario}：动态候选减去{label}，胜率差 {100*w['mean']:.1f} 个百分点，探索性 95% 区间 [{100*lo:.1f}, {100*hi:.1f}]。")
    lines += ['', *notes]
    lines += ['', '仅三个训练种子，区间需要谨慎解释。未挑选最好种子，未自动替换提交。详细每种子差异与得分/安全指标区间见 analysis.json。']
    (OUT / 'RESULTS.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')


def main():
    OUT.mkdir(parents=True, exist_ok=False)
    workspace = OUT / 'workspace'
    shutil.copytree(ROOT, workspace, ignore=shutil.ignore_patterns('.git', 'experiments', 'release', 'logs', '__pycache__'))
    (workspace / 'logs').mkdir(exist_ok=True)
    runner.ROOT = workspace
    locked = {}
    for agent in ['q_linear', 'q_dynamic', 'q_final']:
        for path in (workspace / 'agent_code' / agent).glob('*'):
            if path.is_file() and path.suffix in ('.py', '.json'):
                locked[str(path.relative_to(OUT))] = digest(path)
    for seed in SEEDS:
        folder = OUT / f'seed_{seed}'
        folder.mkdir()
        model = folder / 'model.json'
        shutil.copy2(ROOT / f'experiments/dynamic_v1/seed_{seed}/model.json', model)
        locked[str(model.relative_to(OUT))] = digest(model)
    (OUT / 'reference').mkdir()
    (OUT / 'config.json').write_text(json.dumps(dict(training=False, training_seeds=SEEDS,
        rounds_per_scenario=200, evaluation_seeds=[57002, 57003], total_matches=2800,
        python=sys.version, numpy=np.__version__, locked_sha256=locked,
        design='Fixed preexisting weights and code. Dynamic vs original linear across three seeds; one fixed final reference. No tuning, seed selection, or automatic deployment on this holdout.',
        primary='Strict win rate vs original linear and final, separately for mixed and strong opponents.',
        secondary='Score, survival, suicide, inference time. Shared maps are not independent repeats.'), indent=2))
    results = {}
    completed = 0
    def record(folder, agent, scenario, opponents, seed, model):
        nonlocal completed
        label = f'{agent}_{scenario}'
        key = f'{folder.name}/{label}'
        (OUT / 'status.json').write_text(json.dumps(dict(phase=key, completed_batches=completed, total_batches=14)))
        results[key] = runner.run(folder, label, model, opponents, 200, seed, agent=agent)
        assert all(digest(OUT / path) == sha for path, sha in locked.items())
        completed += 1
        (OUT / 'summary.json').write_text(json.dumps(results, indent=2))
    try:
        for scenario, opponents, eval_seed in SCENARIOS:
            record(OUT / 'reference', 'q_final', scenario, opponents, eval_seed, workspace / 'agent_code/q_final/model.json')
            for seed in SEEDS:
                folder = OUT / f'seed_{seed}'
                for agent in ['q_linear', 'q_dynamic']:
                    record(folder, agent, scenario, opponents, eval_seed, folder / 'model.json')
        (OUT / 'status.json').write_text(json.dumps(dict(phase='analyzing', completed_batches=14, total_batches=14)))
        analyze()
        (OUT / 'status.json').write_text(json.dumps(dict(phase='complete', completed_batches=14, total_batches=14)))
    except Exception as exc:
        (OUT / 'status.json').write_text(json.dumps(dict(phase='failed', completed_batches=completed, error=repr(exc))))
        raise


if __name__ == '__main__':
    main()
