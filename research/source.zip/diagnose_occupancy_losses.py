"""Reproduce all control/candidate matches in two isolated offline workers."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import os
import shutil
import subprocess
import sys

from occupancy_experiment import ROOT, SCENES, ARMS, read, save, digest, rows, normalized

SOURCE = ROOT / 'experiments/occupancy_escape_v1'
OUT = ROOT / 'experiments/occupancy_loss_audit_v1'


def normalized_trace(path):
    data = rows(path)
    for row in data:
        search = row.get('occupancy', {}).get('search')
        if search:
            search.pop('elapsed_ms')
    return data


def main():
    config = read(SOURCE / 'config.json')
    assert read(SOURCE / 'review_verification.json')['verified']
    assert all(digest(ROOT / p) == h for p, h in config['source_sha256'].items())
    assert all(digest(SOURCE / 'workspace' / p) == h for p, h in config['locked_sha256'].items())
    OUT.mkdir(parents=True, exist_ok=False)
    save(OUT / 'config.json', dict(started_at=datetime.now(timezone.utc).isoformat(), replay_matches=240,
        new_matches=0, source_sha256=config['source_sha256'], source_config_sha256=digest(SOURCE / 'config.json'),
        instrumentation_sha256=digest(ROOT / 'diagnose_occupancy_match.py')))
    save(OUT / 'status.json', dict(phase='replaying', pid=os.getpid()))
    for arm in ARMS:
        workspace = OUT / arm / 'workspace'
        shutil.copytree(SOURCE / 'workspace', workspace, ignore=shutil.ignore_patterns('logs', '__pycache__'))
        (workspace / 'logs').mkdir(exist_ok=True)
        shutil.copy2(ROOT / 'diagnose_occupancy_match.py', workspace / 'diagnose_occupancy_match.py')

    def replay(arm, agent):
        workspace = OUT / arm / 'workspace'
        for si, (scene, opponents) in enumerate(SCENES.items()):
            target = OUT / arm / scene
            env = {k: v for k, v in os.environ.items() if not k.startswith('QL_')}
            env.update(QL_OCCUPANCY_MODE='on', QL_GUARD_TRACE=str(target / 'policy.trace.jsonl'))
            command = [sys.executable, str(workspace / 'diagnose_occupancy_match.py'), '--agent', agent,
                '--output', str(target), '--model', str(SOURCE / arm / 'model.json'), '--rounds', '60',
                '--seed', str(config['evaluation_seeds'][si]), '--opponents', *opponents]
            with (OUT / arm / (scene + '_process.log')).open('w') as log:
                subprocess.run(command, cwd=workspace, env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
            assert normalized(target / 'match.rounds.jsonl', agent) == normalized(SOURCE / arm / (scene + '.rounds.jsonl'), agent)
            assert normalized_trace(target / 'policy.trace.jsonl') == normalized_trace(SOURCE / arm / (scene + '.trace.jsonl'))
            assert all(digest(workspace / p) == h for p, h in config['locked_sha256'].items())
            save(OUT / arm / 'status.json', dict(phase='complete' if si == 1 else 'strong', completed_matches=(si + 1) * 60))
            print(arm, scene, '60 matches exactly reproduced', flush=True)
    try:
        with ThreadPoolExecutor(max_workers=2) as executor:
            jobs = [executor.submit(replay, arm, agent) for arm, agent in ARMS.items()]
            for job in jobs:
                job.result()
        assert all(digest(ROOT / p) == h for p, h in config['source_sha256'].items())
        hashes = {str(p.relative_to(OUT)): digest(p) for arm in ARMS for scene in SCENES
            for p in (OUT / arm / scene).glob('*') if p.is_file() and p.suffix != '.log'}
        save(OUT / 'replay_verification.json', dict(verified=True, matches=240, exact_actions=True,
            traces_identical_except_elapsed=True, raw_sha256=hashes))
        save(OUT / 'status.json', dict(phase='replay_complete', needs_analysis=True))
    except Exception as exc:
        save(OUT / 'status.json', dict(phase='failed', error=repr(exc)))
        raise


if __name__ == '__main__':
    main()
