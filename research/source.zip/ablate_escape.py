"""Frozen-weight inference ablation; selection precedes fresh-map evaluation."""
import hashlib
import json
from pathlib import Path
import shutil
from run_fighter_experiment import run

ROOT = Path(__file__).parent
OUT = ROOT / 'experiments/escape_ablation_v1'
VARIANTS = {'full': ('1', '1'), 'no_bomb_cost': ('0', '1'), 'half_contest': ('1', '.5')}


def main():
    OUT.mkdir(exist_ok=False)
    selected = json.loads((ROOT / 'experiments/learning_curve_v1/selection.json').read_text())
    source = Path(selected['path'])
    model = OUT / 'model.json'
    shutil.copy2(source, model)
    digest = hashlib.sha256(model.read_bytes()).hexdigest()
    shutil.copytree(ROOT / 'agent_code/q_fighter', OUT / 'source',
                    ignore=shutil.ignore_patterns('logs', '__pycache__', '*.json'))
    config = {'training': False, 'model_source': str(source), 'model_sha256': digest,
              'variants': VARIANTS, 'validation_seed': 45001, 'holdout_seed': 55001,
              'rounds_per_evaluation': 60,
              'selection': 'Highest validation mean score, then strict win rate; ties retain full rules.'}
    (OUT / 'config.json').write_text(json.dumps(config, indent=2))
    results = {}
    def evaluate(label, variant, seed):
        bomb, contest = VARIANTS[variant]
        results[label] = run(OUT, label, model, ['rule_based_agent'] * 3, 60, seed,
            environment={'QF_ESCAPE_RISK': '1', 'QF_ANTICIPATE': '0', 'QF_SHIELD': '1',
                         'QF_BOMB_COST': bomb, 'QF_CONTEST_SCALE': contest})
        (OUT / 'summary.json').write_text(json.dumps(results, indent=2))
    for variant in VARIANTS:
        evaluate('validation_' + variant, variant, 45001)
    winner = max(VARIANTS, key=lambda v: (results['validation_' + v]['mean_score'],
                                         results['validation_' + v]['strict_win_rate']))
    (OUT / 'selection.json').write_text(json.dumps({'selected': winner}, indent=2))
    evaluate('holdout_full', 'full', 55001)
    if winner != 'full':
        evaluate('holdout_selected', winner, 55001)
    assert hashlib.sha256(model.read_bytes()).hexdigest() == digest
    (OUT / 'status.json').write_text(json.dumps({'phase': 'complete', 'selected': winner}))


if __name__ == '__main__':
    main()
