"""Verify paired maps and quantify map-level uncertainty for the linear pilot."""
import csv
import json
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'experiments/linear_v1'


def main():
    assert json.loads((OUT / 'status.json').read_text())['phase'] == 'complete'
    summary = json.loads((OUT / 'summary.json').read_text())
    rng = np.random.default_rng(27004)
    result = {}
    for scenario in ['mixed', 'strong']:
        rows = {label: [json.loads(x) for x in (OUT / f'{label}_{scenario}.rounds.jsonl').read_text().splitlines()]
                for label in ['linear', 'table', 'final']}
        assert all(len(v) == 60 for v in rows.values())
        result[scenario] = {}
        for baseline in ['table', 'final']:
            assert [r['map_hash'] for r in rows['linear']] == [r['map_hash'] for r in rows[baseline]]
            ix = rng.integers(0, 60, size=(10000, 60))
            result[scenario][baseline] = {}
            for metric in ['score', 'win', 'survived']:
                delta = np.array([float(a[metric]) - float(b[metric]) for a, b in zip(rows['linear'], rows[baseline])])
                result[scenario][baseline][metric] = dict(difference=float(delta.mean()),
                    paired_bootstrap_95ci=np.percentile(delta[ix].mean(axis=1), [2.5, 97.5]).tolist())
    result['training'] = {}
    for label in ['linear', 'table']:
        with (OUT / f'{label}.csv').open() as f:
            rows = list(csv.DictReader(f))
        model = json.loads((OUT / f'{label}.json').read_text())
        assert len(rows) == 300 and model['episodes'] == 300
        assert all(np.isfinite(v).all() for v in model['q'].values())
        result['training'][label] = dict(rounds=300, coefficient_rows=len(model['q']),
            visit_rows=len(model['visits']), coefficients_finite=True)
    result['limitation'] = 'Single training seed; bootstrap measures paired map variation, not training-seed uncertainty.'
    (OUT / 'analysis.json').write_text(json.dumps(result, indent=2))
    lines = ['# 分块线性 Q-learning 首轮结果', '',
        '两种模型各从零训练 300 局，全部训练与评估完成。测试每场景 60 局，初始地图哈希已逐局核对一致。final 为既有更多训练预算的冻结版本。', '',
        '| 场景 | 模型 | 胜率 | 平均得分 | 生存率 | 自杀率 |',
        '|---|---|---:|---:|---:|---:|']
    for scenario in ['mixed', 'strong']:
        for label in ['linear', 'table', 'final']:
            s = summary[f'{label}_{scenario}']
            lines.append(f"| {scenario} | {label} | {s['strict_win_rate']:.1%} | {s['mean_score']:.2f} | {s['survival_rate']:.1%} | {s['suicide_rate']:.1%} |")
    lines += ['', '## 配对差异', '', '差异为 linear 减去对照；区间为 10,000 次按地图配对 bootstrap 的 95% 区间。', '']
    for scenario in ['mixed', 'strong']:
        for baseline in ['table', 'final']:
            m = result[scenario][baseline]
            w, s = m['win'], m['score']
            lo, hi = w['paired_bootstrap_95ci']
            slo, shi = s['paired_bootstrap_95ci']
            lines.append(f"- {scenario} 对 {baseline}：胜率差 {100*w['difference']:.1f} 个百分点 [{100*lo:.1f}, {100*hi:.1f}]；得分差 {s['difference']:.2f} [{slo:.2f}, {shi:.2f}]。")
    lines += ['', '## 判断', '',
        '本轮分块表示在同预算两场景的胜率、得分点估计均较原表好，支持继续验证这条路线；尚未证明跨训练种子稳定提升。与冻结最终版相比，混合胜率较高但得分较低，强对手胜率略低，两个场景自杀率均较高。目前不替换最终提交。',
        '建议保持配置，先做多个训练种子的同预算复验，增加独立测试地图；同时诊断强对手场景的自杀轨迹。不要直接把单种子的最好表现当作架构已获胜。',
        '表示仅有 531 个激活系数组合（原表 6821 条 Q 记录），但仍保存完整状态访问计数；不能直接据此宣称内存按相同比例缩小。',
        '复现：python analyze_linear.py；原始结果在 experiments/linear_v1。']
    (ROOT / 'LINEAR_Q_RESULTS.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
