"""Frozen baseline, raw-Q continuation, and D4-mean-Q continuation."""
import argparse
import csv
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys

import numpy as np

import experiment_attack_reward as comparison
import run_fighter_experiment as runner

ROOT = Path(__file__).resolve().parent
AGENT = 'q_aligned'
ARMS = ('frozen', 'raw', 'average')
SCENES = {'mixed': ['rule_based_agent', 'coin_collector_agent', 'peaceful_agent'],
          'strong': ['rule_based_agent'] * 3}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def save(path, data):
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(data, indent=2), encoding='utf-8')
    tmp.replace(path)


def check_training(model, base, mode, rounds):
    data = read(model)
    assert data['episodes'] == 1150 + rounds
    for field, expected in dict(learning_value_mode=mode, attack_shaping='original',
                                behavior_policy='d4_average_urgent_escape', n_step=3,
                                symmetry=True, bootstrap_dynamic=True, gradient_divisor=7).items():
        assert data['config'][field] == expected
    assert all(len(v) == 6 and np.isfinite(v).all() for v in data['q'].values())
    assert all(len(k.split(',')) == 16 for k in data['visits'])
    visits = lambda d: sum(sum(v) for v in d['visits'].values())
    updates = read(model.with_suffix('.backup_metrics.json'))['updates']
    credit = read(model.with_suffix('.credit_metrics.json'))
    counts = credit['counts']
    assert credit['learning_value_mode'] == mode
    assert visits(data) - visits(base) == updates == counts['updates']
    assert sum(counts.get('effective_length_' + str(i), 0) for i in (1, 2, 3)) == updates
    assert 0 <= counts['cut_branches'] <= counts['branch_opportunities']
    assert 0 <= counts['three_step_reaches_last'] <= counts['three_step_windows']
    with model.with_suffix('.csv').open(newline='') as handle: rows = list(csv.DictReader(handle))
    assert [int(r['episode']) for r in rows] == list(range(1151, 1151 + rounds))
    assert all(float(r['epsilon']) == .05 for r in rows)
    assert sum(int(r['steps']) for r in rows) == updates
    return dict(updates=updates, counts=counts,
                cut_branch_rate=counts['cut_branches'] / max(1, counts['branch_opportunities']),
                three_step_reaches_last_rate=counts['three_step_reaches_last'] / max(1, counts['three_step_windows']),
                mean_last_reward_coefficient_in_three_step=counts['three_step_last_reward_coefficient_sum'] / max(1, counts['three_step_windows']),
                mean_discounted_reward_coefficient_mass=counts['discounted_reward_coefficient_sum'] / updates)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--name', default='learning_alignment_v1')
    parser.add_argument('--train-rounds', type=int, default=100)
    parser.add_argument('--eval-rounds', type=int, default=60)
    parser.add_argument('--seed', type=int, default=227001)
    args = parser.parse_args()
    assert Path(args.name).name == args.name and args.name not in ('.', '..')
    assert args.train_rounds > 0 and args.eval_rounds > 0
    manifest = read(ROOT / 'CURRENT_CANDIDATE.json')
    assert manifest['agent'] == 'q_urgent' and manifest['episodes'] == 1150
    source = ROOT / manifest['model']; base = read(source)
    assert digest(source) == manifest['model_sha256']
    assert all(digest(ROOT / p) == h for p, h in manifest['code_sha256'].items())
    checks = read(ROOT / 'experiments/learning_alignment_checks_v1/verification.json')
    assert checks['verified'] and checks['source_sha256'] == digest(source)
    output = ROOT / 'experiments' / args.name; output.mkdir(parents=True, exist_ok=False)
    workspace = output / 'workspace'
    shutil.copytree(ROOT, workspace, ignore=shutil.ignore_patterns('.git', 'experiments', 'release', 'logs', '__pycache__'))
    (workspace / 'logs').mkdir(exist_ok=True); runner.ROOT = workspace
    files = list(workspace.glob('*.py')) + list((workspace / 'agent_code').rglob('*.py'))
    locked = {str(p.relative_to(workspace)): digest(p) for p in files}
    source_hashes = {str(p.relative_to(ROOT)): digest(p) for p in (source, ROOT / 'CURRENT_CANDIDATE.json')}
    env = {**read(ROOT / 'experiments/target_learning_curve_v1/config.json')['environment'],
           'QF_EPSILON': '.05', 'QL_SNAPSHOT_DIR': '', 'BM_TRACK_COLLISIONS': '1'}
    config = dict(started_at=datetime.now(timezone.utc).isoformat(), source_hashes=source_hashes,
                  train_rounds_each=args.train_rounds, eval_rounds_each=args.eval_rounds,
                  training_seed=args.seed, evaluation_seeds=[args.seed + 1, args.seed + 2],
                  environment=env, arms=list(ARMS), agent=AGENT, locked_sha256=locked,
                  python=sys.version, numpy=np.__version__, checks=checks,
                  design='All arms start from identical 1150-episode weights/visits and D4-average urgent behavior. Original rewards. Raw control retains original augmented tree backup. Average uses Qbar for current prediction and max bootstrap/tree-backup probabilities, with its exact D4-mean semi-gradient divided by seven. Fixed final checkpoint, no checkpoint selection.',
                  primary_metric='Equal-scene strict win rate; paired comparisons of average against frozen and raw.',
                  diagnostics='Native recorded windows at actual update time: branch cuts, effective reward reach, tie/gamma coefficient mass. Not independent samples; raw augmented orientations are not included in native metrics.',
                  limitation='Single continuation seed, small evaluation sets, exploratory paired-map intervals without multiplicity correction. No automatic promotion, no holdout gate or follow-on training.')
    save(output / 'config.json', config)
    save(output / 'process.json', dict(pid=os.getpid(), started_at=config['started_at']))
    summary = {}; training = {}; hashes = {}; completed = 0
    def status(phase, **more):
        save(output / 'status.json', dict(phase=phase, pid=os.getpid(), updated_at=datetime.now(timezone.utc).isoformat(),
            completed_batches=completed, total_batches=8, **more))
    try:
        for arm in ARMS:
            folder = output / arm; folder.mkdir(); (folder / 'checkpoints').mkdir()
            model = folder / 'model.json'; shutil.copy2(source, model)
            shutil.copy2(source, folder / 'initial_model.json')
            mode = 'raw' if arm == 'raw' else 'average'
            def run(label, opponents, rounds, seed, train=False):
                nonlocal completed
                status(arm + '_' + label, rounds=rounds)
                summary[arm + '_' + label] = runner.run(folder, label, model, opponents, rounds, seed,
                    train=train, agent=AGENT, environment={**env, 'QL_LEARNING_Q': mode,
                        'QL_SNAPSHOT_DIR': str(folder / 'checkpoints') if train else ''})
                completed += 1
                save(output / 'summary.json', summary)
                assert all(digest(ROOT / p) == h for p, h in source_hashes.items())
                assert all(digest(workspace / p) == h for p, h in locked.items())
            if arm != 'frozen':
                run('training', ['rule_based_agent', 'training_coin_pool', 'training_peace_pool'],
                    args.train_rounds, args.seed, True)
                training[arm] = check_training(model, base, mode, args.train_rounds)
                save(output / 'training_diagnostics.json', training)
            hashes[arm] = digest(model)
            for i, (scene, opponents) in enumerate(SCENES.items()):
                run('pilot_' + scene, opponents, args.eval_rounds, args.seed + 1 + i)
            assert digest(model) == hashes[arm]
        status('analyzing')
        comparison.AGENT = AGENT
        report = comparison.compare(output, 'pilot', list(ARMS), candidate='average')
        report['limitation'] = config['limitation']
        save(output / 'pilot_comparison.json', report)
        for arm in ARMS:
            for scene in SCENES:
                rows = [json.loads(x) for x in (output / arm / f'pilot_{scene}.rounds.jsonl').read_text().splitlines()]
                assert len(rows) == args.eval_rounds
                for row in rows:
                    own = row['agents'][AGENT]
                    other_scores = [a['score'] for name, a in row['agents'].items() if name != AGENT]
                    assert row['score'] == own['score'] == own.get('coins', 0) + 5 * own.get('kills', 0)
                    assert row['win'] == (row['score'] > max(other_scores))
                m = report['measurements'][arm][scene]; s = summary[arm + '_pilot_' + scene]
                for metric, field in dict(win='strict_win_rate', score='mean_score', survived='survival_rate',
                                          suicides='suicide_rate', coins='mean_coins', kills='mean_kills').items():
                    assert np.isclose(m[metric], s[field])
        save(output / 'verification.json', dict(verified=True, source_unchanged=True, snapshot_hashes_match=True,
            maps_paired=True, raw_summaries_checked=True, model_sha256=hashes, training=training))
        lines = ['# Learning alignment pilot', '', '| Arm | Mixed win | Strong win | Combined win | Mean score | Suicide |',
                 '|---|---:|---:|---:|---:|---:|']
        for arm, m in report['measurements'].items():
            c = m['combined']
            lines.append(f"| {arm} | {m['mixed']['win']:.1%} | {m['strong']['win']:.1%} | {c['win']:.1%} | {c['score']:.3f} | {c['suicides']:.1%} |")
        (output / 'RESULTS.md').write_text('\n'.join(lines + ['', config['limitation']]) + '\n', encoding='utf-8')
        status('complete', needs_review=True)
    except Exception as exc:
        status('failed', error=repr(exc))
        raise


if __name__ == '__main__':
    main()
