"""Exact additive accounting of recorded crate decisions; no policy changes."""
from collections import Counter
import gzip
import json
from pathlib import Path
import numpy as np
from agent_code.q_dynamic.callbacks import BLOCKS, active_tiles
from agent_code.q_dynamic.features import ACTIONS

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'experiments/resource_diagnosis_v1'
NAMES = ['global_bias', 'safety', 'navigation', 'resource', 'combat', 'bomb_interaction', 'phase_threat_interaction']


def main():
    result = {}
    for seed in [27001, 28001, 29001]:
        folder = OUT / f'seed_{seed}'
        model = json.loads((folder / 'model.json').read_text())
        assert model['blocks'] == [list(b) for b in BLOCKS]
        weights = {tuple(map(int, k.split(','))): np.array(v) for k, v in model['q'].items()}
        differences, margins, costs, keys, examples = [], [], [], set(), []
        chosen = Counter()
        remove_flip = Counter()
        all_opportunities = 0
        checked = 0
        with gzip.open(folder / 'score_frames.jsonl.gz', 'rt') as handle:
            for line in handle:
                frame = json.loads(line)
                key = tuple(frame['info']['key'])
                contributions = np.array([weights.get(tile, np.zeros(6)) for tile in active_tiles(key)])
                raw = contributions.sum(axis=0)
                np.testing.assert_allclose(raw, frame['q'], atol=1e-10, rtol=1e-10)
                adjusted = raw - np.array(frame['costs'])
                np.testing.assert_allclose(adjusted, frame['adjusted_q'], atol=1e-10, rtol=1e-10)
                checked += 1
                if frame['info']['threatened'] or frame['info']['target'] != 2 or frame['info']['yield'] <= 0 or not frame['candidate_mask'][5]:
                    continue
                all_opportunities += 1
                action = ACTIONS.index(frame['chosen'])
                if action == 5:
                    continue
                delta = contributions[:, action] - contributions[:, 5]
                cost_delta = frame['costs'][5] - frame['costs'][action]
                margin = adjusted[action] - adjusted[5]
                assert margin > 0
                np.testing.assert_allclose(delta.sum() + cost_delta, margin, atol=1e-10)
                differences.append(delta)
                margins.append(margin)
                costs.append(cost_delta)
                keys.add(key)
                chosen[frame['chosen']] += 1
                candidates = np.array(frame['candidate_mask'], dtype=bool)
                for i, name in enumerate(NAMES):
                    # Deleting one fitted block is an offline sensitivity check,
                    # not a valid retraining experiment or a win-rate prediction.
                    scores = adjusted - contributions[i]
                    remove_flip[name] += bool(scores[5] >= scores[candidates].max() - 1e-10)
                if len(examples) < 3:
                    examples.append(dict(round=frame['round'], step=frame['step'], action=frame['chosen'],
                        key=key, position=frame['state']['self'][3], yield_crates=frame['info']['yield'],
                        delta_by_block=dict(zip(NAMES, delta.tolist())), escape_cost_contribution=cost_delta,
                        final_margin=float(margin), raw_q=raw.tolist()))
        d = np.array(differences)
        result[str(seed)] = dict(all_frames_verified=checked, opportunities=all_opportunities,
            skipped=len(d), distinct_skipped_keys=len(keys), chosen=dict(chosen),
            mean_margin=float(np.mean(margins)), median_margin=float(np.median(margins)),
            mean_escape_cost_contribution=float(np.mean(costs)),
            blocks={name: dict(mean_move_minus_bomb=float(d[:,i].mean()),
                              fraction_favoring_chosen=float((d[:,i]>0).mean()),
                              largest_positive_count=int(((d.argmax(axis=1)==i)&(d[:,i]>0)).sum()),
                              bomb_best_if_block_removed=int(remove_flip[name])) for i,name in enumerate(NAMES)},
            examples=examples)
    result['limitations'] = ('Exact decomposition in the current fitted parameterization, not causal attribution. '
        'Overlapping one-hot blocks are redundant; individual coefficients need not be uniquely identifiable. '
        'Repeated states and loops are correlated. Removing a block changes Q calibration and does not predict retrained performance.')
    (OUT / 'block_analysis.json').write_text(json.dumps(result, indent=2))
    print(json.dumps({seed:{k:v for k,v in data.items() if k!='examples'} for seed,data in result.items() if isinstance(data,dict)},indent=2))


if __name__ == '__main__':
    main()
