"""Reproduce both fixed-policy batches in isolated copies and record causes."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

from diagnose_symavg_survival import stable_rows

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'experiments/pursuit_switch_v1'
OUT = ROOT / 'experiments/switch_failures_v1'
SCENES = {'mixed': ['rule_based_agent', 'coin_collector_agent', 'peaceful_agent'],
          'strong': ['rule_based_agent'] * 3}


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, obj):
    path.write_text(json.dumps(obj, indent=2), encoding='utf-8')


def main():
    config = read(SOURCE / 'config.json')
    review = read(SOURCE / 'review_verification.json')
    assert review['verified'] and review['matches'] == 240
    assert all(digest(SOURCE / 'workspace' / p) == h for p, h in config['locked_sha256'].items())
    assert all(digest(SOURCE / p) == h for p, h in review['trace_and_rows_sha256'].items())
    assert all(digest(ROOT / p) == h for p, h in config['source_sha256'].items())
    OUT.mkdir(parents=True, exist_ok=False)
    locked = {}
    for arm in ('off', 'switch'):
        folder = OUT / arm
        folder.mkdir()
        workspace = folder / 'workspace'
        shutil.copytree(SOURCE / 'workspace', workspace, ignore=shutil.ignore_patterns('logs', '__pycache__'))
        (workspace / 'logs').mkdir(exist_ok=True)
        shutil.copy2(ROOT / 'diagnose_switch_fighter.py', workspace / 'diagnose_switch_fighter.py')
        locked[arm] = {str(p.relative_to(workspace)): digest(p)
                       for p in list(workspace.glob('*.py')) + list((workspace / 'agent_code').rglob('*.py'))}
        assert all(digest(workspace / p) == h for p, h in config['locked_sha256'].items())
    save(OUT / 'config.json', dict(started_at=datetime.now(timezone.utc).isoformat(), source=str(SOURCE),
         purpose='Exact replay diagnosis, no new policy, training, or independent win-rate estimate.',
         original_config_sha256=digest(SOURCE / 'config.json'), source_sha256=config['source_sha256'],
         locked_sha256=locked, instrumentation_sha256=digest(ROOT / 'diagnose_switch_fighter.py')))
    save(OUT / 'status.json', dict(phase='replaying', rounds=240, pid=os.getpid()))

    def run_arm(arm):
        folder = OUT / arm
        workspace = folder / 'workspace'
        for i, (scene, opponents) in enumerate(SCENES.items()):
            save(folder / 'status.json', dict(phase=scene, completed_scenes=i))
            target = folder / scene
            command = [sys.executable, str(workspace / 'diagnose_switch_fighter.py'), '--output', str(target),
                       '--agent', 'q_switch', '--model', str(SOURCE / arm / 'model.json'), '--rounds', '60',
                       '--seed', str(config['evaluation_seeds'][i]), '--score-details', '--opponents', *opponents]
            with (folder / (scene + '_process.log')).open('w') as log:
                subprocess.run(command, cwd=workspace, check=True, stdout=log, stderr=subprocess.STDOUT,
                    env={**os.environ, 'BM_TRACK_COLLISIONS': '1', 'QL_SWITCH_MODE': arm,
                         'QL_SWITCH_TRACE': str(target / 'policy.trace.jsonl')})
            assert stable_rows(target / 'match.rounds.jsonl') == stable_rows(SOURCE / arm / f'pilot_{scene}.rounds.jsonl')
            assert digest(target / 'policy.trace.jsonl') == digest(SOURCE / arm / f'pilot_{scene}.trace.jsonl')
            assert all(digest(workspace / p) == h for p, h in locked[arm].items())
            print(f'{arm} {scene}: 60 games and full decision traces exactly reproduced (timing excluded)', flush=True)
        save(folder / 'status.json', dict(phase='complete', completed_scenes=2))

    try:
        # Separate workspaces, logs and output paths; these reads/replays are independent.
        with ThreadPoolExecutor(max_workers=2) as pool:
            futures = [pool.submit(run_arm, arm) for arm in ('off', 'switch')]
            for future in futures:
                future.result()
        assert all(digest(ROOT / p) == h for p, h in config['source_sha256'].items())
        save(OUT / 'status.json', dict(phase='replay_complete', rounds=240, needs_analysis=True))
    except Exception as exc:
        save(OUT / 'status.json', dict(phase='failed', error=repr(exc)))
        raise


if __name__ == '__main__':
    main()
