"""Compare full actions on fixed recorded observations, without changing weights."""
import gzip
import itertools
import json
import os
from pathlib import Path
import time
from types import SimpleNamespace
import numpy as np
from agent_code.q_linear import callbacks as baseline
from agent_code.q_dynamic import callbacks as candidate

ROOT = Path(__file__).resolve().parent
os.environ['QL_MODEL'] = str(ROOT / 'experiments/linear_v1/linear.json')
agents = [SimpleNamespace(train=False), SimpleNamespace(train=False)]
for module, agent in zip([baseline, candidate], agents):
    module.setup(agent)
times = [[], []]
changed = 0
with gzip.open(ROOT / 'experiments/linear_diagnosis_v1/score_frames.jsonl.gz', 'rt') as handle:
    for line in itertools.islice(handle, 1200):
        s = json.loads(line)['state']
        for name in ['field', 'explosion_map']:
            s[name] = np.array(s[name])
        s['self'] = (*s['self'][:3], tuple(s['self'][3]))
        s['others'] = [(*o[:3], tuple(o[3])) for o in s['others']]
        s['coins'] = [tuple(p) for p in s['coins']]
        s['bombs'] = [(tuple(p), t) for p, t in s['bombs']]
        actions = []
        for i, (module, agent) in enumerate(zip([baseline, candidate], agents)):
            # Reset equally per observation so prior tie choices do not confound action differences.
            agent.rng = np.random.default_rng(42)
            start = time.perf_counter()
            actions.append(module.act(agent, s))
            times[i].append(1000 * (time.perf_counter() - start))
        changed += actions[0] != actions[1]
result = dict(states=len(times[0]), changed_actions=changed, timing={
    name: dict(mean_ms=float(np.mean(t)), p99_ms=float(np.percentile(t, 99)), max_ms=max(t))
    for name, t in zip(['baseline', 'dynamic'], times)},
    limitation='Recorded states, not a win-rate test or a worst-case latency guarantee; setup excluded.')
(ROOT / 'dynamic_latency.json').write_text(json.dumps(result, indent=2))
print(json.dumps(result, indent=2))
