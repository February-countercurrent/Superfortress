"""Paired bootstrap intervals for fixed-seed maps (not independent training runs)."""
import json
from pathlib import Path
import numpy as np

output = Path(__file__).parent / 'experiments/escape_v1'
results = {}
for group in ('development', 'fresh', 'duel'):
    paths = [output / f'{group}_{variant}.rounds.jsonl' for variant in ('baseline', 'escape')]
    rows = [[json.loads(line) for line in p.read_text().splitlines()] for p in paths]
    assert len(rows[0]) == len(rows[1])
    assert all(a['map_hash'] == b['map_hash'] for a, b in zip(*rows))
    rng = np.random.default_rng(731)
    indices = rng.integers(len(rows[0]), size=(10000, len(rows[0])))
    result = {}
    for metric in ('score', 'survived', 'win'):
        differences = np.array([float(b[metric]) - float(a[metric]) for a, b in zip(*rows)])
        result[metric] = {'mean_change': float(differences.mean()),
            'paired_bootstrap_95_interval': np.quantile(differences[indices].mean(axis=1), [.025, .975]).tolist()}
    results[group] = result
(output / 'paired_analysis.json').write_text(json.dumps(results, indent=2))
print(json.dumps(results, indent=2))
