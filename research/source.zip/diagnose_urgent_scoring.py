"""Replay all 120 accepted q_urgent matches for survivor score diagnostics."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
from diagnose_symavg_survival import stable_rows

ROOT = Path(__file__).resolve().parent
OUT = ROOT/'experiments/urgent_scoring_v1'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    manifest = json.loads((ROOT/'CURRENT_CANDIDATE.json').read_text())
    assert manifest['agent'] == 'q_urgent' and manifest['accepted_by_user']
    source = ROOT/manifest['model']
    assert digest(source) == manifest['model_sha256']
    assert all(digest(ROOT/p) == h for p,h in manifest['code_sha256'].items())
    OUT.mkdir(parents=True,exist_ok=False)
    workspace = OUT/'workspace'
    shutil.copytree(ROOT,workspace,ignore=shutil.ignore_patterns('.git','experiments','release','logs','__pycache__'))
    (workspace/'logs').mkdir(exist_ok=True)
    model = OUT/'model.json'; shutil.copy2(source,model)
    locked = {str(p.relative_to(OUT)):digest(p) for p in (workspace/'agent_code/q_urgent').glob('*.py')}
    for name in ('diagnose_fighter.py','run_fighter_match.py','environment.py','settings.py'):
        locked[str((workspace/name).relative_to(OUT))] = digest(workspace/name)
    scenes = [('mixed',187002,['rule_based_agent','coin_collector_agent','peaceful_agent']),
              ('strong',187003,['rule_based_agent']*3)]
    (OUT/'config.json').write_text(json.dumps(dict(agent='q_urgent',rounds_each=60,seeds=[187002,187003],
        model_sha256=manifest['model_sha256'],locked_sha256=locked,
        reference='experiments/urgent_escape_v1/urgent_{scene}.rounds.jsonl',
        environment={'BM_TRACK_COLLISIONS':'1'},
        purpose='Reproduce all matches; classify alive losses separately from ties and wins. No policy changes, training or new win-rate claims.'),indent=2))
    try:
        for index,(scene,seed,opponents) in enumerate(scenes):
            (OUT/'status.json').write_text(json.dumps(dict(phase=scene,completed_scenes=index,total_scenes=2)))
            command = [sys.executable,str(workspace/'diagnose_fighter.py'),'--agent','q_urgent',
                '--model',str(model),'--output',str(OUT/scene),'--rounds','60','--seed',str(seed),
                '--score-details','--opponents',*opponents]
            subprocess.run(command,cwd=workspace,env={**os.environ,'BM_TRACK_COLLISIONS':'1'},check=True)
            observed = stable_rows(OUT/scene/'match.rounds.jsonl')
            reference = stable_rows(ROOT/f'experiments/urgent_escape_v1/urgent_{scene}.rounds.jsonl')
            assert len(observed) == len(reference) == 60 and observed == reference
            assert all(digest(OUT/p) == h for p,h in locked.items())
            assert digest(source) == digest(model) == manifest['model_sha256']
            print(scene,'60 rounds reproduced exactly except timing',flush=True)
        (OUT/'status.json').write_text(json.dumps(dict(phase='replay_complete',completed_scenes=2,total_scenes=2)))
    except Exception as exc:
        (OUT/'status.json').write_text(json.dumps(dict(phase='failed',error=repr(exc))))
        raise


if __name__ == '__main__':
    main()
