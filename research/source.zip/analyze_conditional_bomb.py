"""Check paired maps and quantify uncertainty after frozen-model ablation."""
import json
from pathlib import Path
import numpy as np

p = Path(__file__).parent / 'experiments/conditional_bomb_v1'
def rows(label):
    return [json.loads(line) for line in (p / f'{label}.rounds.jsonl').read_text().splitlines()]

summary = json.loads((p / 'summary.json').read_text())
result = {'metrics': summary, 'paired_comparisons': {}}
comparisons = [('validation_full', 'validation_off'),
               ('validation_full', 'validation_late_behind')]
if 'holdout_selected' in summary:
    comparisons.append(('holdout_full', 'holdout_selected'))
for first, second in comparisons:
    a, b = rows(first), rows(second)
    assert len(a) == len(b) == 60
    assert all(x['map_hash'] == y['map_hash'] for x, y in zip(a, b))
    indices = np.random.default_rng(183).integers(60, size=(20000, 60))
    stats = {}
    for metric in ('score', 'win', 'survived'):
        d = np.array([float(y[metric]) - float(x[metric]) for x, y in zip(a, b)])
        stats[metric] = {'mean_change': float(d.mean()),
                         'interval_95': np.quantile(d[indices].mean(axis=1), [.025, .975]).tolist()}
    result['paired_comparisons'][second] = stats
(p / 'analysis.json').write_text(json.dumps(result, indent=2))
print(json.dumps(result['paired_comparisons'], indent=2))
