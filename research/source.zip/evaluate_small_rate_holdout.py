"""Frozen final-checkpoint comparison on independent maps; no training."""
import hashlib
import json
from pathlib import Path
import shutil
import sys
import numpy as np
import run_fighter_experiment as runner

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'experiments/small_rate_holdout_v1'
SCENARIOS = [('mixed', ['rule_based_agent','coin_collector_agent','peaceful_agent'], 87002),
             ('strong', ['rule_based_agent'] * 3, 87003)]
POLICIES = [('small_rate','q_dynamic','experiments/small_rate_v1/checkpoints/step_300.json'),
            ('original_rate','q_dynamic','experiments/stability_v1/checkpoints/step_300.json'),
            ('final','q_final','agent_code/q_final/model.json')]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def analyze():
    summary = json.loads((OUT/'summary.json').read_text())
    rng = np.random.default_rng(87004)
    result = {}
    for scenario, _, _ in SCENARIOS:
        rows = {label:[json.loads(line) for line in (OUT/f'{label}_{scenario}.rounds.jsonl').read_text().splitlines()]
                for label,_,_ in POLICIES}
        assert all(len(r)==200 for r in rows.values())
        result[scenario] = {}
        for baseline, agent in [('original_rate','q_dynamic'),('final','q_final')]:
            a,b = rows['small_rate'], rows[baseline]
            assert [r['map_hash'] for r in a] == [r['map_hash'] for r in b]
            ix = rng.integers(0,200,(10000,200))
            metrics = {}
            for metric in ['win','score','survived','coins','kills','crates','suicides']:
                def value(row, name):
                    return row[metric] if metric in ['win','score','survived'] else row['agents'][name].get(metric,0)
                d = np.array([float(value(x,'q_dynamic'))-float(value(y,agent)) for x,y in zip(a,b)])
                metrics[metric] = dict(difference=float(d.mean()),paired_map_95ci=np.percentile(d[ix].mean(axis=1),[2.5,97.5]).tolist())
            result[scenario][baseline] = metrics
    result['limitations'] = 'One fixed training seed/checkpoint per policy; intervals reflect paired-map sampling only, not retraining variability. No parameter tuning, best-checkpoint selection or automatic promotion.'
    (OUT/'analysis.json').write_text(json.dumps(result,indent=2))
    lines = ['# 小步长候选独立测试','','每场景 200 张新地图，三种冻结策略。候选与原步长均固定新增训练 300 局后的最后检查点。','',
             '| 场景 | 策略 | 胜率 | 平均得分 | 平均金币 | 生存率 | 自杀率 |','|---|---|---:|---:|---:|---:|---:|']
    notes=[]
    for scenario,_,_ in SCENARIOS:
        for label,_,_ in POLICIES:
            m=summary[f'{label}_{scenario}']
            lines.append(f"| {scenario} | {label} | {m['strict_win_rate']:.1%} | {m['mean_score']:.2f} | {m['mean_coins']:.2f} | {m['survival_rate']:.1%} | {m['suicide_rate']:.1%} |")
        for baseline in ['original_rate','final']:
            w=result[scenario][baseline]['win']; lo,hi=w['paired_map_95ci']
            notes.append(f"- {scenario}：小步长减去 {baseline} 胜率差 {100*w['difference']:.1f} 个百分点，地图配对 95% 区间 [{100*lo:.1f}, {100*hi:.1f}]。")
    lines += ['',*notes,'','仅单个训练种子，不反映重新训练的波动。未自动替换提交。完整指标区间见 analysis.json。']
    (OUT/'RESULTS.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')


def main():
    OUT.mkdir(parents=True,exist_ok=False)
    workspace=OUT/'workspace'
    shutil.copytree(ROOT,workspace,ignore=shutil.ignore_patterns('.git','experiments','release','logs','__pycache__'))
    (workspace/'logs').mkdir(exist_ok=True)
    runner.ROOT=workspace
    models={}
    locked={}
    for label,agent,relative in POLICIES:
        target=OUT/f'{label}_model.json'
        shutil.copy2(ROOT/relative,target)
        models[label]=target
        locked[str(target.relative_to(OUT))]=digest(target)
    for agent in ['q_dynamic','q_final']:
        for path in (workspace/'agent_code'/agent).glob('*'):
            if path.is_file() and path.suffix in ['.py','.json']:
                locked[str(path.relative_to(OUT))]=digest(path)
    assert digest(models['final'])==digest(workspace/'agent_code/q_final/model.json')
    old=json.loads(models['original_rate'].read_text()); new=json.loads(models['small_rate'].read_text())
    assert old['episodes']==new['episodes']==600
    assert np.isclose(new['config']['rate_scale'],1/3)
    (OUT/'config.json').write_text(json.dumps(dict(training=False,rounds=200,total_matches=1200,
        evaluation_seeds=[87002,87003],policies=POLICIES,locked_sha256=locked,
        python=sys.version,numpy=np.__version__,
        primary='Strict win rate for mixed and strong scenarios separately, against both controls.',
        secondary='Score, coins, kills, crates, survival, suicide, mean action latency.',
        design='Freeze last checkpoint selected before new evaluation. No retraining or tuning. No automatic submission replacement.',
        limitation='One training seed; final reference has a larger historical training budget.'),indent=2))
    results={}; completed=0
    try:
        for scenario,opponents,seed in SCENARIOS:
            for label,agent,_ in POLICIES:
                key=f'{label}_{scenario}'
                (OUT/'status.json').write_text(json.dumps(dict(phase=key,completed_batches=completed,total_batches=6)))
                results[key]=runner.run(OUT,key,models[label],opponents,200,seed,agent=agent)
                assert all(digest(OUT/p)==h for p,h in locked.items())
                completed+=1
                (OUT/'summary.json').write_text(json.dumps(results,indent=2))
        (OUT/'status.json').write_text(json.dumps(dict(phase='analyzing',completed_batches=6,total_batches=6)))
        analyze()
        (OUT/'status.json').write_text(json.dumps(dict(phase='complete',completed_batches=6,total_batches=6)))
    except Exception as exc:
        (OUT/'status.json').write_text(json.dumps(dict(phase='failed',completed_batches=completed,error=repr(exc))))
        raise


if __name__=='__main__':
    main()
