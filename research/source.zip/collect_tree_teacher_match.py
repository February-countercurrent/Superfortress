"""Record full tree-FQI targets while a frozen teacher plays unchanged."""
import argparse
from collections import Counter
import importlib
from pathlib import Path
import sys
from types import SimpleNamespace
import numpy as np

from agent_code.tree_fqi import train
from enrich_tree_fqi_match import SnapshotContext,next_decision_state
from environment import BombeRLeWorld
import run_tree_fqi_match


class Recorder:
    def __init__(self,folder,epsilon=0.):
        folder.mkdir(parents=True,exist_ok=False)
        self.collector=SimpleNamespace(data_dir=folder,pending=None,transitions=[],
            counts=Counter(),epsilon=epsilon)
        self.last=None

    def step_done(self,decision,new,events,dead,running):
        if decision is not None:
            self.last=decision
            if not dead:
                train.game_events_occurred(self.collector,*decision,new,list(events))
        if not running:
            assert self.last is not None
            train.end_of_round(self.collector,*self.last,list(events))
            self.last=None


def main():
    parser=argparse.ArgumentParser(add_help=False)
    parser.add_argument('--data-dir',type=Path,required=True)
    parser.add_argument('--random-behavior',action='store_true')
    parser.add_argument('--agent',choices=['tree_fqi','q_guard'],required=True)
    args,rest=parser.parse_known_args()
    assert '--train' not in rest, 'Observation must not alter framework training mode'
    callback=importlib.import_module('agent_code.'+args.agent+'.callbacks')
    original_act,original_setup=callback.act,callback.setup
    original_step,original_observe=BombeRLeWorld.do_step,train.observe
    context=SnapshotContext();pending=[]
    recorder=Recorder(args.data_dir,1. if args.random_behavior else 0.)

    def observe(self,old,action,new,events):
        original_observe(self,old,action,new,events)
        if old is None:return
        x,bonus=context(old)
        next_x=np.zeros(28,dtype=np.int8) if new is None else context(next_decision_state(new))[0]
        self.transitions[-1].update(tactical_x=x.copy(),tactical_next_x=next_x.copy(),
            open_attack_bonus=bonus if action=='BOMB' else 0.)

    def setup(self):
        original_setup(self)
        if args.random_behavior:
            assert args.agent=='tree_fqi'
            # Only the callback's fake_self changes; world Agent.train stays False.
            self.train=True;self.epsilon=1.

    def act(self,state):
        action=original_act(self,state)
        pending.append((state,action))
        return action

    def step(world,*a,**kw):
        pending.clear()
        result=original_step(world,*a,**kw)
        first=world.agents[0];decision=None
        if pending:
            assert len(pending)==1
            state,requested=pending[0]
            executed=[action for step,slot,action in world.match_actions if step==world.step and slot==0]
            assert executed==[requested], 'Never label a timeout fallback with its requested action'
            decision=(state,executed[0])
        recorder.step_done(decision,world.get_state_for_agent(first),first.events,first.dead,world.running)
        return result

    callback.setup,callback.act=setup,act
    train.observe=observe;BombeRLeWorld.do_step=step
    sys.argv=[sys.argv[0],'--agent',args.agent,*rest]
    run_tree_fqi_match.main()


if __name__=='__main__':main()
