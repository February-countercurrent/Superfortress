"""Frozen Q weights; fixed search design; paired validation and fresh test."""
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import shutil
import hashlib
import numpy as np
from finalize_agent import match

ROOT = Path(__file__).parent.resolve()
OUT = ROOT / 'experiments/sequence_v1'


def worker(name):
    folder = OUT / name
    folder.mkdir()
    workspace = folder / 'workspace'
    shutil.copytree(ROOT, workspace, ignore=shutil.ignore_patterns('.git', 'experiments', 'release', 'logs', '__pycache__'))
    (workspace / 'logs').mkdir(exist_ok=True)
    results = {}
    for label, count, seed in [('validation', 60, 155001), ('holdout', 100, 155002)]:
        (folder / 'status.json').write_text(json.dumps({'phase': label}))
        results[label] = match(workspace, folder, label, ['rule_based_agent'] * 3, count, seed, agent=name)
        (folder / 'results.json').write_text(json.dumps(results, indent=2))
        print(name, label, json.dumps(results[label]), flush=True)
    (folder / 'status.json').write_text(json.dumps({'phase': 'complete'}))
    return name, results


def main():
    OUT.mkdir(exist_ok=False)
    digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
    assert digest(ROOT / 'agent_code/q_final/model.json') == digest(ROOT / 'agent_code/q_sequence/model.json')
    (OUT / 'config.json').write_text(json.dumps({'training': False,
        'model_sha256': digest(ROOT / 'agent_code/q_final/model.json'),
        'validation_seed': 155001, 'holdout_seed': 155002,
        'coefficients': {'trap_bonus': 5., 'pressure_weight': 1., 'prefix_step_cost': .15, 'contested_step_cost': .5, 'override_threshold': .25, 'max_prefix_steps': 2},
        'note': 'Receding-horizon move-plant-escape override, optimistic opponent movement, one-at-a-time immediate opponent bombs; same frozen Q and fixed seed. No tuning or deployment on holdout.'}, indent=2))
    with ThreadPoolExecutor(max_workers=2) as pool:
        results = dict(pool.map(worker, ['q_final', 'q_sequence']))
    (OUT / 'results.json').write_text(json.dumps(results, indent=2))
    paired = {}
    for label in ['validation', 'holdout']:
        a, b = [[json.loads(line) for line in (OUT / name / f'{label}.rounds.jsonl').read_text().splitlines()]
                for name in ['q_final', 'q_sequence']]
        assert len(a) == len(b)
        assert all(x['map_hash'] == y['map_hash'] for x,y in zip(a,b))
        ix = np.random.default_rng(496).integers(len(a), size=(20000, len(a)))
        paired[label] = {}
        for key in ['score', 'win', 'survived']:
            d = np.array([float(y[key])-float(x[key]) for x,y in zip(a,b)])
            paired[label][key] = {'difference': float(d.mean()), 'interval95': np.quantile(d[ix].mean(axis=1), [.025,.975]).tolist()}
    (OUT / 'analysis.json').write_text(json.dumps(paired, indent=2))
    (OUT / 'status.json').write_text(json.dumps({'phase': 'complete'}))


if __name__ == '__main__':
    main()
