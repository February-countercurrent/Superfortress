"""Retrospective bomb/death attribution and public resource-inventory audit."""
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import pickle

import numpy as np

from analyze_urgent_scoring import round_frames, state_arrays
from agent_code.q_switch.features import ACTIONS, DELTAS, blast, describe
from agent_code.q_switch.dynamic import candidate_mask_with_status
from agent_code.q_switch.features import allowed
from agent_code.q_tactical.tactics import timeline, escape_branches
from diagnose_symavg_survival import stable_rows
from resource_inventory import CoinInventory

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'experiments/switch_failures_v1'
SOURCE = ROOT / 'experiments/pursuit_switch_v1'
NAME = 'q_switch'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def dump(path, data):
    path.write_text(json.dumps(data, indent=2, default=lambda v: v.item()), encoding='utf-8')


def actual_collision(frame):
    occupancy = {o[0]: tuple(o[3]) for o in frame['state']['others']}
    occupancy[NAME] = tuple(frame['state']['self'][3])
    for action in frame['actions']:
        if action['agent'] == NAME and action['action'] in ACTIONS[:4]:
            dx, dy = DELTAS[ACTIONS.index(action['action'])]
            target = action['before'][0] + dx, action['before'][1] + dy
            blockers = [n for n, p in occupancy.items() if n != NAME and p == target]
            return blockers if blockers and action['before'] == action['after'] else []
        occupancy[action['agent']] = tuple(action['after'])
    return []


def new_enemy_bombs(frame):
    return [dict(name=a['agent'], position=a['before'], step=frame['step'])
            for a in frame['actions'] if a['agent'] != NAME and 'BOMB_DROPPED' in a['events']]


def main():
    assert json.loads((OUT / 'status.json').read_text())['phase'] in ('replay_complete', 'complete')
    totals = defaultdict(Counter)
    bombs = []
    activations = []
    deaths = []
    locked = {}
    checked_states = 0
    paired_new_suicides = Counter()
    for arm in ('off', 'switch'):
        for scene in ('mixed', 'strong'):
            folder = OUT / arm / scene
            rows = stable_rows(folder / 'match.rounds.jsonl')
            original = stable_rows(SOURCE / arm / f'pilot_{scene}.rounds.jsonl')
            assert rows == original
            base_rows = {r['round']: r for r in stable_rows(SOURCE / 'off' / f'pilot_{scene}.rounds.jsonl')}
            traces = defaultdict(dict)
            with (folder / 'policy.trace.jsonl').open() as handle:
                for line in handle:
                    f = json.loads(line)
                    traces[f['round']][f['step']] = f
            by_round = {r['round']: r for r in rows}
            for number, frames in round_frames(folder / 'score_frames.jsonl.gz'):
                row = by_round[number]
                trace = traces[number]
                assert len(frames) == len(trace) == row['agents'][NAME]['steps']
                states = [state_arrays(f) for f in frames]
                # Trusted locally generated replay: hidden locations validate
                # the public estimate, never enter CoinInventory or any policy.
                replay_path = folder / f'replay_{number:03d}.pt'
                replay = pickle.loads(replay_path.read_bytes())
                all_coins = list(map(tuple, replay['coins']))
                assert len(all_coins) == 9
                inventory = CoinInventory(9)
                inventories = []
                for i, (f, state) in enumerate(zip(frames, states)):
                    assert f['step'] == i + 1
                    t = trace[f['step']]
                    assert f['chosen'] == t['action']
                    np.testing.assert_array_equal(f['candidate_mask'], t['candidate_mask'])
                    np.testing.assert_allclose(f['adjusted_q'], t['scores'], rtol=0, atol=1e-12)
                    inv = inventory.observe(state)
                    actual_hidden = sum(state['field'][p] == 1 for p in all_coins)
                    assert inv['hidden_exact'] == actual_hidden
                    inventories.append(inv)
                    checked_states += 1
                    if t['decision']['activated']:
                        a = t['decision']['commitment']
                        target = tuple(a['target'])
                        cells = set(blast(state['field'], target))
                        crates = int((state['field'] == 1).sum())
                        yield_here = sum(state['field'][p] == 1 for p in cells)
                        goal_hidden = sum(p in cells and state['field'][p] == 1 for p in all_coins)
                        rec = dict(arm=arm, scene=scene, round=number, step=f['step'], kind=a['kind'],
                                   target=list(target), inventory=inv, goal_crates=int(yield_here),
                                   expected_revealed_coins=(yield_here * inv['hidden_exact'] / crates if crates else 0.),
                                   actual_goal_hidden_coins=int(goal_hidden),
                                   original_distance=a['initial_distance'], won=row['win'])
                        activations.append(rec)
                        totals[arm]['activations'] += 1
                        totals[arm]['activation_' + a['kind']] += 1
                        if a['kind'] == 'crate':
                            totals[arm]['crate_activation_no_hidden'] += inv['no_hidden_coins']
                            totals[arm]['crate_activation_no_resource'] += inv['no_resource_coins']
                            totals[arm]['crate_activation_goal_actually_empty'] += goal_hidden == 0
                    if 'BOMB_DROPPED' not in f['events']:
                        continue
                    end = min(i + 6, len(frames))
                    events = Counter(e for later in frames[i:end] for e in later['events'])
                    branch = t['decision']['reason'] == 'resource_commitment'
                    mode = 'branch_forced' if branch and t['changed'] else 'branch_agreed' if branch else 'base'
                    rec = dict(arm=arm, scene=scene, round=number, placed=f['step'], mode=mode,
                               baseline_action=t['baseline_action'], position=f['state']['self'][3],
                               static_bomb_safe=bool(f['info']['safe'][5]), dynamic_bomb_allowed=bool(f['candidate_mask'][5]),
                               inventory=inv, resolved_observation=frames[-1]['step'] >= f['step'] + 5,
                               observed_crates=events['CRATE_DESTROYED'], observed_coins_found=events['COIN_FOUND'],
                               observed_kills=events['KILLED_OPPONENT'], observed_selfkill=events['KILLED_SELF'] > 0,
                               ray_enemies=f['info']['enemy_hits'], initial_crate_yield=f['info']['yield'])
                    bombs.append(rec)
                    for group in (arm, arm + '/' + mode):
                        c = totals[group]
                        c['bombs'] += 1
                        c['bombs_no_hidden'] += inv['no_hidden_coins']
                        c['resolved_bombs'] += rec['resolved_observation']
                        c['observed_selfkills'] += rec['observed_selfkill']
                        c['observed_crates'] += rec['observed_crates']
                        c['observed_coins_found'] += rec['observed_coins_found']
                        c['observed_kills'] += rec['observed_kills']
                if not frames[-1]['dead']:
                    continue
                final = frames[-1]
                suicide = 'KILLED_SELF' in final['events']
                own_lethal = [b for b in final['lethal'] if b['owner'] == NAME]
                assert bool(own_lethal) == suicide
                assert int(suicide) == row['agents'][NAME].get('suicides', 0)
                own_placed = own_lethal[0]['placed'] if own_lethal else None
                start_index = own_placed - 1 if own_placed is not None else max(0, len(frames) - 8)
                plant = frames[start_index]
                plant_trace = trace[plant['step']]
                plant_state = states[start_index]
                mode = ('branch_forced' if plant_trace['decision']['reason'] == 'resource_commitment' and plant_trace['changed']
                        else 'branch_agreed' if plant_trace['decision']['reason'] == 'resource_commitment' else 'base')
                path = []
                first_loss = None
                for i in range(start_index, len(frames)):
                    f = frames[i]
                    state = states[i]
                    info = {**f['info'], **{k: np.array(f['info'][k], dtype=bool)
                                           for k in ('safe', 'robust_safe', 'legal')}}
                    _, fallback = candidate_mask_with_status(state, info, allowed(info, True))
                    chosen = ACTIONS.index(f['chosen'])
                    entry = dict(step=f['step'], position=f['state']['self'][3], action=f['chosen'],
                                 after_position=f['after_position'], baseline_action=trace[f['step']]['baseline_action'],
                                 changed=trace[f['step']]['changed'], decision_reason=trace[f['step']]['decision']['reason'],
                                 static_safe_actions=[ACTIONS[j] for j, ok in enumerate(f['info']['safe']) if ok],
                                 chosen_static_safe=bool(f['info']['safe'][chosen]), dynamic_fallback=fallback,
                                 candidate_actions=[ACTIONS[j] for j, ok in enumerate(f['candidate_mask']) if ok],
                                 collision_with=actual_collision(f), new_enemy_bombs=new_enemy_bombs(f),
                                 post_safe_any=any(f['post_safe']) if 'post_safe' in f else None)
                    if first_loss is None and entry['chosen_static_safe'] and entry['post_safe_any'] is False and i + 1 < len(states):
                        following = states[i + 1]
                        new_positions = {tuple(b['position']) for b in entry['new_enemy_bombs']}
                        without_new = {**following, 'bombs': [(p, timer) for p, timer in following['bombs'] if p not in new_positions]}
                        first_loss = dict(step=f['step'], collision_with=entry['collision_with'],
                                          new_enemy_bombs=entry['new_enemy_bombs'],
                                          removing_new_bombs_restores_static_escape=bool(new_positions and describe(without_new)['safe'].any()))
                    path.append(entry)
                static_branches = None
                if suicide:
                    horizon = max([6, int(plant_state['explosion_map'].max())]
                                  + [t + 2 for _, t in plant_state['bombs']])
                    static_branches = escape_branches(plant_state, timeline(plant_state, True, horizon))
                rec = dict(arm=arm, scene=scene, round=number, death_step=final['step'], suicide=suicide,
                           original_same_map_suicide=bool(base_rows[number]['agents'][NAME].get('suicides', 0)),
                           final_win=row['win'], lethal=final['lethal'], own_bomb_placed=own_placed,
                           plant_mode=mode if suicide else None,
                           plant_inventory=inventories[start_index] if suicide else None,
                           static_escape_branches_at_plant=static_branches,
                           plant_baseline_action=plant_trace['baseline_action'] if suicide else None,
                           death_has_static_safe_action=any(final['info']['safe']),
                           death_collision=actual_collision(final), first_loss_of_escape=first_loss,
                           any_collision_since_plant=any(p['collision_with'] for p in path),
                           new_enemy_bombs_since_plant=[b for p in path for b in p['new_enemy_bombs']], path=path)
                deaths.append(rec)
                totals[arm]['deaths'] += 1
                if suicide:
                    totals[arm]['suicides'] += 1
                    totals[arm]['suicide_plant_' + mode] += 1
                    totals[arm]['suicide_no_static_safe_at_death'] += not rec['death_has_static_safe_action']
                    totals[arm]['suicide_with_collision'] += rec['any_collision_since_plant']
                    totals[arm]['suicide_with_new_enemy_bomb'] += bool(rec['new_enemy_bombs_since_plant'])
                    totals[arm]['suicide_plant_no_hidden'] += rec['plant_inventory']['no_hidden_coins']
                    totals[arm]['suicide_plant_branch_after_no_hidden'] += mode.startswith('branch_') and rec['plant_inventory']['no_hidden_coins']
                    if arm == 'switch':
                        paired_new_suicides['also_off_suicide' if rec['original_same_map_suicide'] else 'off_not_suicide'] += 1
            for name in ('match.rounds.jsonl', 'score_frames.jsonl.gz', 'policy.trace.jsonl'):
                locked[str((folder / name).relative_to(OUT))] = digest(folder / name)
    assert totals['off']['suicides'] == 8 and totals['switch']['suicides'] == 18
    assert checked_states == 41879 + 40377
    assert totals['switch']['activations'] == 159
    for arm in ('off', 'switch'):
        assert totals[arm]['observed_selfkills'] == totals[arm]['suicides']
    for name, data in (('bombs.json', bombs), ('activations.json', activations), ('deaths.json', deaths)):
        dump(OUT / name, data)
    result = dict(verified_replay=True, matches=240, observations=checked_states,
                  inventory_exact_vs_hidden_replay_on_all_observations=True,
                  totals={k: dict(v) for k, v in totals.items()}, paired_switch_suicides=dict(paired_new_suicides),
                  limitations=['Same matches replayed, not independent evaluation.',
                      'Bomb ownership/hidden positions used only for retrospective attribution and validation, never by public inventory.',
                      'Descriptive planting groups differ in state selection; observed selfkill rates are not causal treatment effects.',
                      'Removing newly placed enemy bombs tests a static geometric explanation, not a full counterfactual game.',
                      'Expected revealed coins is hidden_count * blast_crates / remaining_crates under the framework placement prior; it is not expected own score.'])
    dump(OUT / 'analysis.json', result)
    dump(OUT / 'analysis_verification.json', dict(verified=True, input_sha256=locked,
         source_sha256={p: digest(ROOT / p) for p in ('analyze_switch_failures.py', 'resource_inventory.py', 'test_resource_inventory.py',
                                                   'agent_code/q_tactical/tactics.py', 'agent_code/q_switch/features.py')},
         output_sha256={p: digest(OUT / p) for p in ('analysis.json', 'bombs.json', 'activations.json', 'deaths.json')}))
    dump(OUT / 'status.json', dict(phase='complete', replay_matches=240, new_matches=0, needs_review=True))
    print(json.dumps(result, indent=2, default=lambda v: v.item()))


if __name__ == '__main__':
    main()
