"""Check the three pre-recorded ambiguous-state example pairs, without fitting."""
import gzip
import json
from pathlib import Path
import numpy as np
from experiment_tree_fqi import read
from experiment_tree_fqi_batches import save
from finalize_guard_release import digest
from analyze_tree_attack import restore
from agent_code.tree_timed.timed import timed_key

ROOT=Path(__file__).resolve().parent
PRIOR=ROOT/'experiments/tree_attack_diagnosis_v1'


def main():
    examples=read(PRIOR/'analysis.json')['teacher']['identical_28_keys_with_different_escape']['examples']
    needed={(r['batch'],r['round'],r['step']) for pair in examples for r in pair};found={}
    for batch in sorted({k[0] for k in needed}):
        with gzip.open(PRIOR/f'replay/batch_{batch}_teacher/trace.jsonl.gz','rt',encoding='utf-8') as f:
            for line in f:
                r=json.loads(line);key=(batch,r['round'],r['step'])
                if key in needed:found[key]=timed_key(restore(r['decision']['state'])).tolist()
    result=[]
    for pair in examples:
        aa,bb=[found[r['batch'],r['round'],r['step']] for r in pair]
        np.testing.assert_array_equal(aa[:28],bb[:28])
        result.append(dict(states=[{k:r[k] for k in ('batch','round','step')} for r in pair],
            new_descriptors=[aa[28:],bb[28:]],separated=aa!=bb))
    save(ROOT/'experiments/tree_timed_v1/alias_examples_check.json',dict(verified=True,
        pre_recorded_pairs=len(result),separated=sum(r['separated'] for r in result),examples=result,
        source_analysis_sha256=digest(PRIOR/'analysis.json'),script_sha256=digest(Path(__file__))))
    print(result)


if __name__=='__main__':main()
