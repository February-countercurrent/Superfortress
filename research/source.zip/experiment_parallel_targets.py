"""Parallel-target representation pilot; reuse the exact matched control."""
import hashlib
import json
from pathlib import Path
import shutil
import sys
import numpy as np
from migrate_parallel_targets import migrate_file
import run_fighter_experiment as runner

ROOT=Path(__file__).resolve().parent
BASE=ROOT/'experiments/combined_training_v1'
OUT=ROOT/'experiments/parallel_targets_v1'
ARMS=['frozen900','control','targets']


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def analyze():
    summary=json.loads((OUT/'summary.json').read_text())
    rng=np.random.default_rng(147004); comparisons={}
    lines=['# Parallel target feature blocks','',
           '| Model | Mixed win | Strong win | Mixed score | Strong score |',
           '|---|---:|---:|---:|---:|']
    for arm in ARMS:
        a,b=[summary[f'{arm}_eval_{s}'] for s in ['mixed','strong']]
        lines.append(f"| {arm} | {a['strict_win_rate']:.1%} | {b['strict_win_rate']:.1%} | {a['mean_score']:.2f} | {b['mean_score']:.2f} |")
    for scene in ['mixed','strong']:
        rows={arm:[json.loads(x) for x in (OUT/arm/f'eval_{scene}.rounds.jsonl').read_text().splitlines()] for arm in ARMS}
        candidate=rows['targets']; comparisons[scene]={}
        assert len(candidate)==60
        for baseline in ['control','frozen900']:
            old=rows[baseline]; assert len(old)==60
            assert [r['map_hash'] for r in old]==[r['map_hash'] for r in candidate]
            ix=rng.integers(0,60,(10000,60)); metrics={}
            for key in ['win','score','survived','coins','crates','kills','suicides']:
                def value(row,agent):
                    return row[key] if key in ['win','score','survived'] else row['agents'][agent].get(key,0)
                d=np.array([float(value(b,'q_targets'))-float(value(a,'q_dynamic')) for a,b in zip(old,candidate)])
                metrics[key]=dict(difference=float(d.mean()),paired_map_95ci=np.percentile(d[ix].mean(axis=1),[2.5,97.5]).tolist())
            comparisons[scene][baseline]=metrics
    comparisons['limitation']='Single training seed, reused development maps, 60 rounds per scene. Feature expansion changes representation and gradient allocation; total step normalized. No automatic promotion.'
    (OUT/'comparison.json').write_text(json.dumps(comparisons,indent=2))
    (OUT/'RESULTS.md').write_text('\n'.join(lines+['',comparisons['limitation']])+'\n',encoding='utf-8')


def main():
    assert json.loads((BASE/'status.json').read_text())['phase']=='complete'
    baseline_config=json.loads((BASE/'config.json').read_text())
    source=ROOT/'experiments/multistep_v1/multistep/model.json'
    source_hash=digest(source)
    assert baseline_config['source_hashes'][str(source)]==source_hash
    assert baseline_config['training_seed']==137001
    for path in (ROOT/'agent_code/q_dynamic').glob('*.py'):
        assert digest(path)==digest(BASE/'workspace/agent_code/q_dynamic'/path.name),path.name
    OUT.mkdir(parents=True,exist_ok=False)
    workspace=OUT/'workspace'
    shutil.copytree(ROOT,workspace,ignore=shutil.ignore_patterns('.git','experiments','release','logs','__pycache__'))
    (workspace/'logs').mkdir(exist_ok=True); runner.ROOT=workspace
    baseline_summary=json.loads((BASE/'summary.json').read_text()); results={}
    baseline_hashes={}
    for arm in ['frozen900','control']:
        folder=OUT/arm; folder.mkdir()
        for name in ['model.json','eval_mixed.json','eval_mixed.rounds.jsonl','eval_strong.json','eval_strong.rounds.jsonl']:
            original=BASE/arm/name
            shutil.copy2(original,folder/name)
            baseline_hashes[str(original)]=digest(original)
        for scene in ['mixed','strong']:
            results[f'{arm}_eval_{scene}']=baseline_summary[f'{arm}_eval_{scene}']
    folder=OUT/'targets'; folder.mkdir()
    snapshots=folder/'checkpoints'; snapshots.mkdir()
    model=folder/'model.json'; migrate_file(source,model)
    shutil.copy2(model,folder/'initial_model.json')
    env={**baseline_config['environment'],'QL_OPPONENT_POOL':'mixed','QL_SNAPSHOT_DIR':str(snapshots)}
    (OUT/'config.json').write_text(json.dumps(dict(source=str(source),source_sha256=source_hash,
        baseline=str(BASE),baseline_locked_sha256=baseline_hashes,environment=env,
        training_seed=137001,additional_rounds=150,evaluation_seeds=[137002,137003],evaluation_rounds=60,
        python=sys.version,numpy=np.__version__,
        design='V5 to V7 migration retains legacy seven blocks and all Q values; adds four zero-initialized blocks, total 32 features. Both target and control share raw 16-key visit schedule, rewards, dynamic masks, D4 averaging, three-step tree backup and all-mixed curriculum. Normalize updates by 11 active blocks. Reuse exact control and frozen-reference evaluations.',
        limitation='Legacy target features and shaping remain; this adds parallel information, not removal of every legacy target preference. Distances use static current occupancy, not guaranteed safe routes. Development maps, single seed.'),indent=2))
    (OUT/'summary.json').write_text(json.dumps(results,indent=2))
    try:
        (OUT/'status.json').write_text(json.dumps(dict(phase='targets_training')))
        results['targets_training']=runner.run(folder,'training',model,
            ['rule_based_agent','training_coin_pool','training_peace_pool'],150,137001,
            train=True,agent='q_targets',environment=env)
        data=json.loads(model.read_text()); initial=json.loads(source.read_text())
        assert data['version']==7 and data['episodes']==1050
        assert data['config']['n_step']==3 and data['config']['symmetry'] and data['config']['bootstrap_dynamic']
        assert all(len(k.split(','))==16 for k in data['visits'])
        assert all(np.isfinite(v).all() for v in data['q'].values())
        visits=lambda d:sum(sum(v) for v in d['visits'].values())
        assert visits(data)-visits(initial)==json.loads(model.with_suffix('.backup_metrics.json').read_text())['updates']
        model_hash=digest(model)
        (OUT/'summary.json').write_text(json.dumps(results,indent=2))
        for scene,opponents,seed in [('mixed',['rule_based_agent','coin_collector_agent','peaceful_agent'],137002),('strong',['rule_based_agent']*3,137003)]:
            key=f'targets_eval_{scene}'
            (OUT/'status.json').write_text(json.dumps(dict(phase=key)))
            results[key]=runner.run(folder,f'eval_{scene}',model,opponents,60,seed,agent='q_targets')
            assert digest(model)==model_hash
            (OUT/'summary.json').write_text(json.dumps(results,indent=2))
        assert digest(source)==source_hash
        assert all(digest(Path(p))==h for p,h in baseline_hashes.items())
        (OUT/'status.json').write_text(json.dumps(dict(phase='analyzing')))
        analyze()
        (OUT/'status.json').write_text(json.dumps(dict(phase='complete')))
    except Exception as exc:
        (OUT/'status.json').write_text(json.dumps(dict(phase='failed',error=repr(exc))))
        raise


if __name__=='__main__':
    main()
