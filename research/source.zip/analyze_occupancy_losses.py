"""Whole-cohort kill-credit timing and fixed condition coverage; descriptive."""
from collections import Counter, defaultdict
import gzip
import json

import numpy as np

from occupancy_experiment import ROOT, ARMS, SCENES, read, save, rows, digest
from agent_code.q_guard.features import describe, allowed, blast, ACTIONS
from agent_code.q_guard.dynamic import candidate_mask_with_status
from agent_code.q_guard_options.options import threat_arrival

OUT = ROOT / 'experiments/occupancy_loss_audit_v1'
SOURCE = ROOT / 'experiments/occupancy_escape_v1'


def frames_by_round(path):
    number, batch = None, []
    with gzip.open(path, 'rt', encoding='utf-8') as handle:
        for line in handle:
            f = json.loads(line)
            if number is not None and number != f['round']:
                yield number, batch
                batch = []
            number = f['round']
            batch.append(f)
    if batch:
        yield number, batch


def arrays(s):
    return {**s, 'field': np.array(s['field']), 'explosion_map': np.array(s['explosion_map']),
        'self': (*s['self'][:3], tuple(s['self'][3])), 'bombs': [(tuple(p), t) for p, t in s['bombs']],
        'others': [(*o[:3], tuple(o[3])) for o in s['others']], 'coins': [tuple(p) for p in s['coins']]}


def conditions(f, trace):
    s = arrays(f['state'])
    info = describe(s)
    _, fallback = candidate_mask_with_status(s, info, allowed(info, True))
    arrival = threat_arrival(s)
    chosen = ACTIONS.index(trace['action'])
    tied = chosen in trace['baseline_best']
    return dict(original_best=trace['baseline_best'], original_action=trace['baseline_action'], action=trace['action'],
        keeps_best_q=tied, q_loss=float(max(trace['scores'][i] for i in trace['baseline_best']) - trace['scores'][chosen]),
        dynamic_fallback=bool(fallback), threat_arrival=arrival, imminent=arrival is not None and arrival <= 1,
        selects_wait=chosen == 4)


def main():
    verified = read(OUT / 'replay_verification.json')
    assert verified['verified']
    assert all(digest(OUT / p) == h for p, h in verified['raw_sha256'].items())
    pairs = {(r['scene'], r['round']): r for r in read(SOURCE / 'paired_divergence_audit.json')['rounds']}
    arm_totals, details, conditions_all, first_conditions = {}, {}, [], {}
    for arm, agent in ARMS.items():
        total = Counter()
        details[arm] = {}
        for scene in SCENES:
            matches = {r['round']: r for r in rows(OUT / arm / scene / 'match.rounds.jsonl')}
            traces = {(r['round'], r['step']): r for r in rows(OUT / arm / scene / 'policy.trace.jsonl')}
            for number, frames in frames_by_round(OUT / arm / scene / 'frames.jsonl.gz'):
                row = matches[number]
                assert len(frames) == row['steps']
                first = pairs[scene, number]['first_divergence']
                first_step = first['step'] if first else 401
                count, credits = Counter(), []
                for f in frames:
                    assert f['step'] <= row['steps']
                    total['world_steps'] += 1
                    for hit in f['hits']:
                        if hit['owner'] != agent:
                            continue
                        if hit['suicide']:
                            count['suicides'] += 1
                        else:
                            count['kills'] += 1
                            timing = 'before_divergence' if f['step'] < first_step else \
                                     'existing_bomb_after_divergence' if hit['placed'] < first_step else 'new_bomb_after_divergence'
                            count['kills_' + timing] += 1
                            credits.append(dict(step=f['step'], timing=timing, **hit))
                    if f['state'] is not None:
                        total['observations'] += 1
                        t = traces[number, f['step']]
                        own = next(a for a in f['actions'] if a['agent'] == agent)
                        assert own['action'] == t['action']
                        count['steps'] += 1
                        if f['step'] >= first_step:
                            count['post_divergence_steps'] += 1
                            count['post_divergence_opponent_steps'] += bool(f['state']['others'])
                        if 'BOMB_DROPPED' in own['events']:
                            count['bombs'] += 1
                            if f['step'] >= first_step:
                                count['post_divergence_bombs'] += 1
                                s = arrays(f['state'])
                                ray = blast(s['field'], s['self'][3])
                                hits = sum(o[3] in ray for o in s['others'])
                                count['post_divergence_attack_bombs'] += hits > 0
                        if arm == 'occupancy' and t['occupancy']['changed']:
                            detail = dict(scene=scene, round=number, step=f['step'], **conditions(f, t))
                            conditions_all.append(detail)
                            if f['step'] == first_step:
                                first_conditions[scene, number] = detail
                assert count['kills'] == row['agents'][agent].get('kills', 0)
                assert count['suicides'] == row['agents'][agent].get('suicides', 0)
                assert count['steps'] == row['agents'][agent]['steps']
                assert frames[-1]['after'][agent]['score'] == row['score']
                total.update(count)
                details[arm][scene + '_' + str(number)] = dict(counts=dict(count), credits=credits,
                    score=row['score'], win=row['win'], survived=row['survived'])
            print(arm, scene, dict(total), flush=True)
        arm_totals[arm] = dict(total)
    rows_out, groups = [], defaultdict(Counter)
    for (scene, number), pair in pairs.items():
        key = scene + '_' + str(number)
        a, b = details['control'][key], details['occupancy'][key]
        delta = {k: b['counts'].get(k, 0) - a['counts'].get(k, 0) for k in
            ('kills', 'kills_before_divergence', 'kills_existing_bomb_after_divergence', 'kills_new_bomb_after_divergence')}
        assert delta['kills_before_divergence'] == 0
        assert delta['kills'] == sum(delta[k] for k in delta if k != 'kills')
        c = first_conditions.get((scene, number))
        record = dict(**pair, kill_differences=delta, first_conditions=c)
        rows_out.append(record)
        if c:
            labels = ['same_q' if c['keeps_best_q'] else 'lower_q',
                'dynamic_fallback' if c['dynamic_fallback'] else 'dynamic_not_fallback',
                'imminent' if c['imminent'] else 'not_imminent', 'wait' if c['selects_wait'] else 'move']
            for label in labels:
                g = groups[label]
                g['pairs'] += 1
                g['win_difference'] += int(b['win']) - int(a['win'])
                g['score_difference'] += b['score'] - a['score']
                g['kill_difference'] += delta['kills']
                g['suicide_difference'] += b['counts'].get('suicides', 0) - a['counts'].get('suicides', 0)
    coverage = {key: sum(bool(r[key]) for r in conditions_all)
                for key in ('keeps_best_q', 'dynamic_fallback', 'imminent', 'selects_wait')}
    result = dict(verified=True, replay_matches=240, new_matches=0, arm_totals=arm_totals,
        first_divergence_groups={k: dict(v) for k, v in groups.items()}, all_changed_actions=len(conditions_all),
        condition_coverage=coverage, changes=conditions_all, rounds=rows_out, round_details=details,
        limitations=['Timing decomposition is descriptive; surviving position and opponent responses are not isolated causal mechanisms.',
            'Group results condition on first changes in an existing tested policy; they are not performance estimates for newly gated policies.',
            'Counts of bombs with an enemy in the observed blast ray measure attack exposure, not guaranteed or equally difficult kill opportunities.'])
    save(OUT / 'analysis.json', result)
    save(OUT / 'status.json', dict(phase='complete', needs_review=True))
    print(json.dumps({k: result[k] for k in ('arm_totals', 'first_divergence_groups', 'condition_coverage')}, indent=2))


if __name__ == '__main__':
    main()
