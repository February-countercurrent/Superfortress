"""Fixed first 40 mixed holdout maps: three dynamic checkpoints and final."""
import json
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'experiments/resource_diagnosis_v1'


def main():
    OUT.mkdir(parents=True, exist_ok=False)
    workspace = OUT / 'workspace'
    shutil.copytree(ROOT, workspace, ignore=shutil.ignore_patterns('.git', 'experiments', 'release', 'logs', '__pycache__'))
    (workspace / 'logs').mkdir(exist_ok=True)
    (OUT / 'config.json').write_text(json.dumps(dict(rounds=40, seed=57002,
        checkpoints=[27001, 28001, 29001], training=False,
        sampling='First 40 maps, chosen without filtering by outcome; reuses prior holdout for diagnosis, not new independent validation.'), indent=2))
    try:
        for label, agent, source in [('final', 'q_final', ROOT / 'agent_code/q_final/model.json')] + [
            (f'seed_{s}', 'q_dynamic', ROOT / f'experiments/dynamic_holdout_v1/seed_{s}/model.json') for s in [27001, 28001, 29001]]:
            (OUT / 'status.json').write_text(json.dumps(dict(phase=label)))
            command = [sys.executable, str(workspace / 'diagnose_fighter.py'), '--agent', agent,
                '--model', str(source), '--output', str(OUT / label), '--rounds', '40', '--seed', '57002',
                '--score-details', '--opponents', 'rule_based_agent', 'coin_collector_agent', 'peaceful_agent']
            with (OUT / f'{label}.log').open('w') as log:
                subprocess.run(command, cwd=workspace, stdout=log, stderr=subprocess.STDOUT, check=True)
        (OUT / 'status.json').write_text(json.dumps(dict(phase='analyzing')))
        from analyze_resources import main as analyze
        analyze()
        (OUT / 'status.json').write_text(json.dumps(dict(phase='complete')))
    except Exception as exc:
        (OUT / 'status.json').write_text(json.dumps(dict(phase='failed', error=repr(exc))))
        raise


if __name__ == '__main__':
    main()
