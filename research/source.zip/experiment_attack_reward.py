"""Fixed-budget attack reward ablation, with a predeclared holdout gate."""
import argparse
import csv
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys

import numpy as np
import run_fighter_experiment as runner

ROOT=Path(__file__).resolve().parent
AGENT='q_reward'
OPPONENTS={'mixed':['rule_based_agent','coin_collector_agent','peaceful_agent'],
           'strong':['rule_based_agent']*3}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path,content):
    temp=path.with_suffix('.tmp')
    temp.write_text(json.dumps(content,indent=2),encoding='utf-8')
    temp.replace(path)


def compare(output,stage,arms,candidate='outcome'):
    rows={}; measurements={}; comparisons={}
    for arm in arms:
        measurements[arm]={}
        for scene in OPPONENTS:
            path=output/arm/f'{stage}_{scene}.rounds.jsonl'
            values=[json.loads(line) for line in path.read_text().splitlines()]
            rows[arm,scene]=values
            assert [r['map_hash'] for r in values]==[r['map_hash'] for r in rows[arms[0],scene]]
            measurements[arm][scene]={metric:float(np.mean([
                r[metric] if metric in ('win','score','survived') else r['agents'][AGENT].get(metric,0)
                for r in values])) for metric in ('win','score','survived','suicides','coins','kills')}
        measurements[arm]['combined']={m:float(np.mean([measurements[arm][s][m] for s in OPPONENTS]))
                                       for m in measurements[arm]['mixed']}
    rng=np.random.default_rng(197004 if stage=='pilot' else 197104)
    for reference in [a for a in arms if a!=candidate]:
        by_scene={}; boot={}; deltas={}
        for scene in OPPONENTS:
            a,b=rows[reference,scene],rows[candidate,scene]
            assert len(a)==len(b)
            indices=rng.integers(0,len(a),(10000,len(a)))
            by_scene[scene]={}
            for metric in measurements[reference][scene]:
                def get(r):
                    return float(r[metric] if metric in ('win','score','survived') else r['agents'][AGENT].get(metric,0))
                d=np.array([get(y)-get(x) for x,y in zip(a,b)])
                samples=d[indices].mean(axis=1)
                deltas[scene,metric]=float(d.mean()); boot[scene,metric]=samples
                by_scene[scene][metric]=dict(difference=float(d.mean()),paired_map_95ci=np.percentile(samples,[2.5,97.5]).tolist())
        by_scene['combined']={m:dict(difference=float(np.mean([deltas[s,m] for s in OPPONENTS])),
            paired_map_95ci=np.percentile(sum(boot[s,m] for s in OPPONENTS)/2,[2.5,97.5]).tolist())
            for m in measurements[reference]['mixed']}
        comparisons[candidate+'_minus_'+reference]=by_scene
    result=dict(stage=stage,candidate=candidate,measurements=measurements,comparisons=comparisons,
        limitation='Single continuation seed. Maps paired within scenes; trajectories diverge. Pilot selects whether to run untouched holdout. Bootstrap intervals are exploratory, not multiplicity-corrected across future experiments.')
    save(output/f'{stage}_comparison.json',result)
    return result


def holdout_gate(result):
    m=result['measurements']; candidate=m[result.get('candidate','outcome')]; frozen=m['frozen']; control=m['original']
    checks=dict(
        win_gain_vs_frozen=candidate['combined']['win']>=frozen['combined']['win']+.025-1e-12,
        win_at_least_control=candidate['combined']['win']>=control['combined']['win']-1e-12,
        score_not_materially_lower=candidate['combined']['score']>=.95*max(frozen['combined']['score'],control['combined']['score']),
        no_scene_win_drop_over_5pp=all(candidate[s]['win']>=frozen[s]['win']-.05-1e-12 for s in OPPONENTS),
        suicide_increase_at_most_2p5pp=candidate['combined']['suicides']<=frozen['combined']['suicides']+.025+1e-12)
    return dict(qualifies=all(checks.values()),checks=checks)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--name',default='attack_reward_v1')
    parser.add_argument('--train-rounds',type=int,default=150)
    parser.add_argument('--eval-rounds',type=int,default=60)
    parser.add_argument('--holdout-rounds',type=int,default=100)
    parser.add_argument('--seed',type=int,default=197001)
    parser.add_argument('--candidate-mode',choices=['outcome','progress_only'],default='outcome')
    parser.add_argument('--reuse-controls',type=Path)
    args=parser.parse_args()
    arms=('frozen','original',args.candidate_mode)
    assert args.train_rounds>0 and args.eval_rounds>0 and args.holdout_rounds>0
    assert Path(args.name).name==args.name and args.name not in ('.','..')
    output=ROOT/'experiments'/args.name
    manifest=json.loads((ROOT/'CURRENT_CANDIDATE.json').read_text())
    assert manifest['agent']=='q_urgent'
    source=ROOT/manifest['model']; source_hash=digest(source)
    assert source_hash==manifest['model_sha256']
    initial=json.loads(source.read_text())
    assert initial['episodes']==1150
    env={**json.loads((ROOT/'experiments/target_learning_curve_v1/config.json').read_text())['environment'],
         'QF_EPSILON':'.05','QL_SNAPSHOT_DIR':'','BM_TRACK_COLLISIONS':'1'}
    output.mkdir(parents=True,exist_ok=False)
    workspace=output/'workspace'
    shutil.copytree(ROOT,workspace,ignore=shutil.ignore_patterns('.git','experiments','release','logs','__pycache__'))
    (workspace/'logs').mkdir(exist_ok=True); runner.ROOT=workspace
    files=list((workspace/'agent_code/q_reward').glob('*.py'))
    files += [workspace/name for name in ('run_fighter_match.py','run_fighter_experiment.py','environment.py','settings.py')]
    locked={str(p.relative_to(workspace)):digest(p) for p in files}
    config=dict(source=str(source),source_sha256=source_hash,initial_episodes=1150,
        train_rounds_each=args.train_rounds,pilot_rounds_each=args.eval_rounds,holdout_rounds_each=args.holdout_rounds,
        train_seed=args.seed,pilot_seeds=[args.seed+1,args.seed+2],holdout_seeds=[args.seed+101,args.seed+102],
        environment=env,arms=list(arms),candidate_mode=args.candidate_mode,locked_sha256=locked,
        started_at=datetime.now(timezone.utc).isoformat(),
        change='Remove attack-target progress; '+('also remove immediate ray-coverage bomb bonus.' if args.candidate_mode=='outcome' else 'retain immediate ray-coverage bomb bonus.')+' Preserve event rewards and resource shaping.',
        shared_behavior='All arms deploy accepted D4-average urgent policy. Both training arms now also use that policy with epsilon .05; raw-Q off-policy tree backup remains unchanged.',
        holdout_gate='Candidate combined win >= frozen +2.5pp and >= continued control; score >=95% of max controls; no scene win drop >5pp; combined suicide increase <=2.5pp.',
        selection='Fixed final checkpoint; do not select intermediate checkpoints using pilot maps. No automatic promotion by this script.')
    if args.reuse_controls:
        previous=args.reuse_controls.resolve()
        old=json.loads((previous/'config.json').read_text())
        assert old['source_sha256']==source_hash and old['environment']==env
        assert old['train_seed']==args.seed and old['train_rounds_each']==args.train_rounds
        assert old['pilot_rounds_each']==args.eval_rounds
        assert json.loads((previous/'verification.json').read_text())['verified']
        assert not (previous/'holdout_comparison.json').exists(), 'Holdout must still be untouched'
        for p,h in locked.items():
            if p.startswith('agent_code') and not p.endswith('train.py'):
                assert old['locked_sha256'][p]==h
        config['reused_controls']=str(previous)
        config['reuse_note']='Frozen and original control are exact archived runs with the same source, budget, seeds and behavior. New trainer original mode regression-tested; only additional candidate reward mode added. Pilot maps are now development maps.'
    save(output/'config.json',config)
    save(output/'process.json',dict(pid=os.getpid(),started_at=config['started_at']))
    results={}
    def status(phase,**extra):
        save(output/'status.json',dict(phase=phase,updated_at=datetime.now(timezone.utc).isoformat(),pid=os.getpid(),**extra))
    def record(arm,label,model,opponents,rounds,seed,training=False):
        status(f'{arm}_{label}',rounds=rounds)
        results[f'{arm}_{label}']=runner.run(output/arm,label,model,opponents,rounds,seed,
            train=training,agent=AGENT,environment={**env,'QL_ATTACK_SHAPING':arm if arm!='frozen' else 'original'})
        save(output/'summary.json',results)
    try:
        for arm in arms:
            if args.reuse_controls and arm in ('frozen','original'):
                old_results=json.loads((previous/'summary.json').read_text())
                shutil.copytree(previous/arm,output/arm)
                for key,value in old_results.items():
                    if key.startswith(arm+'_'): results[key]=value
                save(output/'summary.json',results)
                continue
            folder=output/arm; folder.mkdir()
            model=folder/'model.json'; shutil.copy2(source,model)
            if arm!='frozen':
                record(arm,'training',model,['rule_based_agent','training_coin_pool','training_peace_pool'],
                       args.train_rounds,args.seed,True)
                data=json.loads(model.read_text())
                assert data['episodes']==1150+args.train_rounds
                assert data['config']['attack_shaping']==arm
                assert data['config']['symmetry'] and data['config']['bootstrap_dynamic'] and data['config']['n_step']==3
                assert data['config']['behavior_policy']=='d4_average_urgent_escape'
                assert all(np.isfinite(v).all() for v in data['q'].values())
                visits=lambda d:sum(sum(v) for v in d['visits'].values())
                assert visits(data)-visits(initial)==json.loads(model.with_suffix('.backup_metrics.json').read_text())['updates']
                with model.with_suffix('.csv').open(newline='') as handle: training=list(csv.DictReader(handle))
                assert len(training)==args.train_rounds
                assert [int(r['episode']) for r in training]==list(range(1151,1151+args.train_rounds))
                assert all(float(r['epsilon'])==.05 for r in training)
            trained_hash=digest(model)
            for index,(scene,opponents) in enumerate(OPPONENTS.items()):
                record(arm,'pilot_'+scene,model,opponents,args.eval_rounds,args.seed+1+index)
            assert digest(model)==trained_hash
        pilot=compare(output,'pilot',list(arms),args.candidate_mode)
        gate=holdout_gate(pilot); save(output/'holdout_gate.json',gate)
        if gate['qualifies']:
            for arm in arms:
                model=output/arm/'model.json'; trained_hash=digest(model)
                for index,(scene,opponents) in enumerate(OPPONENTS.items()):
                    record(arm,'holdout_'+scene,model,opponents,args.holdout_rounds,args.seed+101+index)
                assert digest(model)==trained_hash
            compare(output,'holdout',list(arms),args.candidate_mode)
        assert digest(source)==source_hash
        assert all(digest(workspace/p)==h for p,h in locked.items())
        save(output/'verification.json',dict(verified=True,source_unchanged=True,snapshot_hashes_match=True,
            model_sha256={a:digest(output/a/'model.json') for a in arms},
            pilot_maps_paired=True,holdout_run=gate['qualifies'],training_updates_and_epsilon_verified=True))
        lines=['# Attack reward continuation','', '| Stage | Arm | Mixed win | Strong win | Combined win | Mean score | Suicide |',
               '|---|---|---:|---:|---:|---:|---:|']
        for stage in ('pilot','holdout'):
            path=output/f'{stage}_comparison.json'
            if not path.exists(): continue
            for arm,m in json.loads(path.read_text())['measurements'].items():
                c=m['combined']
                lines.append(f"| {stage} | {arm} | {m['mixed']['win']:.1%} | {m['strong']['win']:.1%} | {c['win']:.1%} | {c['score']:.3f} | {c['suicides']:.1%} |")
        lines+=['','Holdout gate: '+str(gate['qualifies']), '',pilot['limitation']]
        (output/'RESULTS.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
        status('complete',holdout_run=gate['qualifies'],needs_review=True)
    except Exception as exc:
        status('failed',error=repr(exc))
        raise


if __name__=='__main__':
    main()
