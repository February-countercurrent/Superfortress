"""Audit immediate training rewards on frozen evaluation trajectories.

These are counterfactual training rewards, not actual evaluation scores or
training updates. No policy or checkpoint is modified. The decomposition is
checked against the reward path in the checkpoint's original trainer.
"""
from collections import Counter, defaultdict
import hashlib
import json
from types import SimpleNamespace

import numpy as np

from analyze_urgent_scoring import ROOT, OUT, round_frames, state_arrays
from agent_code.q_dynamic import train
from agent_code.q_urgent.features import ACTIONS


def components(frame, config):
    info, action, events = frame['info'], frame['chosen'], frame['events']
    assert config['shaping'] == 0
    result = dict(
        coins=8*events.count('COIN_COLLECTED'),
        crates=events.count('CRATE_DESTROYED'),
        coin_found=.5*events.count('COIN_FOUND'),
        kills=15*events.count('KILLED_OPPONENT'),
        bomb_cost=-.2*events.count('BOMB_DROPPED'),
        invalid=-events.count('INVALID_ACTION'),
        death=-config['death_penalty']*int('GOT_KILLED' in events or 'KILLED_SELF' in events),
        step=-.03, progress=0., bomb_crate=0., bomb_attack=0., empty_bomb=0., wait=0.)
    if not info['threatened'] and info['target']:
        if action in ACTIONS[:4]:
            result['progress'] = config['progress']*info['progress'][ACTIONS.index(action)]
        elif action == 'WAIT' and info['distance']>0:
            result['progress'] = -config['progress']
    if action == 'BOMB':
        if info['safe'][5]:
            result['bomb_crate'] = .5*min(info['yield'],3)
            result['bomb_attack'] = 1.5*info['enemy_hits']
        if info['yield']==0 and info['enemy_hits']==0:
            result['empty_bomb'] = -1.
    if action=='WAIT' and not info['threatened']:
        result['wait'] = -.2
    return result


def verify_reward(frame, config, expected):
    # Disposable empty weights; new=None does not affect immediate reward
    # because this checkpoint's potential-shaping coefficient is zero.
    dummy = SimpleNamespace(**{k:config[k] for k in
        ('gamma','shaping','progress','death_penalty','alpha','rate_scale')},
        anticipate=False, attack_features=False, q={}, visits={},
        n_step=1, symmetry=False, counts=Counter(), total_reward=0.)
    train.update(dummy,state_arrays(frame),frame['chosen'],None,frame['events'])
    np.testing.assert_allclose(dummy.total_reward,expected,rtol=0,atol=1e-12)


def main():
    manifest = json.loads((ROOT/'CURRENT_CANDIDATE.json').read_text())
    config = manifest['training_config']
    origin = ROOT/'experiments/target_learning_curve_v1/workspace/agent_code/q_dynamic/train.py'
    if not origin.exists():
        # The learning-curve run keeps each branch in its own workspace.
        options = list((ROOT/'experiments/target_learning_curve_v1').glob('**/agent_code/q_dynamic/train.py'))
        assert options, 'Original training source must be present'
        origin = options[0]
    assert origin.read_bytes()==(ROOT/'agent_code/q_dynamic/train.py').read_bytes()
    groups = defaultdict(Counter); records = []; checked = 0; examples = []
    for scene in ('mixed','strong'):
        analysis = json.loads((OUT/scene/'scoring_analysis.json').read_text())
        rows = {r['round']:r for r in analysis['survivor_rounds']}
        for number,frames in round_frames(OUT/scene/'score_frames.jsonl.gz'):
            if number not in rows:
                continue
            row = rows[number]; group = row['category']
            all_reward = Counter(); late_reward = Counter(); no_resource_reward = Counter()
            bombs=[]; latest=None; late_steps=0; no_resource_steps=0
            late_progress_targets=Counter()
            for f in frames:
                parts = components(f,config)
                reward = sum(parts.values())
                all_reward.update(parts)
                if (f['step']-1)%100==0:
                    verify_reward(f,config,reward); checked+=1
                if f['step']>200:
                    late_steps+=1; late_reward.update(parts)
                    late_progress_targets[str(f['info']['target'])]+=parts['progress']
                    if not f['state']['coins'] and f['crates_remaining']==0:
                        no_resource_steps+=1; no_resource_reward.update(parts)
                if 'BOMB_DROPPED' in f['events']:
                    latest=dict(step=f['step'],ray=f['info']['enemy_hits']>0,
                        declared_yield=f['info']['yield'],reward=reward,attack_bonus=parts['bomb_attack'],
                        kills=0,crates=0,coin_found=0,detonated=None)
                    bombs.append(latest)
                if latest is not None:
                    latest['kills']+=f['events'].count('KILLED_OPPONENT')
                    latest['crates']+=f['events'].count('CRATE_DESTROYED')
                    latest['coin_found']+=f['events'].count('COIN_FOUND')
                    if 'BOMB_EXPLODED' in f['events']:
                        latest['detonated']=f['step']
            import settings
            c=groups[group]
            for b in bombs:
                if b['detonated'] is None or b['detonated']+settings.EXPLOSION_TIMER-1>frames[-1]['step']:
                    continue
                if b['ray'] and not b['kills']:
                    c['resolved_ray_misses']+=1
                    c['ray_miss_attack_bonus']+=b['attack_bonus']
                    if not b['crates'] and not b['coin_found']:
                        c['ray_misses_no_crates_or_revealed_coins']+=1
                        c['empty_ray_miss_attack_bonus']+=b['attack_bonus']
                        c['empty_ray_miss_positive_plant_reward']+=int(b['reward']>0)
            no_score = late_steps>0 and row['counters'].get('late_score',0)==0
            if no_score:
                c['no_score_late_rounds']+=1
                c['no_score_late_positive_reward_rounds']+=int(sum(late_reward.values())>1e-9)
                for k,v in late_reward.items(): c['no_score_late_reward_'+k]+=v
                for k,v in late_progress_targets.items(): c['no_score_late_progress_target_'+k]+=v
            record=dict(scene=scene,round=number,category=group,score=row['own_score'],
                leader_score=row['leader_score'],last_score_step=row['last_score_step'],
                late_steps=late_steps,late_score=row['counters'].get('late_score',0),
                late_reward=sum(late_reward.values()),late_reward_components=dict(late_reward),
                late_progress_by_target=dict(late_progress_targets),
                no_resource_late_steps=no_resource_steps,
                no_resource_late_reward=sum(no_resource_reward.values()),
                no_resource_late_reward_components=dict(no_resource_reward))
            records.append(record)
            if group=='alive_loss' and no_score:
                examples.append(record)
    result=dict(
        definition='Immediate rewards reconstructed using the original trainer and checkpoint config on frozen evaluation trajectories. Not observed training returns, not discounted returns, not Q values, and no model updates.',
        trainer_source=str(origin.relative_to(ROOT)),trainer_sha256=hashlib.sha256(origin.read_bytes()).hexdigest(),
        rewards_verified_against_trainer=checked,groups={g:dict(c) for g,c in groups.items()},
        no_score_alive_loss_examples=sorted(examples,key=lambda r:r['late_reward'],reverse=True)[:5],
        rounds=records,
        limitations='Descriptions on outcome-selected games do not establish that removing reward improves win rate. Bomb misses may still have positional value. This audit has no alternate-policy counterfactual.')
    (OUT/'reward_audit.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k!='rounds'},indent=2))


if __name__=='__main__':
    main()
