"""Matched continuation: adopted symmetry Q baseline versus three-step greedy tree backup."""
import hashlib
import json
from pathlib import Path
import shutil
import sys
import numpy as np
from experiment_linear import ENV
import run_fighter_experiment as runner

ROOT = Path(__file__).resolve().parent
OUT = ROOT/'experiments/multistep_v1'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def analyze():
    summary = json.loads((OUT/'summary.json').read_text())
    rng = np.random.default_rng(107004)
    report = {}
    lines = ['# Three-step greedy tree backup', '',
             '| Scene | Control win | Three-step win | Control score | Three-step score |',
             '|---|---:|---:|---:|---:|']
    for scene in ['mixed','strong']:
        rows = [[json.loads(line) for line in (OUT/arm/f'eval_{scene}.rounds.jsonl').read_text().splitlines()]
                for arm in ['control','multistep']]
        a,b = rows
        assert len(a)==len(b)==60
        assert [r['map_hash'] for r in a]==[r['map_hash'] for r in b]
        ix = rng.integers(0,len(a),(10000,len(a)))
        report[scene] = {}
        for metric in ['win','score','survived']:
            d = np.array([float(y[metric])-float(x[metric]) for x,y in zip(a,b)])
            report[scene][metric] = dict(difference=float(d.mean()),
                paired_map_95ci=np.percentile(d[ix].mean(axis=1),[2.5,97.5]).tolist())
        x,y = [summary[f'{arm}_eval_{scene}'] for arm in ['control','multistep']]
        lines.append(f"| {scene} | {x['strict_win_rate']:.1%} | {y['strict_win_rate']:.1%} | {x['mean_score']:.2f} | {y['mean_score']:.2f} |")
    report['limitation'] = 'One training seed, 60 paired maps per scene, fixed final checkpoint; no automatic promotion. Equal environment budget, not equal CPU time.'
    (OUT/'comparison.json').write_text(json.dumps(report,indent=2))
    lines += ['',report['limitation']]
    (OUT/'RESULTS.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')


def main():
    source=ROOT/'experiments/symmetry_v1/symmetry/model.json'
    assert json.loads(source.read_text())['episodes']==750
    OUT.mkdir(parents=True,exist_ok=False)
    workspace=OUT/'workspace'
    shutil.copytree(ROOT,workspace,ignore=shutil.ignore_patterns('.git','experiments','release','logs','__pycache__'))
    (workspace/'logs').mkdir(exist_ok=True)
    runner.ROOT=workspace
    source_hash=digest(source)
    shutil.copy2(source,OUT/'initial_model.json')
    env={**ENV,'QL_RATE_SCALE':str(1/3),'QL_BOOTSTRAP_DYNAMIC':'1','QL_SYMMETRY':'1','QL_SNAPSHOT_DIR':''}
    (OUT/'config.json').write_text(json.dumps(dict(source=str(source),source_sha256=source_hash,
        environment=env,arms={'control':{'QL_N_STEP':'1'},'multistep':{'QL_N_STEP':'3'}},
        training_seed=107001,additional_rounds_each=150,evaluation_rounds_each=60,
        evaluation_seeds=[107002,107003],python=sys.version,numpy=np.__version__,
        design='Same 750-episode symmetry checkpoint and inherited visits. Both arms use D4 augmentation, dynamic bootstrap masks and one-third learning rate. Candidate uses greedy tree backup over at most three transitions, with exact greedy ties averaged separately in each transformed trajectory. Every real transition updated once; terminal tails flushed. Fixed final checkpoint.',
        limitation='Single seed pilot; tree backup can cut credit before three steps. Greedy target uses raw Q; behavior still subtracts escape costs. No convergence guarantee for this approximate control setting.'),indent=2))
    results={}
    def record(arm,label,model,opponents,rounds,seed,training,arm_env):
        phase=f'{arm}_{label}'
        (OUT/'status.json').write_text(json.dumps(dict(phase=phase)))
        results[phase]=runner.run(OUT/arm,label,model,opponents,rounds,seed,
                                 train=training,agent='q_dynamic',environment=arm_env)
        (OUT/'summary.json').write_text(json.dumps(results,indent=2))
    try:
        mixed=['rule_based_agent','coin_collector_agent','peaceful_agent']
        for arm,enabled in [('control','1'),('multistep','3')]:
            folder=OUT/arm
            folder.mkdir()
            snapshots=folder/'checkpoints'; snapshots.mkdir()
            model=folder/'model.json'
            shutil.copy2(source,model)
            assert digest(model)==source_hash
            arm_env={**env,'QL_N_STEP':enabled,'QL_SNAPSHOT_DIR':str(snapshots)}
            record(arm,'training',model,mixed,150,107001,True,arm_env)
            data=json.loads(model.read_text())
            assert data['episodes']==900
            assert data['config']['symmetry'] and data['config']['bootstrap_dynamic']
            assert data['config'].get('n_step',1)==int(enabled)
            assert all(np.isfinite(v).all() for v in data['q'].values())
            trained_hash=digest(model)
            for scene,opponents,seed in [('mixed',mixed,107002),('strong',['rule_based_agent']*3,107003)]:
                record(arm,f'eval_{scene}',model,opponents,60,seed,False,arm_env)
            assert digest(model)==trained_hash
        assert digest(source)==source_hash
        (OUT/'status.json').write_text(json.dumps(dict(phase='analyzing')))
        analyze()
        (OUT/'status.json').write_text(json.dumps(dict(phase='complete')))
    except Exception as exc:
        (OUT/'status.json').write_text(json.dumps(dict(phase='failed',error=repr(exc))))
        raise


if __name__=='__main__':
    main()
