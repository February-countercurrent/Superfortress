"""Combine adopted improvements and three-step backup with mixed/strong opponent training."""
import hashlib
import json
from pathlib import Path
import shutil
import sys
import numpy as np
from experiment_linear import ENV
import run_fighter_experiment as runner

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'experiments/combined_training_v1'
ARMS=['frozen900','control','pool']
SCENES=['mixed','strong']


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def analyze():
    summary=json.loads((OUT/'summary.json').read_text())
    data={}
    for scene in SCENES:
        data[scene]={arm:[json.loads(line) for line in
                         (OUT/arm/f'eval_{scene}.rounds.jsonl').read_text().splitlines()]
                     for arm in ARMS}
        hashes=[r['map_hash'] for r in data[scene]['frozen900']]
        for arm in ARMS:
            assert len(data[scene][arm])==60
            assert [r['map_hash'] for r in data[scene][arm]]==hashes
    rng=np.random.default_rng(137004)
    comparisons={}
    for candidate,baseline in [('pool','control'),('pool','frozen900'),
                               ('control','frozen900')]:
        pair={}
        for scene in SCENES:
            ix=rng.integers(0,60,(10000,60)); metrics={}
            for key in ['win','score','survived']:
                d=np.array([float(b[key])-float(a[key]) for a,b in
                            zip(data[scene][baseline],data[scene][candidate])])
                metrics[key]=dict(difference=float(d.mean()),
                    paired_map_95ci=np.percentile(d[ix].mean(axis=1),[2.5,97.5]).tolist())
            pair[scene]=metrics
        comparisons[f'{candidate}_minus_{baseline}']=pair
    ranking=sorted(ARMS,key=lambda arm:(
        sum(summary[f'{arm}_eval_{s}']['strict_win_rate'] for s in SCENES)/2,
        summary[f'{arm}_eval_strong']['strict_win_rate'],
        sum(summary[f'{arm}_eval_{s}']['mean_score'] for s in SCENES)/2),reverse=True)
    report=dict(paired_comparisons=comparisons,development_ranking=ranking,
        ranking_rule='Equal scene weight on strict win rate; ties use strong win rate, then mean score.',
        limitation='Single training seed. Maps used for candidate selection are development maps; ranking needs independent confirmation. No automatic deployment. Multiple comparisons not adjusted.')
    (OUT/'comparison.json').write_text(json.dumps(report,indent=2))
    lines=['# Combined multistep and opponent curriculum','',
           '| Model | Mixed win | Strong win | Mixed score | Strong score |',
           '|---|---:|---:|---:|---:|']
    for arm in ranking:
        a,b=[summary[f'{arm}_eval_{s}'] for s in SCENES]
        lines.append(f"| {arm} | {a['strict_win_rate']:.1%} | {b['strict_win_rate']:.1%} | {a['mean_score']:.2f} | {b['mean_score']:.2f} |")
    lines+=['',report['ranking_rule'],'',report['limitation']]
    (OUT/'RESULTS.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')


def main():
    source=ROOT/'experiments/multistep_v1/multistep/model.json'
    assert json.loads(source.read_text())['episodes']==900
    hashes={str(source):digest(source)}
    OUT.mkdir(parents=True,exist_ok=False)
    workspace=OUT/'workspace'
    shutil.copytree(ROOT,workspace,ignore=shutil.ignore_patterns('.git','experiments','release','logs','__pycache__'))
    (workspace/'logs').mkdir(exist_ok=True); runner.ROOT=workspace
    env={**ENV,'QL_RATE_SCALE':str(1/3),'QL_BOOTSTRAP_DYNAMIC':'1','QL_SYMMETRY':'1',
         'QL_N_STEP':'3','QL_SNAPSHOT_DIR':'','QL_OPPONENT_POOL':'mixed'}
    (OUT/'config.json').write_text(json.dumps(dict(source_hashes=hashes,environment=env,
        training_seed=137001,additional_rounds_each=150,evaluation_rounds_each=60,
        evaluation_seeds=[137002,137003],arms=ARMS,python=sys.version,numpy=np.__version__,
        design='Both arms start from identical 900-episode multistep weights and visits. Pool alternates mixed and strong rounds; control stays mixed. Both retain D4 augmentation, dynamic masks, one-third rate, three-step tree backup. Continuous training, fixed 1050-episode final checkpoints; frozen 900 reference on same evaluation maps.',
        selection='Development equal-weight mean strict win across mixed/strong; ties strong win then mean score. Confirm selected candidate on independent maps before release.'),indent=2))
    models={}; results={}
    for arm in ARMS:
        folder=OUT/arm; folder.mkdir(); model=folder/'model.json'
        original=source
        shutil.copy2(original,model); assert digest(model)==hashes[str(original)]
        models[arm]=model
    def record(arm,label,opponents,rounds,seed,training=False,environment=None):
        key=f'{arm}_{label}'
        (OUT/'status.json').write_text(json.dumps(dict(phase=key)))
        results[key]=runner.run(OUT/arm,label,models[arm],opponents,rounds,seed,
            train=training,agent='q_dynamic',environment=environment or env)
        (OUT/'summary.json').write_text(json.dumps(results,indent=2))
    try:
        train_opponents=['rule_based_agent','training_coin_pool','training_peace_pool']
        for arm,mode in [('pool','alternating'),('control','mixed')]:
            snapshots=OUT/arm/'checkpoints'; snapshots.mkdir()
            arm_env={**env,'QL_OPPONENT_POOL':mode,'QL_SNAPSHOT_DIR':str(snapshots)}
            record(arm,'training',train_opponents,150,137001,True,arm_env)
            data=json.loads(models[arm].read_text())
            assert data['episodes']==1050 and data['config']['symmetry']
            assert data['config']['bootstrap_dynamic'] and data['config'].get('n_step',1)==3
            assert all(np.isfinite(v).all() for v in data['q'].values())
            initial=json.loads(source.read_text())
            visits=lambda d:sum(sum(v) for v in d['visits'].values())
            backups=json.loads(models[arm].with_suffix('.backup_metrics.json').read_text())
            assert visits(data)-visits(initial)==backups['updates']
        for arm in ARMS:
            model_hash=digest(models[arm])
            for scene,opponents,seed in [
                ('mixed',['rule_based_agent','coin_collector_agent','peaceful_agent'],137002),
                ('strong',['rule_based_agent']*3,137003)]:
                record(arm,f'eval_{scene}',opponents,60,seed)
            assert digest(models[arm])==model_hash
        assert all(digest(Path(p))==h for p,h in hashes.items())
        (OUT/'status.json').write_text(json.dumps(dict(phase='analyzing')))
        analyze()
        (OUT/'status.json').write_text(json.dumps(dict(phase='complete')))
    except Exception as exc:
        (OUT/'status.json').write_text(json.dumps(dict(phase='failed',error=repr(exc))))
        raise


if __name__=='__main__':
    main()
