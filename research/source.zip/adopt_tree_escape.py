"""Record explicit user adoption of the frozen tree escape policy."""
from datetime import datetime, timezone
import importlib
import json
import os
from pathlib import Path
import shutil
from types import SimpleNamespace

import numpy as np

from finalize_guard_release import digest

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT/'agent_code/tree_escape'
TARGET = ROOT/'agent_code/tree_guard'
EVIDENCE = ROOT/'experiments/tree_escape_v1'
RECORD = ROOT/'accepted_candidates/tree_guard_v1'
POINTER = ROOT/'CURRENT_TREE_RESEARCH.json'


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def write(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False)+'\n', encoding='utf-8')


def main():
    assert not TARGET.exists() and not RECORD.exists() and not POINTER.exists(), 'Refuse to overwrite an adopted version'
    assert read(EVIDENCE/'verification.json')['verified']
    config = read(EVIDENCE/'config.json')
    protected = {**config['protected_sha256'], **config['source_sha256']}
    for path in EVIDENCE.rglob('*'):
        if path.is_file() and '__pycache__' not in path.parts and 'logs' not in path.parts:
            protected[str(path.relative_to(ROOT))] = digest(path)
    for name in ('CURRENT_CANDIDATE.json', 'CURRENT_SUBMISSION.json', 'METHODS_INVENTORY.md',
                 'release/Superfortress_v1/final-project-agent-code.zip'):
        protected[name] = digest(ROOT/name)
    assert all(digest(ROOT/name) == sha for name,sha in protected.items())
    assert digest(SOURCE/'model.pkl') == config['model_sha256']

    RECORD.mkdir(parents=True)
    shutil.copy2(ROOT/'METHODS_INVENTORY.md', RECORD/'METHODS_INVENTORY.before.md')
    TARGET.mkdir()
    copied = sorted([*SOURCE.glob('*.py'), SOURCE/'model.pkl'])
    for path in copied:
        shutil.copy2(path, TARGET/path.name)
        assert digest(path) == digest(TARGET/path.name)

    # Verify the adopted package loads its own default checkpoint and enables
    # the guard without relying on research environment variables.
    for name in list(os.environ):
        if name.startswith('FQI_'): del os.environ[name]
    adopted = importlib.import_module('agent_code.tree_guard.callbacks')
    original = importlib.import_module('agent_code.tree_escape.callbacks')
    a, b = SimpleNamespace(train=False), SimpleNamespace(train=False)
    adopted.setup(a); original.setup(b)
    assert a.escape_enabled and a.seed == 42 and a.predictor.features == 28
    assert all(f.n_jobs == 1 for f in a.predictor.estimators)
    field = np.zeros((17,17),dtype=int)
    field[[0,-1],:] = -1; field[:,[0,-1]] = -1
    for round_id in (1,2):
        state = dict(round=round_id,step=1,field=field,explosion_map=np.zeros_like(field),
            self=('self',0,False,(5,5)),others=[],coins=[],bombs=[((5,5),3)])
        assert adopted.act(a,state) == original.act(b,state)
        assert a.rng.bit_generator.state == b.rng.bit_generator.state

    analysis = read(EVIDENCE/'analysis.json')
    accepted = analysis['results']['escape']['combined']
    decision = read(EVIDENCE/'decision.json')
    now = datetime.now(timezone.utc).isoformat()
    metadata = dict(
        agent='tree_guard', status='accepted_research_default', accepted_by_user=True,
        accepted_at=now, user_instruction='我认为这个可以采纳',
        acceptance_basis='Explicit user engineering decision: fewer suicides and positive win/score point estimates; stable win-rate improvement remains unconfirmed.',
        automatic_experiment_criteria_passed=decision['worth_independent_confirmation'],
        source_agent='tree_escape', model='agent_code/tree_guard/model.pkl',
        model_sha256=digest(TARGET/'model.pkl'),
        code_sha256={str((TARGET/p.name).relative_to(ROOT)).replace('\\','/'):digest(TARGET/p.name)
                     for p in copied if p.suffix=='.py'},
        architecture=dict(method='ExtraTrees fitted Q iteration',features=28,action_heads=6,
                          trees_per_head=32,total_trees=192,d4_average=True),
        runtime_defaults=dict(seed=42,escape_guard_enabled=True,inference_only=True,
                              original_dynamic_mask=True,proposal_rng_stream=106),
        policy='Frozen joint tree + unique-WAIT correction toward a strictly shorter safe retreat',
        retrained_for_adoption=False,
        previous_research_default=dict(agent='tree_fqi',model='agent_code/tree_fqi/model.pkl',
                                       model_sha256=digest(ROOT/'agent_code/tree_fqi/model.pkl')),
        parent_joint_checkpoint='experiments/tree_tactical_v3/selected/model.pkl',
        evaluation=dict(directory='experiments/tree_escape_v1',games=accepted['games'],
                        wins=accepted['totals']['win'],win_rate=accepted['win_rate'],
                        mean_score=accepted['mean_score'],suicides=accepted['totals']['suicides'],
                        escape_minus_baseline=analysis['escape_minus_baseline'],
                        scope='Equal-weight mixed and three-rule opponents, paired fresh maps, policy seed 42'),
        tournament_submission_replaced=False, block_q_candidate_replaced=False,
        adoption_record='accepted_candidates/tree_guard_v1/manifest.json')
    write(POINTER,metadata)
    write(RECORD/'manifest.json',metadata)
    (TARGET/'README.md').write_text(
        '# 当前采用的树模型\n\n'
        '用户已明确采纳：28维、六动作ExtraTrees联合模型，加提前撤离WAIT修正。'
        '当前入口为 agent_code/tree_guard，权重与已测试的 tree_escape 完全相同，Python代码逐字节一致。'
        '树模型当前版本以根目录 CURRENT_TREE_RESEARCH.json 为准。\n\n'
        '新地图120局：56胜（46.7%），均分6.233，自杀8次；同图原联合树49胜、自杀20次。'
        '胜率差95%区间仍跨零；这是用户确认的工程采纳，未改写原实验的自动判定。\n\n'
        '默认启用撤离修正，种子42；离线拟合模型，推理不训练。此次采纳无需重训。'
        '可用 FQI_ESCAPE_GUARD=0 关闭修正用于对照。\n\n'
        '原试验代理、逐局数据、Superfortress分块Q提交包及其指针保留。'
        '评估细节见 TREE_ESCAPE_RESULTS.md；本目录是树模型研究版本，不是新的比赛提交。\n',
        encoding='utf-8')
    inventory = (ROOT/'METHODS_INVENTORY.md').read_text(encoding='utf-8')
    old = '首轮仍为研究默认；联合版独立51/120，与300局随机树持平，未满足晋级条件；不替换最终提交'
    assert inventory.count(old)==1
    inventory=inventory.replace(old,'当前树研究版为 tree_guard：28维联合树＋提前撤离修正，用户明确采纳；同图新测56/120，详见第十二节；比赛提交仍是分块Q')
    inventory += '\n## 十二、用户采纳树模型提前撤离修正\n\n'
    inventory += ('本节“采纳”指树模型研究路线的当前版本，与第二节比赛提交模型的采用清单分开记录。'
        '当前指针 CURRENT_TREE_RESEARCH.json，代理 agent_code/tree_guard；'
        '从已测试的 tree_escape 逐字节复制Python代码和联合权重，不重训。\n\n'
        '受已知爆炸威胁且原Q唯一选择WAIT时，仅在原安全候选内选择严格缩短静态撤离距离的移动；'
        '同长按Q排序，并列用独立随机流。原动作随机流、安全筛选、28维表示、六组树和权重保留。\n\n'
        '原120局精确重放发现18次自杀中14次之前有可干预的等待。'
        '另120张新地图配对：原联合树49胜（40.8%）→修正56胜（46.7%），'
        '均分5.517→6.233，自杀20→8，击杀45→59。'
        '胜率差+5.83个百分点，配对95%区间[-5.00,+16.67]；稳定胜率优势尚未确认。\n\n'
        '用户在查看结果后明确说“我认为这个可以采纳”。据此更新树研究默认版本，'
        '保留原实验未满足自动晋级条件的记录，不把工程采纳写成显著性结论。'
        '原首轮树、联合树、试验记录及Superfortress分块Q提交包和指针均保留。\n\n'
        '证据：TREE_ESCAPE_RESULTS.md、experiments/tree_escape_v1、'
        'CURRENT_TREE_RESEARCH.json、accepted_candidates/tree_guard_v1。'
        '本清单修改前的版本已保存为 accepted_candidates/tree_guard_v1/METHODS_INVENTORY.before.md；'
        '旧实验中的文档哈希对应当时快照，采纳记录明确列出此次文档更新。\n')
    (ROOT/'METHODS_INVENTORY.md').write_text(inventory,encoding='utf-8')

    intentional = 'METHODS_INVENTORY.md'
    assert digest(RECORD/'METHODS_INVENTORY.before.md') == protected[intentional]
    assert all(digest(ROOT/name)==sha for name,sha in protected.items()
               if Path(name).as_posix()!=intentional)
    assert all(digest(TARGET/p.name)==digest(p) for p in copied)
    write(RECORD/'verification.json',dict(verified=True,accepted_at=now,
        runtime_code_and_weights_identical_to_evaluated_candidate=True,
        copied_files={p.name:digest(TARGET/p.name) for p in copied},
        default_package_load_and_two_round_actions_verified=True,
        default_guard_enabled=True,single_threaded_heads=True,
        prior_files_checked=len(protected),prior_experiments_unchanged=True,
        submission_unchanged=True,block_q_pointer_unchanged=True,
        intentional_document_update=dict(path=intentional,before_sha256=protected[intentional],
            after_sha256=digest(ROOT/intentional),preserved_before='METHODS_INVENTORY.before.md'),
        current_pointer_sha256=digest(POINTER),readme_sha256=digest(TARGET/'README.md')))
    print(json.dumps(dict(agent=metadata['agent'],accepted=True,retrained=False,
        strict_win_rate=metadata['evaluation']['win_rate'],submission_unchanged=True),ensure_ascii=False,indent=2))


if __name__=='__main__': main()
