"""Lossless bias migration, three paired equal-budget continuations."""
import gzip
import hashlib
import itertools
import json
import os
from pathlib import Path
import shutil
import sys
from types import SimpleNamespace
import numpy as np
from unittest.mock import patch
from agent_code.q_dynamic import callbacks as control
from agent_code.q_conditioned import callbacks as candidate
from migrate_conditioned import migrate
from experiment_linear import ENV
import run_fighter_experiment as runner

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'experiments/conditioned_v1'
SEEDS = [27001, 28001, 29001]


def verify(seed, old_path, new_path):
    agents = []
    for module, path in [(control, old_path), (candidate, new_path)]:
        with patch.dict(os.environ, {'QL_MODEL': str(path), 'QL_SEED': '42'}):
            a = SimpleNamespace(train=False)
            module.setup(a)
        agents.append(a)
    keys = list(agents[0].visits)
    for key in keys:
        np.testing.assert_array_equal(control.values_for(agents[0],key), candidate.values_for(agents[1],key))
    count = 0
    with gzip.open(ROOT / f'experiments/resource_diagnosis_v1/seed_{seed}/score_frames.jsonl.gz', 'rt') as handle:
        for line in itertools.islice(handle, 200):
            s = json.loads(line)['state']
            for name in ['field', 'explosion_map']:
                s[name] = np.array(s[name])
            s['self'] = (*s['self'][:3], tuple(s['self'][3]))
            s['others'] = [(*o[:3], tuple(o[3])) for o in s['others']]
            s['coins'] = [tuple(p) for p in s['coins']]
            s['bombs'] = [(tuple(p), t) for p,t in s['bombs']]
            assert control.act(agents[0],s) == candidate.act(agents[1],s)
            count += 1
    return dict(visited_keys_exact=len(keys), recorded_actions_exact=count, migration='passed')


def analyze():
    summary = json.loads((OUT / 'summary.json').read_text())
    result = {}
    rng = np.random.default_rng(67004)
    for scenario in ['mixed','strong']:
        matrices = {k:[] for k in ['win','score','survived','coins','crates','suicides']}
        per_seed = []
        reference_maps = None
        for seed in SEEDS:
            folder = OUT / f'seed_{seed}'
            data = {name:[json.loads(x) for x in (folder/f'{name}_{scenario}.rounds.jsonl').read_text().splitlines()]
                    for name in ['control','conditioned']}
            assert all(len(rows)==60 for rows in data.values())
            maps = [r['map_hash'] for r in data['control']]
            assert maps == [r['map_hash'] for r in data['conditioned']]
            assert reference_maps is None or reference_maps == maps
            reference_maps = maps
            item = dict(seed=seed)
            for metric in matrices:
                def value(r,agent):
                    return r[metric] if metric in ('win','score','survived') else r['agents'][agent].get(metric,0)
                d = [float(value(a,'q_conditioned'))-float(value(b,'q_dynamic')) for a,b in zip(data['conditioned'],data['control'])]
                matrices[metric].append(d)
                item[metric] = float(np.mean(d))
            per_seed.append(item)
        si, mi = rng.integers(0,3,(10000,3)), rng.integers(0,60,(10000,60))
        differences = {}
        for metric, values in matrices.items():
            a = np.array(values)
            boot = a[si[:,:,None],mi[:,None,:]].mean(axis=(1,2))
            differences[metric] = dict(mean=float(a.mean()), exploratory_95ci=np.percentile(boot,[2.5,97.5]).tolist())
        means = {name:{metric:float(np.mean([summary[f'seed_{s}/{name}_{scenario}'][metric] for s in SEEDS]))
            for metric in ['strict_win_rate','mean_score','mean_coins','mean_crates','suicide_rate','survival_rate']}
            for name in ['control','conditioned']}
        result[scenario] = dict(means=means,differences=differences,per_seed=per_seed)
    result['limitations'] = 'Three training seed pairs; 60 shared maps per scenario. Exploratory intervals, no best-seed selection or automatic replacement.'
    (OUT/'analysis.json').write_text(json.dumps(result,indent=2))
    lines = ['# 条件偏置同预算继续训练结果','','| 场景 | 版本 | 胜率 | 平均得分 | 平均金币 | 平均箱子 | 自杀率 |', '|---|---|---:|---:|---:|---:|---:|']
    for scenario in ['mixed','strong']:
        for name,r in result[scenario]['means'].items():
            lines.append(f"| {scenario} | {name} | {r['strict_win_rate']:.1%} | {r['mean_score']:.2f} | {r['mean_coins']:.2f} | {r['mean_crates']:.2f} | {r['suicide_rate']:.1%} |")
    lines += ['','两者均从对应的 300 局模型继续训练 300 局。迁移前后初始价值相同，双方使用动态逃生；未自动替换最终提交。区间和每种子差异见 analysis.json。']
    (OUT/'RESULTS.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')


def main():
    OUT.mkdir(parents=True,exist_ok=False)
    workspace = OUT/'workspace'
    shutil.copytree(ROOT,workspace,ignore=shutil.ignore_patterns('.git','experiments','release','logs','__pycache__'))
    (workspace/'logs').mkdir(exist_ok=True)
    runner.ROOT = workspace
    locked = {}
    verification = {}
    (OUT/'status.json').write_text(json.dumps(dict(phase='verifying_migration')))
    for seed in SEEDS:
        folder = OUT/f'seed_{seed}'
        folder.mkdir()
        source = ROOT/f'experiments/dynamic_holdout_v1/seed_{seed}/model.json'
        data = json.loads(source.read_text())
        old_path, new_path = folder/'control_initial.json', folder/'conditioned_initial.json'
        shutil.copy2(source,old_path)
        new_path.write_text(json.dumps(migrate(data)))
        verification[str(seed)] = verify(seed,old_path,new_path)
        locked[str(source)] = hashlib.sha256(source.read_bytes()).hexdigest()
        for name in ['control','conditioned']:
            shutil.copy2(folder/f'{name}_initial.json',folder/f'{name}.json')
    (OUT/'migration_verification.json').write_text(json.dumps(verification,indent=2))
    (OUT/'config.json').write_text(json.dumps(dict(source_seeds=SEEDS,continuation_seeds=[s+40000 for s in SEEDS],
        additional_rounds_each=300,evaluation_rounds=60,evaluation_seeds=[67002,67003],environment=ENV,
        original_sha256=locked,python=sys.version,numpy=np.__version__,
        policy='Dynamic escape for both behavior policies, including exploration. Original base safety mask for both bootstrap maxima, matching prior learning update.',
        exploration='Both restart epsilon at 0.35, decay 0.99 per continuation episode, floor 0.05. Visits and episode counters inherited.',
        design='Only first block differs: global vs target/threat conditional bias. Initial Q values equal, same rate and reward, 300 additional rounds per branch; six runs, no best-seed selection.'),indent=2))
    results = {}
    mixed = ['rule_based_agent','coin_collector_agent','peaceful_agent']
    completed = 0
    try:
        for seed in SEEDS:
            folder = OUT/f'seed_{seed}'
            for name,agent in [('control','q_dynamic'),('conditioned','q_conditioned')]:
                model = folder/f'{name}.json'
                stages = [('training',mixed,300,seed+40000,True),('mixed',mixed,60,67002,False),
                          ('strong',['rule_based_agent']*3,60,67003,False)]
                for stage,opponents,rounds,run_seed,training in stages:
                    label = f'{name}_{stage}'
                    key = f'{folder.name}/{label}'
                    (OUT/'status.json').write_text(json.dumps(dict(phase=key,completed_batches=completed,total_batches=18)))
                    results[key] = runner.run(folder,label,model,opponents,rounds,run_seed,train=training,agent=agent,environment=ENV)
                    assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in locked.items())
                    completed += 1
                    (OUT/'summary.json').write_text(json.dumps(results,indent=2))
        (OUT/'status.json').write_text(json.dumps(dict(phase='analyzing',completed_batches=18,total_batches=18)))
        analyze()
        (OUT/'status.json').write_text(json.dumps(dict(phase='complete',completed_batches=18,total_batches=18)))
    except Exception as exc:
        (OUT/'status.json').write_text(json.dumps(dict(phase='failed',error=repr(exc),completed_batches=completed)))
        raise


if __name__ == '__main__':
    main()
