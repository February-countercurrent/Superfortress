"""Three fresh seed blocks, frozen checkpoints, paired-map uncertainty."""
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import shutil
import numpy as np
from experiment_gamma import match, COMMON

ROOT = Path(__file__).parent.resolve()
OUT = ROOT / 'experiments/gamma_fresh_v1'
SEEDS = [105001, 105002, 105003]


def save(path, data):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(data, indent=2))
    temp.replace(path)


def worker(gamma):
    name = 'gamma_07' if gamma == .7 else 'gamma_09'
    folder = OUT / name
    folder.mkdir()
    workspace = folder / 'workspace'
    shutil.copytree(ROOT, workspace, ignore=shutil.ignore_patterns('.git', 'experiments', 'logs', '__pycache__'))
    (workspace / 'logs').mkdir(exist_ok=True)
    model = folder / 'model.json'
    shutil.copy2(ROOT / f'experiments/gamma_v1/{name}/model.json', model)
    before = hashlib.sha256(model.read_bytes()).hexdigest()
    results = {}
    for seed in SEEDS:
        save(folder / 'status.json', {'phase': 'evaluation', 'seed': seed, 'completed_blocks': len(results)})
        results[str(seed)] = match(workspace, folder, f'seed_{seed}', model, 100, seed, gamma, train=False)
        save(folder / 'results.json', results)
    assert hashlib.sha256(model.read_bytes()).hexdigest() == before
    save(folder / 'status.json', {'phase': 'complete', 'model_sha256': before})
    return name, results


def analyze(results):
    metrics = ['score', 'win_rate', 'survival_rate', 'suicide_rate', 'kills']
    pooled = {v: {k: float(np.mean([block[k] for block in runs.values()])) for k in metrics}
              for v, runs in results.items()}
    differences = {k: [] for k in ['score', 'win', 'survived', 'suicides', 'kills']}
    for seed in SEEDS:
        a, b = [[json.loads(line) for line in (OUT / v / f'seed_{seed}.rounds.jsonl').read_text().splitlines()]
                for v in ['gamma_07', 'gamma_09']]
        assert len(a) == len(b) == 100
        assert all(x['map_hash'] == y['map_hash'] for x, y in zip(a, b))
        for key in differences:
            def value(row):
                if key in ('suicides', 'kills'):
                    return row['agents']['q_fighter'].get(key, 0)
                return float(row[key])
            differences[key].append(np.array([value(y) - value(x) for x, y in zip(a, b)]))
    rng = np.random.default_rng(789)
    ix = rng.integers(100, size=(3, 20000, 100))
    paired = {}
    for metric, blocks in differences.items():
        samples = sum(block[ix[i]].mean(axis=1) for i, block in enumerate(blocks)) / 3
        paired[metric] = {'difference': float(np.mean(blocks)),
                          'interval95': np.quantile(samples, [.025, .975]).tolist()}
    save(OUT / 'analysis.json', {'pooled_300_rounds_each': pooled, 'paired_block_stratified_bootstrap': paired,
        'note': 'Gamma09 minus gamma07. Uncertainty over maps within these three blocks; one trained model per gamma. Prior validation and holdout excluded.'})


def main():
    OUT.mkdir(exist_ok=False)
    hashes = {v: hashlib.sha256((ROOT / f'experiments/gamma_v1/{v}/model.json').read_bytes()).hexdigest()
              for v in ['gamma_07', 'gamma_09']}
    save(OUT / 'config.json', {'seeds': SEEDS, 'rounds_per_seed_per_model': 100,
         'training': False, 'source_sha256': hashes, 'common_environment': COMMON,
         'primary_metrics': ['mean_score', 'strict_win_rate'], 'secondary': ['survival', 'suicides', 'kills'],
         'note': 'No optional stopping or retuning, no automatic deployment. Gamma differs in prior training, not inference equations.'})
    save(OUT / 'status.json', {'phase': 'running'})
    try:
        with ThreadPoolExecutor(max_workers=2) as pool:
            results = dict(pool.map(worker, [.7, .9]))
        save(OUT / 'results.json', results)
        analyze(results)
        save(OUT / 'status.json', {'phase': 'complete'})
    except Exception as exc:
        save(OUT / 'status.json', {'phase': 'failed', 'error': repr(exc)})
        raise


if __name__ == '__main__':
    main()
