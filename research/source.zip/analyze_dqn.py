"""Paired-map bootstrap analysis of the completed DQN pilot."""
import csv
import json
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'experiments/dqn_v1'


def main():
    status = json.loads((OUT / 'status.json').read_text())
    if status['phase'] != 'complete':
        raise RuntimeError(f'Evaluation not complete: {status}')
    summary = json.loads((OUT / 'summary.json').read_text())
    result = {}
    rng = np.random.default_rng(26004)
    for scenario in ['mixed', 'strong']:
        def rows(label):
            return [json.loads(line) for line in (OUT / f'{label}_{scenario}.rounds.jsonl').read_text().splitlines()]
        trained = rows('trained')
        result[scenario] = {}
        for baseline in ['initial', 'q_final']:
            reference = rows(baseline)
            assert len(trained) == len(reference) == 60
            assert [r['map_hash'] for r in trained] == [r['map_hash'] for r in reference]
            metrics = {}
            ix = rng.integers(0, len(trained), size=(10000, len(trained)))
            for key in ['score', 'win', 'survived']:
                delta = np.array([float(a[key]) - float(b[key]) for a, b in zip(trained, reference)])
                metrics[key] = dict(difference=float(delta.mean()),
                    paired_bootstrap_95ci=np.percentile(delta[ix].mean(axis=1), [2.5, 97.5]).tolist())
            result[scenario][baseline] = metrics
    with (OUT / 'model.csv').open() as f:
        training = list(csv.DictReader(f))
    assert len(training) == 300 and int(training[-1]['episode']) == 300
    assert all(np.isfinite(float(r['mean_loss'])) for r in training)
    result['training'] = dict(rounds=300, steps=int(training[-1]['steps_total']),
        updates=int(training[-1]['updates']), losses_finite=True,
        seconds=summary['training']['seconds'])
    result['limitations'] = 'One training seed, 60 maps per scenario; bootstrap reflects map variation only, not retraining variability.'
    (OUT / 'analysis.json').write_text(json.dumps(result, indent=2))
    lines = ['# DQN 首轮试验结果', '',
        '300 局训练及 360 局对照评估全部完成。每种对手配置使用 60 张相同种子地图，分析脚本已检查初始地图哈希一致。', '',
        '| 场景 | 模型 | 严格胜率 | 平均得分 | 生存率 | 自杀率 | 平均金币 | 平均击杀 |',
        '|---|---|---:|---:|---:|---:|---:|---:|']
    for scenario in ['mixed', 'strong']:
        for label in ['initial', 'trained', 'q_final']:
            s = summary[f'{label}_{scenario}']
            lines.append(f"| {scenario} | {label} | {s['strict_win_rate']:.1%} | {s['mean_score']:.2f} | {s['survival_rate']:.1%} | {s['suicide_rate']:.1%} | {s['mean_coins']:.2f} | {s['mean_kills']:.2f} |")
    lines += ['', '## 差异的不确定性', '', '以下为训练后 DQN 减去 q_final，按地图配对 bootstrap 10,000 次。胜率区间只体现本次地图抽样，不体现重新训练的随机性。', '']
    for scenario in ['mixed', 'strong']:
        metrics = result[scenario]['q_final']
        w, score = metrics['win'], metrics['score']
        lo, hi = w['paired_bootstrap_95ci']
        slo, shi = score['paired_bootstrap_95ci']
        lines.append(f"- {scenario}：胜率差 {100*w['difference']:.1f} 个百分点，95% 区间 [{100*lo:.1f}, {100*hi:.1f}]；得分差 {score['difference']:.2f}，区间 [{slo:.2f}, {shi:.2f}]。")
    lines += ['', '## 判断与下一步', '',
        '本轮没有支持用 DQN 替换冻结 Q-learning 提交版本的证据。DQN 相比未训练网络学会得分，但约半数评估局出现自杀，生存与金币获取仍需改进。',
        '训练总计 97,703 步、24,170 次更新；所有逐局 loss 均为有限值。loss 有限只说明未发生该类数值异常，不保证策略正确或已收敛。',
        '建议下一步记录死亡前完整动作与安全掩码，分辨动态对手封路、新炸弹、无安全动作回退和网络动作偏好各自造成的失败；再针对证据修改。奖励上涨同时自杀未下降，也提示需要检查奖励与胜负目标是否一致，但尚不能据此认定具体机制。',
        '这是单个训练种子的 300 局试验，Q-learning 有更大的既有训练预算；不能据此认定 DQN 架构上限更低，也不能断言只增加训练轮数就能解决问题。',
        '', '原始数据：experiments/dqn_v1/summary.json、analysis.json、model.csv 及各场景 rounds.jsonl。']
    (ROOT / 'DQN_RESULTS.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
