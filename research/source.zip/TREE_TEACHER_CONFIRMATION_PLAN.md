# Frozen teacher-mixture confirmation

The user retained the teacher-mixture candidate after its initial 120-map test.
This next step adds an independently generated fixed sample, without training,
policy changes, checkpoint selection, or early stopping on performance.

Baseline: adopted tree_guard, model SHA256
397045e64700cb64b3413c1145c3ace4bad258e53ed8db2657feaed8d1ce5ed9.
Candidate: 300 random + 100 teacher episodes, model SHA256
b549995f80ab880bb3b64720bebf9d5db7f5186dcf71c67a15423174fe22bea1.
Both use the exact adopted tree_guard source and its WAIT-to-retreat correction.

Primary sample: 600 NEW paired maps per model, 1200 agent-games total.
Three batches, each containing 100 mixed and 100 strong-opponent maps:

| Batch | Mixed seed | Strong seed | Rounds per scene |
|---|---:|---:|---:|
| 1 | 597002 | 597003 | 100 |
| 2 | 597102 | 597103 | 100 |
| 3 | 597202 | 597203 | 100 |

Policy seed42, original isolated-round world/opponent RNG protocol. Four
independent match processes maximum, each with single-threaded tree inference,
separate workspaces and logs. Freeze source, checkpoint and plan hashes before
running any match. Finish all 600 paired maps regardless of interim results.

Check all new hashes against every recorded prior map hash and each other;
pair exact initial maps between arms. Preserve every per-game row, timing,
source, dataset, checkpoint, adopted pointer and tournament artifact.

Primary outcome: strict unique-highest-score win-rate difference. Also report
mean score, ties, kills, coins, suicides, survival, invalid moves and latency.
Stratified paired bootstrap10000, seed597900, over the six scene/batch strata;
report win and score 95% intervals. Report each scene and each batch, without
using any one stratum to select a preferred version.

Recommended upgrade evidence requires a positive lower win CI bound, positive
mean-score difference, and no increase in suicide count. Positive wins/score
and no additional suicides but a CI spanning zero is a positive yet uncertain
result. Other outcomes do not support an upgrade under these fixed criteria.
Do not rewrite the initial 120-map result, the adopted pointer, or the submission.

Also show the original120 + new600 = 720 paired maps as a descriptive cumulative
summary, with bootstrap seed597901 and weights proportional to stratum size.
The NEW600 result remains primary because the initial120 motivated retention.
Intervals describe map variability for these two fixed checkpoints and fixed
opponent pool, not retraining stability or all possible competition opponents.
