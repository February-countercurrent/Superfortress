"""Dynamic bootstrap action-set alignment; otherwise identical small-rate run."""
import hashlib
import json
from pathlib import Path
import shutil
import sys
import numpy as np
from experiment_linear import ENV
import experiment_stability as stability
import run_fighter_experiment as runner

ROOT=Path(__file__).resolve().parent
BASE=ROOT/'experiments/small_rate_v1'
OUT=ROOT/'experiments/aligned_mask_v1'


def analyze():
    stability.OUT=OUT
    stability.analyze()
    base_analysis=json.loads((BASE/'analysis.json').read_text())
    aligned_analysis=json.loads((OUT/'analysis.json').read_text())
    results={}
    rng=np.random.default_rng(77005)
    for step in [100,200,300]:
        for scenario in ['mixed','strong']:
            label=f'eval_{step:03d}_{scenario}'
            a,b=[stability.stable_rows(p/f'{label}.rounds.jsonl') for p in [BASE,OUT]]
            assert len(a)==len(b)==30
            assert [r['map_hash'] for r in a]==[r['map_hash'] for r in b]
            ix=rng.integers(0,30,(10000,30)); metrics={}
            for k in ['win','score','survived']:
                d=np.array([float(y[k])-float(x[k]) for x,y in zip(a,b)])
                metrics[k]=dict(difference=float(d.mean()),paired_map_95ci=np.percentile(d[ix].mean(axis=1),[2.5,97.5]).tolist())
            results[label]=metrics
    report=dict(base_repeated_flips=base_analysis['contexts_with_repeated_substantial_flips'],
        aligned_repeated_flips=aligned_analysis['contexts_with_repeated_substantial_flips'],paired_results=results,
        mask_metrics=json.loads((OUT/'model.mask_metrics.json').read_text()),
        limitation='One training seed; reused development maps, 30 per scenario, multiple checkpoints. No automatic promotion.')
    (OUT/'comparison.json').write_text(json.dumps(report,indent=2))
    summaries=[json.loads((p/'summary.json').read_text()) for p in [BASE,OUT]]
    lines=['# 训练与执行动作集合统一对照','','| 新增局数 | 场景 | 原小步长胜率 | 统一集合胜率 | 原得分 | 统一集合得分 |','|---|---|---:|---:|---:|---:|']
    for step in [0,100,200,300]:
        for scenario in ['mixed','strong']:
            a,b=[s[f'eval_{step:03d}_{scenario}'] for s in summaries]
            lines.append(f"| {step} | {scenario} | {a['strict_win_rate']:.1%} | {b['strict_win_rate']:.1%} | {a['mean_score']:.2f} | {b['mean_score']:.2f} |")
    lines+=['',f"明显反复翻转局面数：原小步长 {report['base_repeated_flips']}，统一集合 {report['aligned_repeated_flips']}。",'',report['limitation']]
    (OUT/'COMPARISON.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')


def main():
    assert json.loads((BASE/'status.json').read_text())['phase']=='complete'
    OUT.mkdir(parents=True,exist_ok=False)
    (OUT/'checkpoints').mkdir()
    workspace=OUT/'workspace'
    shutil.copytree(ROOT,workspace,ignore=shutil.ignore_patterns('.git','experiments','release','logs','__pycache__'))
    (workspace/'logs').mkdir(exist_ok=True)
    runner.ROOT=workspace
    source=BASE/'checkpoints/step_000.json'
    source_hash=hashlib.sha256(source.read_bytes()).hexdigest()
    model=OUT/'model.json'
    shutil.copy2(source,model)
    shutil.copy2(source,OUT/'checkpoints/step_000.json')
    shutil.copy2(BASE/'diagnostic_contexts.json',OUT/'diagnostic_contexts.json')
    results={}; baseline=json.loads((BASE/'summary.json').read_text())
    for scenario in ['mixed','strong']:
        label=f'eval_000_{scenario}'
        results[label]=baseline[label]
        for suffix in ['.json','.rounds.jsonl']:
            shutil.copy2(BASE/f'{label}{suffix}',OUT/f'{label}{suffix}')
    env={**ENV,'QL_RATE_SCALE':str(1/3),'QL_BOOTSTRAP_DYNAMIC':'1','QL_SNAPSHOT_DIR':str(OUT/'checkpoints')}
    (OUT/'config.json').write_text(json.dumps(dict(source=str(source),source_sha256=source_hash,
        environment=env,seed=67001,additional_rounds=300,evaluation_rounds=30,evaluation_seeds=[77002,77003],
        evaluation_checkpoints=[0,100,200,300],python=sys.version,numpy=np.__version__,
        design='Only bootstrap action set changes: use the same dynamic mask as acting, including fallback. Reuse completed small-rate control. Initial weights and visit counts identical.',
        limitation='Action-set alignment only: unchanged raw-Q off-policy maximum and behavior escape-cost adjustment remain. Development maps, single seed, no automatic deployment.'),indent=2))
    def record(label,path,opponents,rounds,seed,train=False):
        (OUT/'status.json').write_text(json.dumps(dict(phase=label)))
        results[label]=runner.run(OUT,label,path,opponents,rounds,seed,train=train,agent='q_dynamic',environment=env)
        (OUT/'summary.json').write_text(json.dumps(results,indent=2))
    try:
        mixed=['rule_based_agent','coin_collector_agent','peaceful_agent']
        record('training',model,mixed,300,67001,True)
        for step in [100,200,300]:
            for scenario,opponents,seed in [('mixed',mixed,77002),('strong',['rule_based_agent']*3,77003)]:
                record(f'eval_{step:03d}_{scenario}',OUT/f'checkpoints/step_{step:03d}.json',opponents,30,seed)
        assert hashlib.sha256(source.read_bytes()).hexdigest()==source_hash
        (OUT/'status.json').write_text(json.dumps(dict(phase='analyzing')))
        analyze()
        (OUT/'status.json').write_text(json.dumps(dict(phase='complete')))
    except Exception as exc:
        (OUT/'status.json').write_text(json.dumps(dict(phase='failed',error=repr(exc))))
        raise


if __name__=='__main__':
    main()
