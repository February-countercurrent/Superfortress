"""Small matched-budget feature experiment, isolated workers, no deployment."""
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import os

ROOT = Path(__file__).parent.resolve()
OUT = ROOT / 'experiments/attack_features_v2'
COMMON = {'QF_ESCAPE_RISK': '1', 'QF_BOMB_COST': '1', 'QF_CONTEST_SCALE': '1',
          'QF_ANTICIPATE': '0', 'QF_SHIELD': '1', 'QF_ALPHA': '.15', 'QF_GAMMA': '.7',
          'QF_EPSILON': '.2', 'QF_DECAY': '.99', 'QF_DEATH_PENALTY': '25',
          'QF_SHAPING': '0', 'QF_PROGRESS': '.8', 'OMP_NUM_THREADS': '1',
          'MKL_NUM_THREADS': '1', 'OPENBLAS_NUM_THREADS': '1'}


def match(workspace, folder, label, model, rounds, seed, enabled, train=False):
    command = [sys.executable, str(workspace / 'run_fighter_match.py'), '--model', str(model),
               '--output', str(folder / f'{label}.json'), '--rounds', str(rounds),
               '--seed', str(seed), '--opponents', *(['rule_based_agent'] * 3)]
    if train:
        command += ['--train']
    with (folder / f'{label}.log').open('w') as log:
        subprocess.run(command, cwd=workspace, env={**os.environ, **COMMON, 'QF_ATTACK_FEATURES': str(enabled)},
                       stdout=log, stderr=subprocess.STDOUT, check=True)
    rows = [json.loads(line) for line in (folder / f'{label}.rounds.jsonl').read_text().splitlines()]
    stats = json.loads((folder / f'{label}.json').read_text())['by_agent']['q_fighter']
    result = {'rounds': len(rows), 'score': stats.get('score', 0) / rounds, 'kills': stats.get('kills', 0) / rounds,
              'win_rate': sum(r['win'] for r in rows) / rounds,
              'survival_rate': sum(r['survived'] for r in rows) / rounds,
              'suicide_rate': stats.get('suicides', 0) / rounds,
              'action_ms': 1000 * stats['time'] / stats['steps']}
    print(folder.name, label, json.dumps(result), flush=True)
    return result


def worker(enabled):
    folder = OUT / ('expanded' if enabled else 'control')
    folder.mkdir()
    workspace = folder / 'workspace'
    shutil.copytree(ROOT, workspace, ignore=shutil.ignore_patterns('.git', 'experiments', 'logs', '__pycache__'))
    (workspace / 'logs').mkdir(exist_ok=True)
    model = folder / 'model.json'
    shutil.copy2(OUT / 'initial.json', model)
    results = {}
    for label, rounds, seed, train in [('initial_check', 3, 65000, False),
                                      ('training', 300, 75001, True),
                                      ('validation', 60, 65001, False),
                                      ('holdout', 60, 65002, False)]:
        (folder / 'status.json').write_text(json.dumps({'phase': label}))
        results[label] = match(workspace, folder, label, model, rounds, seed, enabled, train)
        (folder / 'results.json').write_text(json.dumps(results, indent=2))
    (folder / 'status.json').write_text(json.dumps({'phase': 'complete'}))
    return folder.name, results


def main():
    OUT.mkdir(exist_ok=False)
    selected = json.loads((ROOT / 'experiments/learning_curve_v1/selection.json').read_text())
    shutil.copy2(selected['path'], OUT / 'initial.json')
    (OUT / 'config.json').write_text(json.dumps({'source': selected['path'], 'environment': COMMON,
        'additional_rounds_each': 300, 'training_seed': 75001, 'validation_seed': 65001,
        'holdout_seed': 65002, 'initial_sha256': hashlib.sha256((OUT / 'initial.json').read_bytes()).hexdigest(),
        'note': 'One matched continuation seed; coarse static features; all rules fixed. Expanded keys inherit Q and visit counts; original 16-feature rows remain frozen fallback.'}, indent=2))
    try:
        with ThreadPoolExecutor(max_workers=2) as pool:
            result = dict(pool.map(worker, [0, 1]))
        (OUT / 'results.json').write_text(json.dumps(result, indent=2))
        (OUT / 'status.json').write_text(json.dumps({'phase': 'complete'}))
    except Exception as exc:
        (OUT / 'status.json').write_text(json.dumps({'phase': 'failed', 'error': repr(exc)}))
        raise


if __name__ == '__main__':
    main()
