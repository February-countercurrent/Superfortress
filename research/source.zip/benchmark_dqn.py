"""Time full CPU inference on 1,200 recorded game states, excluding setup."""
import gzip
import argparse
import itertools
import json
import os
from pathlib import Path
import time
from types import SimpleNamespace
import numpy as np
import psutil
from agent_code.dqn_agent import callbacks

ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--model', type=Path, default=ROOT / 'experiments/dqn_v1/initial.pt')
parser.add_argument('--output', type=Path, default=ROOT / 'experiments/dqn_v1/latency.json')
args = parser.parse_args()
os.environ['DQN_MODEL'] = str(args.model.resolve())
agent = SimpleNamespace(train=False)
callbacks.setup(agent)
times = []
with gzip.open(ROOT / 'experiments/score_diagnosis_v1/score_frames.jsonl.gz', 'rt') as handle:
    for line in itertools.islice(handle, 1200):
        s = json.loads(line)['state']
        for name in ['field', 'explosion_map']:
            s[name] = np.array(s[name])
        s['self'] = (*s['self'][:3], tuple(s['self'][3]))
        s['others'] = [(*o[:3], tuple(o[3])) for o in s['others']]
        s['bombs'] = [(tuple(p), t) for p, t in s['bombs']]
        s['coins'] = [tuple(p) for p in s['coins']]
        start = time.perf_counter()
        callbacks.act(agent, s)
        times.append((time.perf_counter() - start) * 1000)
result = dict(states=len(times), mean_ms=float(np.mean(times)), p99_ms=float(np.percentile(times, 99)),
              max_ms=max(times), process_rss_mb=psutil.Process().memory_info().rss / 1024**2,
              model=str(args.model.resolve()),
              note='Recorded states; setup excluded; concurrent workloads may affect latency.')
args.output.write_text(json.dumps(result, indent=2))
print(json.dumps(result))
