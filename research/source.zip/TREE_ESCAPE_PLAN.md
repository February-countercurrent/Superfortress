# Frozen-weight escape-WAIT experiment

The diagnostic replay exactly reproduced 120 joint-tree games. In 14/18 suicide
games, the last six observations included a unique greedy WAIT with a shorter
statically reachable retreat inside the existing timed/dynamic candidate mask.
This is a mechanism hypothesis, not 14 proven rescues. The same condition is
present on 2949/34378 recorded decisions across all 120 games; its impact is
not limited to death cases. The original maps are now development maps.

One fixed candidate, no parameter sweep or retraining: only if threatened and
the original masked greedy set is exactly WAIT, restrict a replacement to
originally safe, dynamically allowed moves that strictly shorten BFS distance
to any free tile outside all currently observed blast rays. Prefer minimum
distance, then learned Q; ties use independent round RNG stream 106. Unreachable
static routes do not trigger. Preserve the original RNG draw every decision.
No reward-unit coefficients, no BOMB override, no override of existing moves.

Before fresh evaluation: six invariant tests; two disabled-equivalence games
per scene; enabled replay of the original 120 games for descriptive mechanism
checks only. Do not select/tune using those replay scores.

Fresh paired evaluation: baseline joint and escape candidate, each 60 mixed
games at seed 577002 and 60 three-rule-opponent games at 577003; policy seed 42.
The same frozen checkpoint is used in both arms. No learned updates. Complete
all games, compare strict unique-highest-score wins, score, suicides, kills,
coins, invalid actions, survival and latency. Verify paired maps and absence
of overlaps with every recorded prior map in experiments. Report stratified
paired bootstrap 10000 samples, seed 577900, for win and score differences.
Intervals describe map uncertainty, not new training seeds or unseen opponents.

Worth independent confirmation only if the win-difference 95% interval is
strictly positive, mean score improves, and suicides do not increase. Otherwise
do not promote. Even a positive result does not replace the submitted block-Q
agent; this is a tree research experiment, without a new block-Q comparison.
Protect prior experiment data, sources, models, release ZIP and pointers.
