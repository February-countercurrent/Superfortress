"""Check complete-episode event accounting and describe training data coverage."""
import csv
from pathlib import Path
import numpy as np
from fit_tree_fqi import read_data
from experiment_tree_fqi import rows
from experiment_tree_fqi_batches import save

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'experiments/tree_teacher_v1'


def describe(data):
    training=data['round']%5!=0
    x=data['tactical_x'][training];a=data['a'][training]
    reward=(data['r']-data['open_attack_bonus'])[training]
    return dict(transitions=len(a),unique_states=len(np.unique(x,axis=0)),
        unique_state_action_pairs=len(np.unique(np.column_stack((x,a)),axis=0)),
        actions={name:dict(count=int((a==i).sum()),
            mean_reward=float(reward[a==i].mean()),
            reward_quantiles=np.quantile(reward[a==i],[.1,.5,.9]).tolist())
            for i,name in enumerate(('UP','RIGHT','DOWN','LEFT','WAIT','BOMB'))})


def main():
    with (OUT/'teacher/data/episodes.csv').open(newline='',encoding='utf-8') as f:
        episodes=list(csv.DictReader(f))
    matches=rows(OUT/'teacher/mixed.rounds.jsonl')
    assert len(episodes)==len(matches)==100
    mappings=dict(COIN_COLLECTED='coins',CRATE_DESTROYED='crates',KILLED_OPPONENT='kills',
                  KILLED_SELF='suicides',BOMB_DROPPED='bombs')
    for episode,match in zip(episodes,matches):
        assert int(episode['round'])==match['round']
        stats=match['agents']['q_guard']
        for event,stat in mappings.items():assert int(episode[event])==stats.get(stat,0),(match['round'],event)
        assert int(episode['GOT_KILLED'])==int(not match['survived'])
        assert int(episode['transitions'])==stats['steps']
    result=dict(episode_event_totals_match_full_game_statistics=True,games=100,
        baseline=describe(read_data(ROOT/'experiments/tree_tactical_v3/data')),
        teacher_mixture=describe(read_data(OUT/'data')),
        note='Coverage and rewards describe the fitting split only; they do not independently establish policy quality.')
    save(OUT/'data_analysis.json',result)
    print({name:{k:v for k,v in r.items() if k!='actions'} for name,r in result.items() if isinstance(r,dict)})


if __name__=='__main__':main()
