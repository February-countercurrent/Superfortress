"""Audit recorded deaths and bounded, same-turn escape counterfactuals.

Counterfactuals retain observed opponent commands and action order, replay
collisions, and ask the existing forecast about survival after that action.
They are NOT complete alternative games or predictions of future opponents.
"""
from collections import Counter
import copy
import json
from pathlib import Path
import numpy as np
import settings
from agent_code.q_symavg.features import ACTIONS, DELTAS, allowed, forecast
from agent_code.q_symavg.dynamic import candidate_mask
from agent_code.q_symavg.escape import escape_costs
from diagnose_symavg_survival import stable_rows

ROOT = Path(__file__).resolve().parent
OUT = ROOT/'experiments/symavg_survival_v1'
NAME = 'q_symavg'


def decode(frame):
    state = copy.deepcopy(frame['state']); info = copy.deepcopy(frame['info'])
    for key in ('field', 'explosion_map'):
        state[key] = np.array(state[key])
    state['bombs'] = [(tuple(p), t) for p, t in state['bombs']]
    state['self'] = (*state['self'][:3], tuple(state['self'][3]))
    state['others'] = [(*o[:3], tuple(o[3])) for o in state['others']]
    state['coins'] = [tuple(p) for p in state['coins']]
    for key in ('legal', 'safe', 'robust_safe'):
        info[key] = np.array(info[key], dtype=bool)
    info['key'] = tuple(info['key'])
    return state, info


def raw_dynamic_mask(state, info):
    """Mirror the deployed filter, exposing the pre-fallback intersection."""
    base = allowed(info, True)
    if not info['safe'].any() or not state['others']:
        return base.copy(), False
    if not info['threatened'] and not base[5]:
        return base.copy(), False
    pos = tuple(state['self'][3]); robust = base.copy()
    occupied = {tuple(o[3]) for o in state['others']} | {tuple(p) for p,_ in state['bombs']} | {pos}
    destinations = [(pos[0]+dx,pos[1]+dy) for dx,dy in DELTAS]+[pos,pos]
    for i,other in enumerate(state['others']):
        ox,oy = other[3]
        if abs(ox-pos[0])+abs(oy-pos[1]) > 6:
            continue
        for dx,dy in DELTAS:
            p = ox+dx,oy+dy
            if not (0 <= p[0] < state['field'].shape[0] and 0 <= p[1] < state['field'].shape[1]):
                continue
            if state['field'][p] != 0 or p in occupied:
                continue
            others = list(state['others']); others[i] = (*other[:3],p)
            predicted = {**state,'others':others}
            if info['threatened']:
                viable = forecast(predicted)
                for action in range(5):
                    destination = pos if action < 4 and destinations[action] == p else destinations[action]
                    robust[action] &= viable[destination]
            if robust[5]:
                robust[5] &= forecast(predicted,new_bomb=True)[pos]
    deployed = robust if robust.any() else base.copy()
    np.testing.assert_array_equal(deployed,candidate_mask(state,info,base))
    return robust, not robust.any()


def replay_action_geometry(frame, own_action=None, remove_enemy_bombs=False, freeze_enemy_moves=False):
    """Exact same-turn movement/placement rules, followed by static forecasting.

    Timer values remain at the pre-step origin so forecast(t=1) consumes this
    action exactly once. No future opponent actions are supplied to forecast.
    """
    state,_ = decode(frame)
    actors = {a[0]:a for a in [state['self'],*state['others']]}
    positions = {name:tuple(a[3]) for name,a in actors.items()}
    ready = {name:bool(a[2]) for name,a in actors.items()}
    bombs = [(tuple(p),t) for p,t in state['bombs']]
    unchanged = own_action is None and not remove_enemy_bombs and not freeze_enemy_moves
    for record in frame['actions']:
        name = record['agent']; action = record['action']
        if name == NAME and own_action is not None:
            action = own_action
        if name != NAME and ((remove_enemy_bombs and action == 'BOMB') or
                             (freeze_enemy_moves and action in ACTIONS[:4])):
            action = 'WAIT'
        if action in ACTIONS[:4]:
            dx,dy = DELTAS[ACTIONS.index(action)]
            pos = positions[name]; dest = pos[0]+dx,pos[1]+dy
            if (state['field'][dest] == 0 and dest not in positions.values()
                    and dest not in {p for p,_ in bombs}):
                positions[name] = dest
        elif action == 'BOMB' and ready[name]:
            bombs.append((positions[name],settings.BOMB_TIMER)); ready[name] = False
        if unchanged:
            assert positions[name] == tuple(record['after']), (frame['round'],frame['step'],name)
    predicted = {**state, 'bombs':bombs,
        'self':(*state['self'][:2],ready[NAME],positions[NAME]),
        'others':[(*o[:2],ready[o[0]],positions[o[0]]) for o in state['others']]}
    viable = forecast(predicted)
    return dict(position=list(positions[NAME]),survival_route=bool(viable[positions[NAME]]),
                actor_positions={name:list(p) for name,p in positions.items()},
                bombs=[(list(p),t) for p,t in bombs])


def audit_folder(folder, reference):
    observed = stable_rows(folder/'match.rounds.jsonl')
    expected = stable_rows(reference)[:len(observed)]
    assert observed == expected and observed, 'Replay changed outcomes'
    counts = Counter(); cases = []
    for path in sorted(folder.glob('death_[0-9][0-9][0-9].json')):
        frames = json.loads(path.read_text()); end = frames[-1]
        suicide = 'KILLED_SELF' in end['events']
        counts['deaths'] += 1; counts['suicides'] += int(suicide)
        counts['death_without_static_safe_action'] += int(not any(end['info']['safe']))
        own_lethal = [b for b in end['lethal'] if b['owner'] == NAME]
        placements = [f for f in frames if any(f['step'] == b['placed'] for b in own_lethal)]
        counts['own_lethal_placement_observed'] += int(bool(placements))
        counts['own_lethal_placement_static_and_dynamic_safe'] += int(bool(placements) and all(
            f['info']['safe'][5] and f['candidate_mask'][5] for f in placements))
        placement_details = []
        for f in placements:
            planting_state,planting_info = decode(f)
            planting_mask,planting_fallback = raw_dynamic_mask(planting_state,planting_info)
            counts['own_lethal_placement_dynamic_fallback'] += int(planting_fallback)
            counts['own_lethal_placement_robust_bomb'] += int(planting_mask[5])
            placement_details.append(dict(step=f['step'],static_safe=bool(f['info']['safe'][5]),
                dynamic_safe=bool(f['candidate_mask'][5]),robust_bomb=bool(planting_mask[5]),
                fallback=planting_fallback))
        unsafe = [f['step'] for f in frames if any(f['info']['safe']) and
                  not f['info']['safe'][ACTIONS.index(f['chosen'])]]
        counts['window_unsafe_choice_despite_static_safe_alternative'] += int(bool(unsafe))
        changes = []
        for f in frames:
            if not any(f['info']['safe']) or (not f['dead'] and any(f.get('post_safe',[]))):
                continue
            state,info = decode(f)
            raw_mask,fallback = raw_dynamic_mask(state,info)
            np.testing.assert_array_equal(candidate_mask(state,info,allowed(info,True)),f['candidate_mask'])
            own = next(a for a in f['actions'] if a['agent'] == NAME)
            enemy_bombs = [a['agent'] for a in f['actions'] if a['agent'] != NAME and 'BOMB_DROPPED' in a['events']]
            enemy_moves = [dict(agent=a['agent'],before=a['before'],after=a['after']) for a in f['actions']
                           if a['agent'] != NAME and a['before'] != a['after']]
            collision = False
            if f['chosen'] in ACTIONS[:4] and 'INVALID_ACTION' in own['events']:
                dx,dy = DELTAS[ACTIONS.index(f['chosen'])]
                dest = [own['before'][0]+dx,own['before'][1]+dy]
                collision = any(a['agent'] != NAME and a['after'] == dest
                    for a in f['actions'][:f['actions'].index(own)])
            mask = np.array(f['candidate_mask'],dtype=bool)
            adjusted = np.array(f['adjusted_q'])
            without_contest = np.array(f['q'])-escape_costs(state,info,0.,0.)
            best_without_contest = np.flatnonzero(mask & np.isclose(without_contest,without_contest[mask].max()))
            flips_wait = (f['chosen'] == 'WAIT' and 4 not in best_without_contest
                          and any(i < 4 for i in best_without_contest))
            actual_geometry = replay_action_geometry(f)
            alternatives = {ACTIONS[i]:replay_action_geometry(f,ACTIONS[i]) for i in np.flatnonzero(mask)
                            if ACTIONS[i] != f['chosen']}
            alternatives_safe = [a for a,r in alternatives.items() if r['survival_route']]
            changes.append(dict(step=f['step'],action=f['chosen'],position=own['before'],after=own['after'],
                static_safe=[ACTIONS[i] for i,x in enumerate(info['safe']) if x],
                dynamic_candidates=[ACTIONS[i] for i,x in enumerate(mask) if x],
                dynamic_intersection_empty=fallback,enemy_new_bombs=enemy_bombs,enemy_moves=enemy_moves,
                observed_move_collision=collision,contest_cost_changes_move_to_wait=flips_wait,
                contest_free_best=[ACTIONS[i] for i in best_without_contest],
                q=f['q'],costs=f['costs'],adjusted_q=f['adjusted_q'],
                actual_same_turn_model=actual_geometry,alternative_same_turn_routes=alternatives_safe,
                alternatives=alternatives,
                remove_enemy_new_bombs_model=replay_action_geometry(f,remove_enemy_bombs=True),
                freeze_enemy_moves_model=replay_action_geometry(f,freeze_enemy_moves=True)))
        # Only the last transition into no-safe/dead is used for the headline
        # indicators; earlier temporary losses remain available in the case.
        terminal = changes[-1] if changes else None
        counts['terminal_safe_to_no_safe_transition_found'] += int(terminal is not None)
        if terminal:
            for field in ('dynamic_intersection_empty','observed_move_collision','contest_cost_changes_move_to_wait'):
                counts['terminal_'+field] += int(terminal[field])
                if suicide:
                    counts['suicide_terminal_'+field] += int(terminal[field])
            counts['terminal_with_enemy_new_bomb'] += int(bool(terminal['enemy_new_bombs']))
            counts['terminal_chosen_wait'] += int(terminal['action'] == 'WAIT')
            counts['terminal_alternative_same_turn_route'] += int(bool(terminal['alternative_same_turn_routes']))
            if suicide:
                counts['suicide_terminal_with_enemy_new_bomb'] += int(bool(terminal['enemy_new_bombs']))
                counts['suicide_terminal_chosen_wait'] += int(terminal['action'] == 'WAIT')
                counts['suicide_terminal_alternative_same_turn_route'] += int(bool(terminal['alternative_same_turn_routes']))
        cases.append(dict(round=end['round'],death_step=end['step'],suicide=suicide,lethal=end['lethal'],
            own_lethal_placements=placement_details,
            unsafe_choices=unsafe,safety_losses=changes,terminal_loss=terminal))
    assert counts['deaths'] == sum(not r['survived'] for r in observed)
    assert counts['suicides'] == sum(r['agents'][NAME].get('suicides',0) for r in observed)
    report = dict(rounds=len(observed),replay_exact_except_timing=True,counts=dict(counts),cases=cases,
        limitation='Diagnostic reuse, not independent win-rate testing. Indicators overlap. Last 12 steps per death. '
        'Alternative same-turn routes keep actual enemy commands and order and replay collisions, then use '
        'the existing static-opponent forecast; they do not prove future survival or higher win rate. '
        'Predicted post-action opponents remain obstacles even if they would die in that turn.')
    (folder/'death_analysis.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    return report


def main():
    assert json.loads((OUT/'status.json').read_text())['phase'] in ('replay_complete','complete')
    reports = {scene:audit_folder(OUT/scene,ROOT/f'experiments/resource_priority_v1/control_{scene}.rounds.jsonl')
               for scene in ('mixed','strong')}
    counts = Counter()
    for r in reports.values():
        counts.update(r['counts'])
    report = dict(rounds=120,scenes={s:r['counts'] for s,r in reports.items()},counts=dict(counts),
                  limitation=reports['mixed']['limitation'])
    (OUT/'analysis.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    (OUT/'status.json').write_text(json.dumps(dict(phase='complete',completed_scenes=2,total_scenes=2)))
    print(json.dumps(report,indent=2))


if __name__ == '__main__':
    main()
