"""Descriptive audit of frozen-game actions and reconciled bomb outcomes."""
from collections import Counter,defaultdict
import gzip
import json
from pathlib import Path
import numpy as np
import settings
from agent_code.tree_guard.features import DELTAS,blast,distance_map,forecast
from agent_code.tree_guard.tactical import enemy_exit_counts
from experiment_tree_fqi import read,rows,summarize
from experiment_tree_fqi_batches import save
from finalize_guard_release import digest

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'experiments/tree_attack_diagnosis_v1'


def restore(state):
    s=dict(state);s['field']=np.asarray(s['field'],dtype=np.int8)
    s['explosion_map']=np.asarray(s['explosion_map'],dtype=np.int8)
    s['self']=tuple(s['self'][:3])+ (tuple(s['self'][3]),)
    s['others']=[tuple(o[:3])+(tuple(o[3]),) for o in s['others']]
    s['bombs']=[(tuple(p),t) for p,t in s['bombs']]
    s['coins']=[tuple(p) for p in s['coins']]
    return s


def enemy_escape(state,enemy):
    """Optimistic enemy routes through KNOWN hazards, without player blocking.

    Enemy can move on the placement turn. Future new opponent bombs and other
    moving players are omitted; absence of a route is stronger than existence.
    This is a diagnostic descriptor, not a calibrated kill probability.
    """
    origin=state['self'][3];position=enemy[3]
    s=dict(state,self=enemy,others=[],bombs=state['bombs']+[(origin,settings.BOMB_TIMER)])
    viable=forecast(s)
    occupied={p for p,_ in s['bombs']}
    choices=[position]+[(position[0]+dx,position[1]+dy) for dx,dy in DELTAS]
    survival=sum(bool(viable[p]) and state['field'][p]==0 and (p==position or p not in occupied) for p in choices)
    without=forecast(dict(s,bombs=state['bombs']))
    old_occupied={p for p,_ in state['bombs']}
    before=sum(bool(without[p]) and state['field'][p]==0 and (p==position or p not in old_occupied) for p in choices)
    free=state['field']==0
    for p in occupied: free[p]=False
    free[position]=True
    outside=free.copy()
    for p in blast(state['field'],origin): outside[p]=False
    distances=distance_map(free,list(zip(*np.where(outside))))
    return dict(viable_first_actions=int(survival),viable_first_actions_without_bomb=int(before),
                static_steps_off_ray=int(distances[position]))


def coin_distance(state):
    if not state['coins']: return -1
    free=state['field']==0
    for p,_ in state['bombs']: free[p]=False
    for o in state['others']:free[o[3]]=False
    free[state['self'][3]]=True
    return int(distance_map(free,state['coins'])[state['self'][3]])


def classify(decision):
    attack=bool(decision['enemy_hits']);crates=bool(decision['crate_yield'])
    return 'attack_and_crates' if attack and crates else 'attack_only' if attack else 'crates_only' if crates else 'no_current_target'


def bomb_totals(bb):
    return dict(bombs=len(bb),detonated=sum(b['detonation'] is not None for b in bb),
        hit_bombs=sum(bool(b['hits']) for b in bb),kill_credits=sum(len(b['hits']) for b in bb),
        crates=sum(b['crates'] for b in bb),self_hit_bombs=sum(bool(b['self_hits']) for b in bb),
        no_kill_no_crate=sum(b['detonation'] is not None and not b['hits'] and not b['crates'] for b in bb),
        targeted_enemies=sum(len(b['target_names']) for b in bb),
        targeted_enemies_hit=sum(len(set(b['target_names']) & {h['victim'] for h in b['hits']}) for b in bb))


def analyze_arm(arm):
    counts=Counter();grouped=defaultdict(list);all_bombs=[];games=[];ends=[];examples=[];escape_targets=[]
    opportunity_examples=[];action_q=defaultdict(list);episode_summaries=[]
    for batch in (1,2,3):
        folder=OUT/'replay'/f'batch_{batch}_{arm}'
        verification=read(folder/'verification.json')
        assert verification['verified']
        assert all(digest(folder/n)==h for n,h in verification['result_sha256'].items())
        games+=rows(folder/'match.rounds.jsonl')
        bomb_rows=[b for b in rows(folder/'bombs.jsonl') if b['owner']=='tree_fqi']
        bombs_by_round=defaultdict(list)
        for b in bomb_rows:bombs_by_round[b['round']].append(b)
        round_records=[]
        def process(rr):
            if not rr:return
            index=rr[0]['round'];decisions={r['step']:r['decision'] for r in rr if r['decision']}
            game=next(g for g in games if g['round']==index and g['seed']=={1:597003,2:597103,3:597203}[batch])
            previous_origin={};local_bombs=[]
            for b in bombs_by_round[index]:
                d=decisions[b['step']];state=restore(d['state']);origin=state['self'][3]
                assert d['action']==5 and tuple(b['position'])==origin
                target_names=[o[0] for o in state['others'] if o[3] in blast(state['field'],origin)]
                escapes=[dict(name=o[0],**enemy_escape(state,o)) for o in state['others'] if o[0] in target_names]
                exits=[int(n) for n in enemy_exit_counts(state,origin)]
                b.update(batch=batch,arm=arm,category=classify(d),target_names=target_names,
                    key=d['key'],q=d['q'],
                    min_exits=min(exits) if exits else None,enemy_escape=escapes,
                    coin_distance=coin_distance(state),threatened=d['threatened'],
                    predicted_crates=d['crate_yield'],remaining=401-b['step'],
                    lead_over_living=max([o[1] for o in state['others']],default=0)<state['self'][1],
                    living_enemies=len(state['others']),repeat_origin=origin in previous_origin,
                    repeat_after_empty=origin in previous_origin and not previous_origin[origin]['hits'] and not previous_origin[origin]['crates'])
                for e in escapes:
                    escape_targets.append(dict(**e,batch=batch,round=index,step=b['step'],min_exits=b['min_exits'],
                        hit=any(h['victim']==e['name'] for h in b['hits'])))
                previous_origin[origin]=b
                grouped[b['category']].append(b);all_bombs.append(b);local_bombs.append(b)
            for step,d in decisions.items():
                counts['actions']+=1;counts['action_'+str(d['action'])]+=1
                counts['retreat_override']+=bool(d['retreat_options'])
                counts['invalid_after_retreat']+=bool(d['retreat_options']) and 'INVALID_ACTION' in d['events']
                counts['death_after_retreat']+=bool(d['retreat_options']) and 'GOT_KILLED' in d['events']
                counts['invalid_action_'+str(d['action'])]+='INVALID_ACTION' in d['events']
                counts['threatened']+=bool(d['threatened'])
                counts['masked_safe_bomb']+=bool(d['mask'][5] and d['safe'][5])
                if d['mask'][5] and d['safe'][5] and d['enemy_hits']:
                    state=restore(d['state']);exits=[int(n) for n in enemy_exit_counts(state,state['self'][3])]
                    tag='exit_'+str(min(min(exits),2))
                    counts['attack_opportunities']+=1
                    counts['attack_opportunities_'+tag]+=1
                    counts['attack_taken']+=d['action']==5
                    counts['attack_taken_'+tag]+=d['action']==5
                    counts['attack_opportunities_calm']+=not d['threatened']
                    counts['attack_taken_calm']+=d['action']==5 and not d['threatened']
                    action_q[tag].append(float(d['q'][5]-max(q for q,m in zip(d['q'][:5],d['mask'][:5]) if m)) if any(d['mask'][:5]) else 0.)
                    if d['action']!=5 and min(exits)<=1:
                        counts['low_exit_skips']+=1
                        if len(opportunity_examples)<10: opportunity_examples.append(dict(batch=batch,round=index,step=step,action=d['action'],q=d['q'],mask=d['mask'],enemy_exits=exits))
                if not d['threatened'] and d['key'][26]==1:
                    counts['calm_adjacent_coin']+=1
                    counts['calm_adjacent_coin_bomb']+=d['action']==5
                    counts['calm_adjacent_coin_wait']+=d['action']==4
                if d['action']==4 and not d['threatened']:
                    counts['calm_wait']+=1
            last=rr[-1];after=last['after'];self_actor=after['agents'][0]
            end=dict(batch=batch,round=index,win=game['win'],tie=game['tie_for_first'],
                survived=game['survived'],score=game['score'],steps=game['steps'],
                others_alive=sum(not a['dead'] for a in after['agents'][1:]),
                best_other_score=max(a['score'] for a in after['agents'][1:]),
                coins_remaining=len(after['coins']),crates_remaining=after['crates'],
                last60_subject_score_gain=after['score']-rr[max(0,len(rr)-61)]['after']['score'])
            ends.append(end)
            episode_summaries.append(dict(**end,bombs=bomb_totals(local_bombs),
                empty_attack_bombs=sum(b['category']=='attack_only' and not b['hits'] for b in local_bombs)))
            if not game['win'] and game['survived']:
                streak=[b for b in local_bombs if b['category']=='attack_only' and not b['hits']]
                if len(streak)>=3:
                    examples.append(dict(**end,empty_attack_bombs=len(streak),
                        bombs=[{k:b[k] for k in ('step','position','target_names','min_exits','enemy_escape','coin_distance','repeat_after_empty')} for b in streak[:8]]))
        with gzip.open(folder/'trace.jsonl.gz','rt',encoding='utf-8') as f:
            for line in f:
                r=json.loads(line)
                if round_records and round_records[0]['round']!=r['round']:
                    process(round_records);round_records=[]
                round_records.append(r)
        process(round_records)
        print(arm,batch,'analyzed',flush=True)
    assert len(ends)==300
    summary=summarize(games,'tree_fqi')
    for key,value in dict(bombs=len(all_bombs),kills=sum(len(b['hits']) for b in all_bombs),
        crates=sum(b['crates'] for b in all_bombs),suicides=sum(len(b['self_hits']) for b in all_bombs)).items():
        assert summary['totals'][key]==value
    categories={k:bomb_totals(v) for k,v in grouped.items()}
    attack=[b for b in all_bombs if b['target_names']]
    lost=[e for e in ends if not e['win']]
    alive_lost=[e for e in lost if e['survived']]
    aliases=defaultdict(list)
    for b in attack:
        aliases[tuple(b['key'])].append(b)
    conflicting=[bb for bb in aliases.values() if any(any(e['viable_first_actions']==0 for e in b['enemy_escape']) for b in bb)
                 and any(all(e['viable_first_actions']>0 for e in b['enemy_escape']) for b in bb)]
    alias_examples=[]
    for bb in conflicting[:3]:
        trapped=next(b for b in bb if any(e['viable_first_actions']==0 for e in b['enemy_escape']))
        escaped=next(b for b in bb if all(e['viable_first_actions']>0 for e in b['enemy_escape']))
        np.testing.assert_allclose(trapped['q'],escaped['q'],atol=1e-12)
        alias_examples.append([{k:b[k] for k in ('batch','round','step','key','q','enemy_escape')} for b in (trapped,escaped)])
    result=dict(summary=summary,actions=dict(counts),bombs=bomb_totals(all_bombs),categories=categories,
        by_min_exits={str(n):bomb_totals([b for b in attack if min(b['min_exits'],2)==n]) for n in (0,1,2)},
        attack_bombs_with_close_coin=bomb_totals([b for b in attack if 0<=b['coin_distance']<=2]),
        attack_only_repeat_after_empty=bomb_totals([b for b in attack if b['category']=='attack_only' and b['repeat_after_empty']]),
        attack_only_optimistic_no_trap=bomb_totals([b for b in attack if b['category']=='attack_only' and all(e['viable_first_actions']>0 for e in b['enemy_escape'])]),
        targets=dict(total=len(escape_targets),has_known_hazard_escape=sum(e['viable_first_actions']>0 for e in escape_targets),
            no_known_hazard_escape=sum(e['viable_first_actions']==0 for e in escape_targets),
            already_no_escape_without_bomb=sum(e['viable_first_actions_without_bomb']==0 for e in escape_targets),
            new_trap_created=sum(e['viable_first_actions']==0 and e['viable_first_actions_without_bomb']>0 for e in escape_targets),
            hit_with_escape=sum(e['hit'] and e['viable_first_actions']>0 for e in escape_targets),
            hit_without_escape=sum(e['hit'] and e['viable_first_actions']==0 for e in escape_targets),
            off_ray_within_two=sum(0<=e['static_steps_off_ray']<=2 for e in escape_targets)),
        endings=dict(nonwins=len(lost),alive_nonwins=len(alive_lost),
            alive_nonwins_behind=sum(e['score']<e['best_other_score'] for e in alive_lost),
            alive_nonwins_tied=sum(e['tie'] for e in alive_lost),
            sole_survivor_nonwins=sum(e['others_alive']==0 for e in alive_lost),
            alive_nonwins_score_stalled_last60=sum(e['last60_subject_score_gain']==0 for e in alive_lost),
            reached_time_limit=sum(e['steps']==400 for e in ends)),
        bomb_advantage_median={k:float(np.median(v)) for k,v in action_q.items()},
        identical_28_keys_with_different_escape=dict(keys=len(conflicting),bombs=sum(len(bb) for bb in conflicting),
            examples=alias_examples),
        posthumous_kill_credits=sum(len(b['hits']) for b in all_bombs if b.get('owner_alive_at_detonation') is False))
    save(OUT/f'{arm}_bomb_analysis.json',all_bombs)
    save(OUT/f'{arm}_endings.json',episode_summaries)
    save(OUT/f'{arm}_examples.json',dict(survived_nonwins=examples[:15],skipped_low_exit_opportunities=opportunity_examples))
    return result


def main():
    assert read(OUT/'verification.json')['verified']
    result={a:analyze_arm(a) for a in ('baseline','teacher')}
    result['interpretation_limits']=['Descriptive replays, not new test maps or causal interventions.',
        'Optimistic enemy paths omit other players and unknown future bombs.',
        'Bombs with no kill or crate may still force movement or deny space.',
        'A target already trapped by existing bombs does not prove our additional bomb was necessary.']
    save(OUT/'analysis.json',result)
    save(OUT/'analysis_provenance.json',dict(script_sha256=digest(Path(__file__)),
        input_verification_sha256=digest(OUT/'verification.json'),
        outputs={p.name:digest(p) for p in OUT.glob('*analysis.json')}))
    print(json.dumps({a:result[a] for a in ('baseline','teacher')},indent=2))


if __name__=='__main__':main()
