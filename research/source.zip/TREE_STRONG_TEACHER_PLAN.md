# Fixed strong-opponent teacher substitution

Authorized by the user: continue modifying after the reward ablation failed.
Test the missing mature-teacher trajectories against three rule-based opponents.
Do not use the unsuccessful timed-feature or narrow-reward changes.

Control: retained 28-feature teacher model
b549995f80ab880bb3b64720bebf9d5db7f5186dcf71c67a15423174fe22bea1.
Candidate: preserve rounds 1..300 of that model's dataset byte-for-byte; replace
rounds 301..400 (safe-random strong opponents) with frozen q_guard trajectories.
Use the SAME original 100 strong initial maps, seed567001, q_guard policyseed42.
Teacher weights remain the adopted1150-episode checkpoint
7af75146369354d6162fa6b4311f5644ca489b418df543d79060f628fc9c5707.
Teacher inference is unchanged; collection observes complete episodes, including
delayed post-death bomb credit. No performance filtering or failed-episode removal.

Episode budget remains400 (320fit/80diagnostic using episode%5). Strong episodes
remain100; teacher episodes rise100->200 and random episodes fall300->200.
Transition counts may differ with lifetimes: equal episode budget is NOT equal
transition budget. This experiment tests substitution of behavior data and its
coverage tradeoff, not merely adding more data. No direct imitation loss.

Before fitting, run the existing observer unit tests; replay two random strong
episodes and compare every original array and full action hash; compare two
unobserved teacher games to the observed collection. Audit event counts for all
100 teacher episodes and check feature prefixes, next-state continuity, action
masks, terminal counts, map hashes and episode-wise merging.

Fit from zeroQ with unchanged fit_tree_tactical.py joint mode, seed537001,
20FQI, gamma.9, 6x32ExtraTrees, depth12, leaf8, D4 augmentation/mean, jobs2.
Fixed final iteration20, no hyperparameter/checkpoint selection. Preserve original
joint rewards, safety/retreat inference source and policy random streams.

Evaluate each model on120 fresh maps: mixed627002 x60 and strong627003 x60,
policyseed42. Preflight official maps against all historical games, including
collection maps, then match actual hashes. Four isolated jobs, prediction single
thread. Complete all240 games regardless of intermediate outcomes. Primary
comparison candidate-control across equal mixed/strong strata; bootstrap10000,
seed627900. Report scene and pooled strict wins, score, coins, kills, suicides,
survival, bombs, invalids and latency. Ties are not strict wins.

Positive screen: higher wins AND mean score AND no more suicides. Separately
report win-difference95%CI. One training seed only; positive screening is not
proof of stable superiority. No automatic adoption or submission replacement.
Preserve previous models, experiment records and submitted Superfortress ZIP.
