"""Descriptive support audit on the shared first batch's held-out episodes."""
from pathlib import Path

import numpy as np

from experiment_tree_fqi import read
from experiment_tree_fqi_batches import save
from finalize_guard_release import digest
from fit_tree_fqi import read_data
from agent_code.tree_fqi.model import D4Queries, load_model, transform_keys
from agent_code.tree_fqi.symmetry_maps import PERMUTATIONS

ROOT = Path(__file__).resolve().parent
OUT = ROOT/'experiments/tree_fqi_random_v1'
PREVIOUS = ROOT/'experiments/tree_fqi_batches_v1'


def packed_rows(array):
    array = np.ascontiguousarray(array, dtype=np.int8)
    return array.view(np.dtype(f'V{array.shape[1]}')).ravel().tolist()


def support(data):
    train = data['round'] % 5 != 0
    x, actions = data['x'][train], data['a'][train]
    seen = set()
    for permutation in PERMUTATIONS:
        pairs = np.column_stack((transform_keys(x, permutation), np.asarray(permutation)[actions]))
        seen.update(packed_rows(pairs))
    return seen


def main():
    assert read(OUT/'status.json')['phase'] in ('evaluating', 'complete')
    frozen = read(OUT/'frozen_models.json')
    first = read_data(PREVIOUS/'batch_1/collection/data')
    heldout = first['round'] % 5 == 0
    x, masks = first['x'][heldout], first['mask'][heldout]
    all_pairs = packed_rows(np.column_stack((np.repeat(x, 6, axis=0), np.tile(np.arange(6), len(x)))))
    queries = D4Queries(x)
    results = {}
    for name, folder, model in (
            ('random', OUT/'cumulative_data', OUT/'fit/model.pkl'),
            ('batched', PREVIOUS/'cumulative_data', PREVIOUS/'batch_3/fit/model.pkl')):
        data = read_data(folder)
        assert digest(model) == frozen[name]
        seen = support(data)
        predictor, _ = load_model(model)
        q = queries.predict(predictor.forest)
        best = np.isclose(q, np.where(masks, q, -np.inf).max(axis=1)[:, None]) & masks
        weights = best / best.sum(axis=1)[:, None]
        absent = np.array([pair not in seen for pair in all_pairs]).reshape(-1, 6)
        train = data['round'] % 5 != 0
        results[name] = dict(training_transitions=int(train.sum()),
            unique_training_feature_keys=len(np.unique(data['x'][train], axis=0)),
            unique_training_state_actions=len(np.unique(np.column_stack((data['x'][train], data['a'][train])), axis=0)),
            unique_d4_state_actions=len(seen), training_action_counts=np.bincount(data['a'][train], minlength=6).tolist(),
            common_holdout_observations=len(x),
            unseen_allowed_action_fraction=float(absent[masks].mean()),
            unseen_greedy_choice_probability=float((weights*absent).sum(axis=1).mean()),
            greedy_action_probabilities=weights.mean(axis=0).tolist(),
            mean_max_allowed_q=float(np.where(masks, q, -np.inf).max(axis=1).mean()))
    save(OUT/'support_audit.json', dict(results=results,
        state_source='Shared first-batch validation episodes (rounds divisible by five); neither model fitted these episodes.',
        actions=['UP', 'RIGHT', 'DOWN', 'LEFT', 'WAIT', 'BOMB'],
        note='Descriptive feature/action support only, with exact D4 augmentation and uniform averaging over near-tied greedy choices. Unseen does not imply wrong and observed does not imply safe. State observations are correlated; this is not an independent win-rate test or a causal diagnosis.'))
    print(results)


if __name__ == '__main__':
    main()
