"""Exact replay of adopted E's 60 pilot games; no policy interventions."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'experiments/resource_guard_v1'
OUT = ROOT / 'experiments/guard_features_v1'
SCENES = {'mixed': ['rule_based_agent', 'coin_collector_agent', 'peaceful_agent'],
          'strong': ['rule_based_agent'] * 3}


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(value, indent=2), encoding='utf-8')
    temp.replace(path)


def stable(path):
    rows = [json.loads(line) for line in path.read_text().splitlines()]
    for row in rows:
        row.pop('subject_max_action_ms')
        for stats in row['agents'].values():
            stats.pop('time', None)
    return rows


def main():
    current, original = read(ROOT / 'CURRENT_CANDIDATE.json'), read(SOURCE / 'config.json')
    assert current['agent'] == 'q_guard' and current['episodes'] == 1150
    assert read(SOURCE / 'review_verification.json')['verified']
    assert read(ROOT / 'experiments/resource_guard_adoption_v1/verification.json')['actions_and_results_identical']
    assert digest(ROOT / current['model']) == digest(SOURCE / 'E/model.json') == current['model_sha256']
    assert all(digest(ROOT / p) == h for p, h in current['code_sha256'].items())
    assert all(digest(SOURCE / 'workspace' / p) == h for p, h in original['locked_sha256'].items())
    OUT.mkdir(parents=True, exist_ok=False)
    protected = {p: digest(ROOT / p) for p in ('CURRENT_CANDIDATE.json', current['model'],
                  'release/final_v1/final-project-agent-code.zip')}
    protected.update(current['code_sha256'])
    template = (ROOT / 'diagnose_switch_fighter.py').read_text(encoding='utf-8')
    instrumentation = template.replace('q_switch', 'q_switch_v2').replace('run_fighter_match', 'run_resource_guard_match')
    (OUT / 'diagnose_guard_fighter.py').write_text(instrumentation, encoding='utf-8')
    save(OUT / 'config.json', dict(started_at=datetime.now(timezone.utc).isoformat(), source=str(SOURCE),
         agent_in_replay='q_switch_v2', adopted_equivalent='q_guard', mode='E', training=False, replay_matches=60,
         independent_new_matches=0, evaluation_seeds=original['evaluation_seeds'], protected_sha256=protected,
         instrumentation_sha256=digest(OUT / 'diagnose_guard_fighter.py')))
    save(OUT / 'status.json', dict(phase='replaying', matches=60, pid=os.getpid()))
    for scene in SCENES:
        workspace = OUT / 'workspaces' / scene
        shutil.copytree(SOURCE / 'workspace', workspace, ignore=shutil.ignore_patterns('logs', '__pycache__'))
        (workspace / 'logs').mkdir(exist_ok=True)
        (workspace / 'diagnose_guard_fighter.py').write_text(instrumentation, encoding='utf-8')

    def replay(scene, opponents, seed):
        workspace, target = OUT / 'workspaces' / scene, OUT / scene
        command = [sys.executable, str(workspace / 'diagnose_guard_fighter.py'), '--output', str(target),
            '--agent', 'q_switch_v2', '--model', str(SOURCE / 'E/model.json'), '--rounds', '30',
            '--seed', str(seed), '--score-details', '--opponents', *opponents]
        with (OUT / (scene + '_process.log')).open('w') as handle:
            subprocess.run(command, cwd=workspace, env={**os.environ, 'QL_GUARD_MODE': 'E',
                'QL_GUARD_TRACE': str(target / 'policy.trace.jsonl')}, stdout=handle, stderr=subprocess.STDOUT, check=True)
        assert stable(target / 'match.rounds.jsonl') == stable(SOURCE / 'E' / ('pilot_' + scene + '.rounds.jsonl'))
        assert digest(target / 'policy.trace.jsonl') == digest(SOURCE / 'E' / ('pilot_' + scene + '.trace.jsonl'))
        assert all(digest(workspace / p) == h for p, h in original['locked_sha256'].items())
        print(scene + ': 30 games, executed-action hashes and full policy traces identical', flush=True)

    try:
        with ThreadPoolExecutor(max_workers=2) as pool:
            jobs = [pool.submit(replay, scene, opponents, original['evaluation_seeds'][i])
                    for i, (scene, opponents) in enumerate(SCENES.items())]
            for job in jobs:
                job.result()
        assert all(digest(ROOT / p) == h for p, h in protected.items())
        save(OUT / 'replay_verification.json', dict(verified=True, matches=60, exact_actions_and_traces=True,
            source_unchanged=True, protected_sha256=protected,
            output_sha256={str(p.relative_to(OUT)): digest(p) for s in SCENES for p in
              (OUT / s / 'score_frames.jsonl.gz', OUT / s / 'match.rounds.jsonl', OUT / s / 'policy.trace.jsonl')}))
        save(OUT / 'status.json', dict(phase='replay_complete', needs_analysis=True, matches=60))
    except Exception as exc:
        save(OUT / 'status.json', dict(phase='failed', error=repr(exc)))
        raise


if __name__ == '__main__':
    main()
