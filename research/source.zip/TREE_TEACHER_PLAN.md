# Teacher-trajectory mixture: one fixed tree FQI experiment

Current adopted tree: tree_guard, checkpoint SHA256
397045e64700cb64b3413c1145c3ace4bad258e53ed8db2657feaed8d1ce5ed9.
Test whether better behavior data improves this same learning architecture.

Replace original random episodes 201..300 with 100 complete frozen q_guard
trajectories on their exact initial maps (mixed seed 537201, policy seed 42).
Keep all original episodes 1..200 and 301..400 byte-identical. This retains
300 safe-random episodes and replaces one 100-episode mixed-opponent batch.
Include all teacher wins/losses, without selection or per-action mixing.
The original and mixed datasets both have 300 mixed / 100 strong episodes,
320 training / 80 diagnostic episodes, split by round ID modulo five.
Equal episode budget does not imply equal transition counts. Report both.
The teacher itself has prior 1150-episode training and extra inference rules;
this is privileged behavior data, not a claim of equal total training cost.

Observe the teacher in inference mode. Keep its actions and RNG untouched.
Record all one-step transitions with original rewards, then apply the same
joint reward subtraction during fitting. Use the established episode-terminal
semantics, including events credited after the subject dies, and next-state
clock correction. Before fitting, verify two random episodes reproduce every
stored array and full action hashes; verify the first two teacher episodes
against an unobserved run. Check contiguous steps, terminal records, safety
masks, 16-feature prefix, and next features/masks matching the next decision.

Fit one candidate from zero Q: joint mode, seed 537001, original CONFIG
(20 rounds, gamma .9, 6 heads x 32 trees, depth12, leaf8, D4 augmentation and
mean inference). Reuse the verified original checkpoint as the random-data
control. No checkpoint selection or hyperparameter sweep. Both evaluation
arms use the identical adopted tree_guard inference code and escape rule.

After freezing the trained checkpoint: each arm receives 120 fresh paired maps,
60 mixed at seed 587002 and 60 strong at 587003, policy seed42. Verify no overlap
with any prior recorded map hashes, including data collection. Report strict
wins, score, coins, kills, suicides, survival, invalid actions and latency.
Paired stratified bootstrap10000, seed587900, win and score differences.

A candidate is promising if win count and mean score both improve without
more suicides. Separately report whether win-difference CI is above zero;
positive point estimates alone are not proof of stable superiority. No automatic
overwrite of CURRENT_TREE_RESEARCH or the submitted block-Q agent. Keep all
frozen source/data artifacts. Record intentional prior inventory documentation
updates from the user-adoption audit instead of silently invalidating hashes.
