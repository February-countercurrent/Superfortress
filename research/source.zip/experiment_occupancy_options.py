"""Sequential four-arm prespecified screen; unchanged weights and paired maps."""
import argparse
from datetime import datetime, timezone
import os
from pathlib import Path
import shutil
import sys
from occupancy_options_experiment import ROOT, ARMS, SCENES, read, save, digest, run, analyze


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--name', default='occupancy_options_v1')
    parser.add_argument('--rounds', type=int, default=30)
    parser.add_argument('--seed', type=int, default=317002)
    args = parser.parse_args()
    assert Path(args.name).name == args.name and args.name not in ('.', '..') and args.rounds > 0
    checks = read(ROOT / 'experiments/occupancy_options_checks_v1/verification.json')
    assert checks['verified']
    protected = {**checks['protected_sha256'], **checks['code_sha256']}
    assert all(digest(ROOT / p) == h for p, h in protected.items())
    if args.rounds > 1:
        assert read(ROOT / 'experiments/occupancy_options_smoke_v1/review_verification.json')['verified']
    source = ROOT / 'agent_code/q_guard/model.json'
    output = ROOT / 'experiments' / args.name
    output.mkdir(parents=True, exist_ok=False)
    workspace = output / 'workspace'
    shutil.copytree(ROOT, workspace, ignore=shutil.ignore_patterns('.git', 'experiments', 'release', 'logs', '__pycache__'))
    (workspace / 'logs').mkdir(exist_ok=True)
    locked = {str(p.relative_to(workspace)): digest(p) for p in list(workspace.glob('*.py')) + list((workspace / 'agent_code').rglob('*.py'))}
    config = dict(started_at=datetime.now(timezone.utc).isoformat(), pid=os.getpid(), arms=list(ARMS),
        primary='tie_minus_control', rounds_each_scene=args.rounds, total_matches=8 * args.rounds,
        evaluation_seeds=[args.seed, args.seed + 1], bootstrap_seed=args.seed + 2, training=False,
        model_episodes=1150, model_sha256=digest(source), source_sha256=protected, locked_sha256=locked,
        rng_protocol='round_isolated_v1', python=sys.version)
    save(output / 'config.json', config)
    completed, summary = 0, {}

    def status(phase, **extra):
        save(output / 'status.json', dict(phase=phase, completed_batches=completed, total_batches=8,
            pid=os.getpid(), updated_at=datetime.now(timezone.utc).isoformat(), **extra))

    try:
        for arm in ARMS:
            folder = output / arm
            folder.mkdir()
            shutil.copy2(source, folder / 'model.json')
            agent = 'q_guard' if arm == 'control' else 'q_guard_options'
            for si, scene in enumerate(SCENES):
                status(arm + '_' + scene)
                result = run(workspace, folder, scene, agent, folder / 'model.json', args.rounds, args.seed + si,
                    option='tie' if arm == 'control' else arm)
                summary[arm + '_' + scene] = result
                print(arm, scene, result, flush=True)
                assert digest(folder / 'model.json') == config['model_sha256']
                assert all(digest(ROOT / p) == h for p, h in protected.items())
                assert all(digest(workspace / p) == h for p, h in locked.items())
                completed += 1
                save(output / 'summary.json', summary)
        result = analyze(output)
        save(output / 'verification.json', dict(verified=True, matches=config['total_matches'],
            no_training=True, output_sha256={'comparison.json': digest(output / 'comparison.json'), **result['raw_sha256']}))
        status('complete', needs_review=True)
        print(result['raw_counts'], flush=True)
    except Exception as exc:
        status('failed', error=repr(exc))
        raise


if __name__ == '__main__':
    main()
