"""Summarize observational failures and independently check frozen-world escapes."""
from collections import Counter
import json
from pathlib import Path
import sys
import numpy as np
import settings

ROOT = Path(__file__).parent
ACTIONS = ['UP', 'RIGHT', 'DOWN', 'LEFT', 'WAIT', 'BOMB']
DELTAS = [(0, -1), (1, 0), (0, 1), (-1, 0), (0, 0)]


def forward_safe(state, action):
    """Forward reachability, independent of production backward forecast.

    Opponents stay fixed; no future new bombs. Crates block movement but not
    flames. An existing timer zero detonates after this action's movement.
    """
    field = np.array(state['field']).copy()
    flames = np.array(state['explosion_map']).copy()
    bombs = [(tuple(p), t) for p, t in state['bombs']]
    start = tuple(state['self'][3])
    others = {tuple(a[3]) for a in state['others']}
    if action == 5:
        if not state['self'][2]:
            return False
        bombs.append((start, settings.BOMB_TIMER))
    reachable = {start}
    horizon = max([1, int(flames.max())] + [t + settings.EXPLOSION_TIMER for _, t in bombs])
    for tick in range(horizon):
        occupied = {p for p, _ in bombs}
        destinations = set()
        moves = [DELTAS[action if action < 5 else 4]] if tick == 0 else DELTAS
        for x, y in reachable:
            for dx, dy in moves:
                p = x + dx, y + dy
                if field[p] == 0 and p not in others and (p == (x, y) or p not in occupied):
                    destinations.add(p)
        lethal = set(map(tuple, np.argwhere(flames > 0)))
        flames = np.maximum(flames - 1, 0)
        remaining = []
        for p, timer in bombs:
            if timer > 0:
                remaining.append((p, timer - 1))
                continue
            ray = [p]
            for dx, dy in DELTAS[:4]:
                for radius in range(1, settings.BOMB_POWER + 1):
                    cell = p[0] + dx * radius, p[1] + dy * radius
                    if field[cell] == -1:
                        break
                    ray.append(cell)
            for cell in ray:
                lethal.add(cell)
                flames[cell] = settings.EXPLOSION_TIMER - 1
                if field[cell] == 1:
                    field[cell] = 0
        bombs = remaining
        reachable = destinations - lethal
        if not reachable:
            return False
    return bool(reachable)


def main():
    output = Path(sys.argv[1])
    decisions = [json.loads(line) for line in (output / 'decisions.jsonl').read_text().splitlines()]
    matches = [json.loads(line) for line in (output / 'match.rounds.jsonl').read_text().splitlines()]
    reference = [json.loads(line) for line in (ROOT / 'experiments/fighter_strong_v1/holdout_baseline.rounds.jsonl').read_text().splitlines()]
    def stable(rows):
        for row in rows:
            for agent in row['agents'].values():
                agent.pop('time', None)
        return rows
    summary = {'rounds': len(matches), 'reference_identical_except_time': stable(matches) == stable(reference[:len(matches)]),
               'decisions': len(decisions), 'q_sources': dict(Counter(f['q_source'] for f in decisions)),
               'no_safe_decisions': sum(not any(f['info']['safe']) for f in decisions)}
    failures = []
    mismatches = []
    checked = 0
    for path in sorted(output.glob('death_*.json')):
        frames = json.loads(path.read_text())
        last = frames[-1]
        # Last entry into a continuous no-safe segment ending at death.
        onset = len(frames) - 1
        if not any(last['info']['safe']):
            while onset > 0 and not any(frames[onset - 1]['info']['safe']):
                onset -= 1
        trigger = frames[max(0, onset - 1)] if not any(last['info']['safe']) else last
        own = next(a for a in trigger['actions'] if a['agent'] == 'q_fighter')
        invalid = 'INVALID_ACTION' in own['events']
        chosen = ACTIONS.index(trigger['chosen'])
        dest = (own['before'][0] + DELTAS[chosen][0], own['before'][1] + DELTAS[chosen][1]) if chosen < 4 else None
        blockers = [a['agent'] for a in trigger['actions'] if a['agent'] != 'q_fighter' and tuple(a['after']) == dest]
        new_bombs = [a for a in trigger['actions'] if a['agent'] != 'q_fighter' and 'BOMB_DROPPED' in a['events']]
        counterfactual = {}
        if not invalid and onset > 0 and not any(last['info']['safe']):
            post = frames[onset]['state']
            old_positions = {a[0]: a[3] for a in trigger['state']['others']}
            frozen_others = [[*a[:3], old_positions.get(a[0], a[3])] for a in post['others']]
            new_positions = {tuple(a['after']) for a in new_bombs}
            no_new_bombs = [b for b in post['bombs'] if tuple(b[0]) not in new_positions]
            for label, changes in [('restore_opponent_positions', {'others': frozen_others}),
                                   ('remove_new_enemy_bombs', {'bombs': no_new_bombs}),
                                   ('both', {'others': frozen_others, 'bombs': no_new_bombs})]:
                counterfactual[label] = any(forward_safe({**post, **changes}, a) for a in range(6))
        failures.append({'round': last['round'], 'death_step': last['step'], 'trigger_step': trigger['step'],
            'death_had_safe': any(last['info']['safe']), 'trigger_action': trigger['chosen'],
            'trigger_predicted_safe': trigger['info']['safe'][chosen], 'invalid_at_trigger': invalid,
            'destination_occupied_by': blockers, 'new_enemy_bombs_at_trigger': new_bombs,
            'lethal': last['lethal'], 'trigger_q_source': trigger['q_source'], 'counterfactual': counterfactual})
        for frame in frames:
            predicted = frame['info']['safe']
            actual = [forward_safe(frame['state'], a) for a in range(6)]
            checked += 6
            if predicted != actual:
                mismatches.append({'round': frame['round'], 'step': frame['step'], 'backward': predicted, 'forward': actual})
    summary.update({'deaths': len(failures), 'own_bomb_deaths': sum(any(b['owner'] == 'q_fighter' for b in f['lethal']) for f in failures),
        'death_with_safe_action': sum(f['death_had_safe'] for f in failures),
        'invalid_at_last_safe_transition': sum(f['invalid_at_trigger'] for f in failures),
        'opponent_at_failed_destination': sum(f['invalid_at_trigger'] and bool(f['destination_occupied_by']) for f in failures),
        'forward_actions_checked': checked, 'forward_mismatches': mismatches, 'failures': failures})
    (output / 'analysis.json').write_text(json.dumps(summary, indent=2))
    print(json.dumps({k: v for k, v in summary.items() if k != 'failures'}, indent=2))


if __name__ == '__main__':
    main()
