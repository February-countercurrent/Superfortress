"""Post-run integrity and descriptive data coverage; never selects a model."""
from pathlib import Path
import numpy as np
from experiment_tree_fqi import read,rows
from experiment_tree_fqi_batches import save
from finalize_guard_release import digest
from fit_tree_fqi import read_data

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'experiments/tree_tactical_v3'


def main():
    assert read(OUT/'status.json')['phase']=='complete'
    assert read(OUT/'verification.json')['verified']
    data=read_data(OUT/'data');validation=data['round']%5==0
    np.testing.assert_array_equal(data['tactical_x'][:,:16],data['x'])
    np.testing.assert_array_equal(data['tactical_next_x'][:,:16],data['next_x'])
    assert not data['tactical_next_x'][data['terminal']].any()
    descriptions={}
    for label,mask in (('training',~validation),('validation',validation)):
        x=data['tactical_x'][mask];a=data['a'][mask];bonus=data['open_attack_bonus'][mask]
        descriptions[label]=dict(games=len(set(data['round'][mask])),transitions=len(x),
            actions=np.bincount(a,minlength=6).tolist(),
            unique_16_states=len(np.unique(x[:,:16],axis=0)),
            unique_28_states=len(np.unique(x,axis=0)),
            feature_ranges=[dict(min=int(c.min()),max=int(c.max())) for c in x[:,16:].T],
            bomb_actions=int((a==5).sum()),reward_adjusted_actions=int((bonus>0).sum()),
            removed_bonus_sum=float(bonus.sum()))
    historical=set();files=0
    for experiment in (ROOT/'experiments').iterdir():
        if not experiment.is_dir() or experiment.name.startswith('tree_tactical_'):continue
        for path in experiment.rglob('*.rounds.jsonl'):
            if 'workspaces' in path.parts:continue
            for row in rows(path):
                if row.get('map_hash'):historical.add(row['map_hash'])
            files+=1
    current={phase:{r['map_hash'] for scene in ('mixed','strong')
        for r in rows(OUT/phase/'pilot'/(scene+'.rounds.jsonl'))}
        for phase in ('screen','holdout')}
    assert len(current['screen'])==60 and len(current['holdout'])==120
    assert not current['screen'] & current['holdout']
    assert not (current['screen'] | current['holdout']) & historical
    failed=ROOT/'experiments/tree_tactical_v1'
    assert read(failed/'status.json')['phase']=='failed'
    assert not (failed/'training_config.json').exists() and not (failed/'fit').exists()
    previous=ROOT/'experiments/tree_tactical_v2'
    assert read(previous/'status.json')['phase']=='interrupted_before_enhanced_fits'
    assert not (previous/'fit/tactical').exists() and not (previous/'fit/joint').exists()
    prior_data=read_data(previous/'data')
    for name in data:
        if name!='tactical_next_x':np.testing.assert_array_equal(data[name],prior_data[name])
    difference=data['tactical_next_x']!=prior_data['tactical_next_x']
    assert not difference[:,:27].any() and int(difference.sum())==627
    live=~data['terminal'][:-1]
    np.testing.assert_array_equal(data['tactical_next_x'][:-1][live],data['tactical_x'][1:][live])
    assert digest(previous/'fit/control/model.pkl')==digest(OUT/'fit/control/model.pkl')
    assert read(OUT/'verification/collection_replay/verification.json')['verified']
    assert read(OUT/'same_data_comparison.json')['original_selection_and_decision_unchanged']
    save(OUT/'supplementary_audit.json',dict(verified=True,data=descriptions,
        historical_result_files=files,historical_maps=len(historical),
        all_historical_recorded_maps_disjoint_from_new_evaluation=True,
        failed_first_collection=dict(path=str(failed.relative_to(ROOT)),never_fitted=True,
            status_sha256=digest(failed/'status.json'),config_sha256=digest(failed/'data_config.json'),
            reason='Pre/post-action observations shared round/step. Snapshot identity cache fixes extra next-state features.'),
        clock_repair=dict(corrected_values=627,all_other_values_unchanged=True,
            no_28_feature_fit_used_unrepaired_data=True,original_16_control_reused_exactly=True,
            next_features_match_following_decisions=True,fresh_collection_equivalent_games=2,
            fresh_collection_equivalent_transitions=800),
        unit_checks=dict(passed=28,modules=['test_tree_tactical','test_fit_tree_tactical',
            'test_tree_fqi','test_tree_fqi_batches','test_tree_fqi_coin']),
        submission_sha256=digest(ROOT/'release/Superfortress_v1/final-project-agent-code.zip'),
        selected_sha256=digest(OUT/'selected/model.pkl'),
        note='State counts are descriptive, not a causal performance diagnosis. First failed collection is excluded.'))
    names=('audit_tree_tactical.py','plot_tree_tactical.py','tree_tactical_status.py',
           'verify_tree_tactical_collection.py','evaluate_tree_tactical_control.py',
           'TREE_TACTICAL_CONTROL_PLAN.md','agent_code/tree_tactical/README.md',
           'TREE_TACTICAL_RESULTS.md','METHODS_INVENTORY.md')
    save(OUT/'supplementary_sources.json',{n:digest(ROOT/n) for n in names})
    print('Verified:',len(data['a']),'transitions;',files,'historical result files;',len(historical),'prior maps')


if __name__=='__main__':main()
