"""Replay fixed behavior; append current and next-decision timed descriptors.

All old arrays, including rewards, are copied exactly from the verified dataset.
Next inputs come from the actual next observed decision, not a post-action clock.
"""
import argparse
import importlib
from pathlib import Path
import sys
import numpy as np
from agent_code.tree_timed.timed import timed_key
from agent_code.tree_timed.features import ACTIONS
from environment import BombeRLeWorld
import run_tree_fqi_match


def main():
    parser=argparse.ArgumentParser(add_help=False)
    parser.add_argument('--source-data',type=Path,required=True)
    parser.add_argument('--data-dir',type=Path,required=True)
    parser.add_argument('--offset',type=int,required=True)
    parser.add_argument('--random-behavior',action='store_true')
    parser.add_argument('--agent',choices=['q_guard','tree_fqi'],required=True)
    args,rest=parser.parse_known_args()
    args.data_dir.mkdir(parents=True,exist_ok=False)
    callback=importlib.import_module('agent_code.'+args.agent+'.callbacks')
    original_act,original_setup=callback.act,callback.setup
    original_step=BombeRLeWorld.do_step
    pending=[];records=[]
    def setup(policy):
        original_setup(policy)
        if args.random_behavior:
            assert args.agent=='tree_fqi'
            policy.train=True;policy.epsilon=1.
    def act(policy,state):
        action=original_act(policy,state)
        pending.append((state,action))
        return action
    def step(world,*aa,**kw):
        pending.clear();result=original_step(world,*aa,**kw)
        assert len(pending)<=1
        for state,action in pending:
            executed=[a for s,slot,a in world.match_actions if s==world.step and slot==0]
            assert executed==[action]
            records.append((state['step'],ACTIONS.index(action),timed_key(state)))
        if not world.running:
            episode=world.round+args.offset
            with np.load(args.source_data/f'round_{episode:05d}.npz',allow_pickle=False) as z:
                data={n:z[n].copy() for n in z.files}
            assert 'timed_x' not in data
            np.testing.assert_array_equal([r[0] for r in records],data['step'])
            np.testing.assert_array_equal([r[1] for r in records],data['a'])
            x=np.asarray([r[2] for r in records],dtype=np.int8)
            next_x=np.zeros_like(x);next_x[:-1]=x[1:]
            assert data['terminal'].sum()==1 and data['terminal'][-1]
            np.testing.assert_array_equal(x[:,:28],data['tactical_x'])
            np.testing.assert_array_equal(next_x[:,:28],data['tactical_next_x'])
            data.update(timed_x=x,timed_next_x=next_x)
            with (args.data_dir/f'round_{episode:05d}.npz').open('xb') as f:
                np.savez_compressed(f,**data)
            records.clear()
        return result
    callback.setup,callback.act=setup,act
    BombeRLeWorld.do_step=step
    sys.argv=[sys.argv[0],'--agent',args.agent,*rest]
    run_tree_fqi_match.main()


if __name__=='__main__':main()
