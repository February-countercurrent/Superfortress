# Full-policy continuation, fixed before training

Start from the adopted 1150-episode Q weights AND visit counts. Preserve the
submitted guard_v2 ZIP and all adopted source files. Both arms use the full
deployed D4-average, urgent-escape, resource E behavior. Train on the original
mixed opponents: rule, coin collector, peaceful. No opponent/reward/features changes.

- raw: adopted D4-augmented raw-Q greedy tree backup.
- average: previously numerically verified D4-average Q semi-gradient backup.
- 300 additional episodes per arm, same training seed 347001, epsilon .05,
  alpha .15, rate scale 1/3, gamma .9, n=3, original rewards.
- Exploration before resource controller, with its own per-round RNG stream.
  Actual returned actions are remembered and learned. At epsilon zero,
  chronological behavior must match the submitted policy exactly.
- Target policies remain greedy masked raw Q or average Q. History-dependent
  resource decisions and escape costs are behavior interventions, not target
  features. This is off-policy training, not a claim of complete policy alignment.
- Final checkpoint only (1450 episodes) is eligible. Intermediate checkpoints
  every 25 episodes are recovery artifacts, not a search over validation results.
- Screen each final arm and frozen baseline on 60 mixed + 60 strong rounds,
  map seeds 347002/347003, deployed policy seed 42 for every model.
- Rank by strict wins, then game score, then frozen/raw/average order.
  Advance only if at least 4/120 extra wins and score no lower than baseline.
- If advancing, freeze that choice and compare with baseline on untouched
  60 mixed + 60 strong rounds, seeds 357002/357003. Recommend replacement only
  if paired win 95% bootstrap lower bound >0, total score no lower, and neither
  opponent scene has fewer wins. This is a conservative practical gate, not
  proof of tournament performance or optimal hyperparameters.
- If no arm advances, stop; do not adjust thresholds or search checkpoints.
- Check finite parameters, terminal/update/visit counts, unchanged code hashes,
  paired maps and actual game-score accounting. Compare maps against historical
  evaluations. Maximum 600 training + 600 evaluation games, two CPU workers.

Single continuation seed; two candidate recipes. Results remain exploratory
outside the independent final holdout. No automated upload or submitted-file overwrite.
