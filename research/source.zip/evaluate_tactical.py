"""Frozen Q weights; fixed search design; paired validation and fresh test."""
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import shutil
import hashlib
import numpy as np
from finalize_agent import match

ROOT = Path(__file__).parent.resolve()
OUT = ROOT / 'experiments/tactical_v1'


def worker(name):
    folder = OUT / name
    folder.mkdir()
    workspace = folder / 'workspace'
    shutil.copytree(ROOT, workspace, ignore=shutil.ignore_patterns('.git', 'experiments', 'release', 'logs', '__pycache__'))
    (workspace / 'logs').mkdir(exist_ok=True)
    results = {}
    for label, count, seed in [('validation', 60, 145001), ('holdout', 100, 145002)]:
        (folder / 'status.json').write_text(json.dumps({'phase': label}))
        results[label] = match(workspace, folder, label, ['rule_based_agent'] * 3, count, seed, agent=name)
        (folder / 'results.json').write_text(json.dumps(results, indent=2))
        print(name, label, json.dumps(results[label]), flush=True)
    (folder / 'status.json').write_text(json.dumps({'phase': 'complete'}))
    return name, results


def main():
    OUT.mkdir(exist_ok=False)
    digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
    assert digest(ROOT / 'agent_code/q_final/model.json') == digest(ROOT / 'agent_code/q_tactical/model.json')
    (OUT / 'config.json').write_text(json.dumps({'training': False,
        'model_sha256': digest(ROOT / 'agent_code/q_final/model.json'),
        'validation_seed': 145001, 'holdout_seed': 145002,
        'coefficients': {'trap_bonus': 3., 'pressure_bonus': .8, 'narrow_self_escape_cost': .4},
        'note': 'Only tactical BOMB value adjustment added; no tuning on holdout, no automatic deployment.'}, indent=2))
    with ThreadPoolExecutor(max_workers=2) as pool:
        results = dict(pool.map(worker, ['q_final', 'q_tactical']))
    (OUT / 'results.json').write_text(json.dumps(results, indent=2))
    paired = {}
    for label in ['validation', 'holdout']:
        a, b = [[json.loads(line) for line in (OUT / name / f'{label}.rounds.jsonl').read_text().splitlines()]
                for name in ['q_final', 'q_tactical']]
        assert len(a) == len(b)
        assert all(x['map_hash'] == y['map_hash'] for x,y in zip(a,b))
        ix = np.random.default_rng(496).integers(len(a), size=(20000, len(a)))
        paired[label] = {}
        for key in ['score', 'win', 'survived']:
            d = np.array([float(y[key])-float(x[key]) for x,y in zip(a,b)])
            paired[label][key] = {'difference': float(d.mean()), 'interval95': np.quantile(d[ix].mean(axis=1), [.025,.975]).tolist()}
    (OUT / 'analysis.json').write_text(json.dumps(paired, indent=2))
    (OUT / 'status.json').write_text(json.dumps({'phase': 'complete'}))


if __name__ == '__main__':
    main()
