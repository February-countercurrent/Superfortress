"""Reproduce the accepted policy's complete 120-map baseline for death audits."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
OUT = ROOT/'experiments/symavg_survival_v1'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def stable_rows(path):
    rows = [json.loads(x) for x in path.read_text().splitlines()]
    for row in rows:
        for stats in row['agents'].values():
            stats.pop('time', None)
    return rows


def main():
    accepted = json.loads((ROOT/'CURRENT_CANDIDATE.json').read_text())
    assert accepted['agent'] == 'q_symavg'
    source = ROOT/accepted['model']
    assert digest(source) == accepted['model_sha256']
    assert all(digest(ROOT/p) == h for p,h in accepted['code_sha256'].items())
    OUT.mkdir(parents=True, exist_ok=False)
    workspace = OUT/'workspace'
    shutil.copytree(ROOT, workspace, ignore=shutil.ignore_patterns('.git', 'experiments', 'release', 'logs', '__pycache__'))
    (workspace/'logs').mkdir(exist_ok=True)
    frozen = OUT/'model.json'; shutil.copy2(source, frozen)
    locked = {str(p.relative_to(OUT)): digest(p) for p in (workspace/'agent_code/q_symavg').glob('*.py')}
    for name in ('diagnose_fighter.py', 'run_fighter_match.py', 'environment.py', 'settings.py'):
        locked[str((workspace/name).relative_to(OUT))] = digest(workspace/name)
    scenes = [('mixed', 177002, ['rule_based_agent','coin_collector_agent','peaceful_agent']),
              ('strong', 177003, ['rule_based_agent']*3)]
    (OUT/'config.json').write_text(json.dumps(dict(agent='q_symavg', rounds_each=60,
        seeds=[177002,177003], model_sha256=accepted['model_sha256'], locked_sha256=locked,
        reference='experiments/resource_priority_v1/control_{scene}.rounds.jsonl',
        purpose='Full chronological baseline replay; inspect every death without modifying policy. No new training or win-rate evaluation.'), indent=2))
    try:
        for index,(scene,seed,opponents) in enumerate(scenes):
            (OUT/'status.json').write_text(json.dumps(dict(phase=scene, completed_scenes=index, total_scenes=2)))
            command = [sys.executable, str(workspace/'diagnose_fighter.py'), '--agent','q_symavg',
                       '--model',str(frozen),'--output',str(OUT/scene),'--rounds','60','--seed',str(seed),
                       '--score-details','--opponents',*opponents]
            subprocess.run(command,cwd=workspace,check=True)
            observed = stable_rows(OUT/scene/'match.rounds.jsonl')
            reference = stable_rows(ROOT/f'experiments/resource_priority_v1/control_{scene}.rounds.jsonl')
            assert len(observed) == len(reference) == 60 and observed == reference
            assert all(digest(OUT/p) == h for p,h in locked.items())
            assert digest(source) == digest(frozen) == accepted['model_sha256']
            print(scene, '60 rounds reproduced exactly except timing', flush=True)
        (OUT/'status.json').write_text(json.dumps(dict(phase='replay_complete', completed_scenes=2, total_scenes=2)))
    except Exception as exc:
        (OUT/'status.json').write_text(json.dumps(dict(phase='failed', error=repr(exc))))
        raise


if __name__ == '__main__':
    main()
