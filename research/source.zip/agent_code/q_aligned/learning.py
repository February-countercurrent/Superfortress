"""Prediction and exact linear gradient for the D4-averaged value function."""
from collections import Counter
from functools import lru_cache

import numpy as np

from .callbacks import BLOCKS, active_tiles, values_for, averaged_values
from .symmetry_maps import PERMUTATIONS, transform_key


def learning_values(agent, key):
    mode = getattr(agent, 'learning_value_mode', 'average')
    if mode == 'average':
        return averaged_values(agent, key)
    if mode == 'raw':
        return values_for(agent, key)
    raise ValueError('Unknown learning value mode')


@lru_cache(maxsize=16384)
def averaged_gradient(key, action):
    """Sparse derivative of mean_g Q(g*s, g*a) w.r.t. raw coefficients.

    Keep multiplicities: invariant states and scalar blocks can address the
    same coefficient more than once. There are always 8 * 7 contributions.
    """
    counts = Counter()
    for permutation in PERMUTATIONS:
        for tile in active_tiles(transform_key(key, permutation)):
            counts[tile, permutation[action]] += 1
    return tuple((tile, index, count / len(PERMUTATIONS))
                 for (tile, index), count in sorted(counts.items()))


def averaged_step(agent, key, action, delta, rate):
    if not np.isfinite(delta):
        raise FloatingPointError('Non-finite averaged-Q TD error')
    # Preserve the original nominal rate and seven-block normalization.
    # The target is held fixed: this is a semi-gradient TD update.
    scale = rate * delta / len(BLOCKS)
    for tile, index, derivative in averaged_gradient(tuple(key), action):
        agent.q.setdefault(tile, np.zeros(6))[index] += scale * derivative
