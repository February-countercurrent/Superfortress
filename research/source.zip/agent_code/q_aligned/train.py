"""Terminal-safe Q-learning, optional tree backup, and JSON checkpoints."""
import csv
import json
import os
from pathlib import Path
from collections import Counter

import numpy as np

from .features import ACTIONS, allowed, describe
from .callbacks import values_for, active_tiles, BLOCKS, action_mask
from .symmetry import augmented_update
from .multistep import enqueue
from .learning import learning_values


def setup_training(self):
    if getattr(self, 'training_config', {}).get('inference_only', False):
        raise ValueError('This merged checkpoint is inference-only; continuation counters are undefined')
    self.learning_value_mode = os.environ.get('QL_LEARNING_Q',
        getattr(self, 'learning_value_mode', 'average'))
    if self.learning_value_mode not in ('raw', 'average'):
        raise ValueError('Unknown QL_LEARNING_Q mode')
    self.alpha = float(os.environ.get('QF_ALPHA', '.15'))
    self.bootstrap_dynamic = os.environ.get('QL_BOOTSTRAP_DYNAMIC', '1') == '1'
    self.symmetry = os.environ.get('QL_SYMMETRY', '1') == '1'
    self.n_step = int(os.environ.get('QL_N_STEP', '3'))
    if self.n_step not in (1, 3):
        raise ValueError('QL_N_STEP must be 1 or 3')
    self.transition_queue = []
    self.backup_lengths = Counter()
    self.credit_metrics = Counter()
    if self.learning_value_mode == 'average' and not self.symmetry:
        raise ValueError('Averaged Q requires symmetry enabled')
    self.mask_checks = self.mask_changes = 0
    self.bootstrap_gap_sum = 0.
    self.rate_scale = float(os.environ.get('QL_RATE_SCALE', str(1/3)))
    if not np.isfinite(self.rate_scale) or self.rate_scale <= 0:
        raise ValueError('QL_RATE_SCALE must be finite and positive')
    self.gamma = float(os.environ.get('QF_GAMMA', '.9'))
    self.shaping = float(os.environ.get('QF_SHAPING', '0'))
    self.progress = float(os.environ.get('QF_PROGRESS', '.8'))
    self.decay = float(os.environ.get('QF_DECAY', '.99'))
    self.epsilon_start = float(os.environ.get('QF_EPSILON', '.05'))
    self.death_penalty = float(os.environ.get('QF_DEATH_PENALTY',
                               str(getattr(self, 'training_config', {}).get('death_penalty', 25.))))
    self.start_episode = self.episodes
    self.epsilon = self.epsilon_start
    self.pending = None
    self.counts = Counter()
    self.total_reward = 0.


def update(self, old, action, new, events):
    if old is None or action not in ACTIONS:
        return
    info = describe(old, self.anticipate, getattr(self, 'attack_features', False))
    reward = (8 * events.count('COIN_COLLECTED') + events.count('CRATE_DESTROYED')
              + .5 * events.count('COIN_FOUND') + 15 * events.count('KILLED_OPPONENT')
              - .2 * events.count('BOMB_DROPPED') - events.count('INVALID_ACTION')
              - self.death_penalty * int('GOT_KILLED' in events or 'KILLED_SELF' in events) - .03)
    future, next_potential = 0., 0.
    if new is not None:
        next_info = describe(new, self.anticipate, getattr(self, 'attack_features', False))
        next_values = learning_values(self, next_info['key'])
        base_mask = allowed(next_info, self.shield)
        next_mask = base_mask
        if getattr(self, 'bootstrap_dynamic', False):
            next_mask = action_mask(new, next_info)
            self.mask_checks += 1
            self.mask_changes += int(not np.array_equal(next_mask, base_mask))
            self.bootstrap_gap_sum += float(next_values[base_mask].max() - next_values[next_mask].max())
        future = next_values[next_mask].max()
        next_potential = -next_info['distance']
    reward += self.shaping * (self.gamma * next_potential + info['distance'])
    # Balanced local shaping avoids reward for alternating toward/away moves.
    # This is an experimental reward heuristic, not an optimality guarantee.
    if not info['threatened'] and info['target']:
        if action in ACTIONS[:4]:
            reward += self.progress * info['progress'][ACTIONS.index(action)]
        elif action == 'WAIT' and info['distance'] > 0:
            reward -= self.progress
    if action == 'BOMB':
        reward += .5 * min(info['yield'], 3) if info['safe'][5] else 0.
        reward += 1.5 * info['enemy_hits'] if info['safe'][5] else 0.
        if info['yield'] == 0 and info['enemy_hits'] == 0:
            reward -= 1.
    if action == 'WAIT' and not info['threatened']:
        reward -= .2
    values = learning_values(self, info['key'])
    inherited_visits = self.visits.get(info['key'][:16], np.zeros(6, dtype=int))
    visits = self.visits.setdefault(info['key'], inherited_visits.copy())
    index = ACTIONS.index(action)
    visits[index] += 1
    rate = getattr(self, 'rate_scale', 1.) * max(.02, self.alpha / (1 + visits[index] / 200))
    delta = reward + self.gamma * future - values[index]
    if not np.isfinite(delta):
        raise FloatingPointError('Non-finite linear Q TD error')
    tiles = active_tiles(info['key'])
    # Normalize by active feature count: the total change for this state/action
    # equals the tabular update rate * TD error, rather than seven times that.
    if getattr(self, 'n_step', 1) > 1 or self.learning_value_mode == 'average':
        enqueue(self, dict(key=info['key'], action=index, reward=reward, rate=rate,
                           next_key=next_info['key'] if new is not None else None,
                           mask=next_mask.copy() if new is not None else None))
    elif getattr(self, 'symmetry', False):
        augmented_update(self, info['key'], index,
                         next_info['key'] if new is not None else None,
                         next_mask if new is not None else None, reward, rate)
    else:
        for tile in tiles:
            self.q.setdefault(tile, np.zeros(6))[index] += rate * delta / len(tiles)
    self.counts.update(events)
    self.total_reward += reward


def game_events_occurred(self, old_game_state, self_action, new_game_state, events):
    if self.pending is not None:
        update(self, *self.pending)
    self.pending = (old_game_state, self_action, new_game_state, list(events))


def end_of_round(self, last_game_state, last_action, events):
    if self.pending is not None:
        previous = self.pending[0]
        if previous is not None and (previous['round'], previous['step']) != (last_game_state['round'], last_game_state['step']):
            update(self, *self.pending)
    self.pending = None
    update(self, last_game_state, last_action, None, events)
    self.episodes += 1
    self.model_path.parent.mkdir(parents=True, exist_ok=True)
    data = {'version': 5, 'blocks': [list(b) for b in BLOCKS], 'actions': list(ACTIONS), 'episodes': self.episodes,
            'prior': {','.join(map(str, k)): v.tolist() for k, v in self.prior.items()},
            'q': {','.join(map(str, k)): v.tolist() for k, v in self.q.items()},
            'visits': {','.join(map(str, k)): v.tolist() for k, v in self.visits.items()},
            'config': {'alpha': self.alpha, 'gamma': self.gamma, 'shaping': self.shaping,
                       'progress': self.progress, 'decay': self.decay, 'shield': self.shield,
                       'death_penalty': self.death_penalty, 'epsilon_start': self.epsilon_start,
                       'anticipate': self.anticipate,
                       'attack_features': getattr(self, 'attack_features', False),
                       'attack_shaping': 'original',
                       'behavior_policy': 'd4_average_urgent_escape',
                       'learning_value_mode': self.learning_value_mode,
                       'gradient': 'd4_mean_semi_gradient' if self.learning_value_mode == 'average' else 'original_augmented_raw',
                       'gradient_divisor': len(BLOCKS)}}
    if getattr(self, 'rate_scale', 1.) != 1.:
        data['config']['rate_scale'] = self.rate_scale
    if getattr(self, 'bootstrap_dynamic', False):
        data['config']['bootstrap_dynamic'] = True
    if getattr(self, 'symmetry', False):
        data['config']['symmetry'] = True
    if getattr(self, 'n_step', 1) > 1:
        assert not self.transition_queue, 'Terminal backup must flush the queue'
        data['config']['n_step'] = self.n_step
        data['config']['backup_method'] = 'greedy_tree_backup'
    temporary = self.model_path.with_suffix('.tmp')
    temporary.write_text(json.dumps(data), encoding='utf-8')
    temporary.replace(self.model_path)
    self.model_path.with_suffix('.credit_metrics.json').write_text(json.dumps({
        'learning_value_mode': self.learning_value_mode,
        'counts': dict(self.credit_metrics),
        'note': 'Native recorded trajectory at actual backup time, once per real update; overlapping windows are correlated. Reward coefficients include greedy tie probabilities and gamma. Raw control also updates transformed trajectories, not counted here.'}))
    if getattr(self, 'n_step', 1) > 1:
        self.model_path.with_suffix('.backup_metrics.json').write_text(json.dumps({
            'updates_by_buffer_length': dict(self.backup_lengths),
            'updates': sum(self.backup_lengths.values()),
            'note': 'Buffer length is not effective credit length; non-greedy intermediate actions cut later credit.'}))
    if getattr(self, 'bootstrap_dynamic', False):
        self.model_path.with_suffix('.mask_metrics.json').write_text(json.dumps({
            'nonterminal_updates': self.mask_checks, 'mask_changed_updates': self.mask_changes,
            'bootstrap_max_reduction_sum': self.bootstrap_gap_sum,
            'mean_max_reduction': self.bootstrap_gap_sum / max(1, self.mask_checks)}))
    snapshot_dir = os.environ.get('QL_SNAPSHOT_DIR')
    elapsed = self.episodes - self.start_episode
    if snapshot_dir and elapsed % 25 == 0:
        folder = Path(snapshot_dir)
        folder.mkdir(parents=True, exist_ok=True)
        with (folder / f'step_{elapsed:03d}.json').open('x', encoding='utf-8') as handle:
            json.dump(data, handle)
    metrics = self.model_path.with_suffix('.csv')
    new_file = not metrics.exists()
    names = ['COIN_COLLECTED', 'CRATE_DESTROYED', 'BOMB_DROPPED', 'KILLED_SELF', 'GOT_KILLED', 'KILLED_OPPONENT']
    with metrics.open('a', newline='', encoding='utf-8') as handle:
        writer = csv.writer(handle)
        if new_file:
            writer.writerow(['episode', 'steps', 'epsilon', 'states', 'reward'] + names)
        writer.writerow([self.episodes, last_game_state['step'], self.epsilon, len(self.q), self.total_reward]
                        + [self.counts[name] for name in names])
    self.counts.clear()
    self.total_reward = 0.
    self.epsilon = max(.05, self.epsilon_start * self.decay ** (self.episodes - self.start_episode))
