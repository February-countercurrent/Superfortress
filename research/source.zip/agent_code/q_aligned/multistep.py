"""Greedy tree backup with a raw-Q control and an averaged-Q semi-gradient."""
import numpy as np

from .callbacks import active_tiles, values_for
from .learning import learning_values, averaged_step
from .symmetry import PERMUTATIONS, transform_key, transform_vector


def backup_target(agent, trajectory, with_probabilities=False):
    if not trajectory:
        raise ValueError('Empty backup trajectory')
    result = None
    probabilities = [0.] * (len(trajectory) - 1)
    for i in range(len(trajectory) - 1, -1, -1):
        key, action, reward, next_key, mask = trajectory[i]
        if next_key is None:
            if i != len(trajectory) - 1:
                raise ValueError('Terminal transition must end the trajectory')
            result = reward
            continue
        q = learning_values(agent, next_key)
        mask = np.array(mask, dtype=bool)
        value = float(q[mask].max())
        target = reward + agent.gamma * value
        if i + 1 < len(trajectory):
            following = trajectory[i + 1]
            if following[0] != next_key:
                raise ValueError('Non-contiguous multi-step trajectory')
            # Exact greedy policy, including uniform exact ties, as before.
            greedy = mask & (q == value)
            probability = float(greedy[following[1]]) / int(greedy.sum())
            probabilities[i] = probability
            target += agent.gamma * probability * (result - q[following[1]])
        result = target
    result = float(result)
    return (result, probabilities) if with_probabilities else result


def record_credit(agent, length, probabilities):
    metrics = agent.credit_metrics
    metrics['updates'] += 1
    metrics['branch_opportunities'] += len(probabilities)
    metrics['cut_branches'] += sum(p == 0 for p in probabilities)
    metrics['continuation_probability_sum'] += sum(probabilities)
    product = 1.
    reached = 1
    discounted_mass = 1.
    for i, probability in enumerate(probabilities, 1):
        product *= probability
        reached += int(product > 0)
        discounted_mass += agent.gamma ** i * product
    metrics['effective_length_' + str(reached)] += 1
    metrics['discounted_reward_coefficient_sum'] += discounted_mass
    if length == 3:
        metrics['three_step_windows'] += 1
        metrics['three_step_reaches_last'] += int(product > 0)
        metrics['three_step_last_reward_coefficient_sum'] += agent.gamma ** 2 * product


def apply_backup(agent, records):
    native = tuple((r['key'], r['action'], r['reward'], r['next_key'],
                    tuple(r['mask']) if r['next_key'] is not None else None) for r in records)
    target, probabilities = backup_target(agent, native, with_probabilities=True)
    record_credit(agent, len(records), probabilities)
    if agent.learning_value_mode == 'average':
        key, index = native[0][:2]
        delta = target - learning_values(agent, key)[index]
        # Qbar and its gradient are invariant under whole-trajectory D4
        # transforms. Averaging those identical updates again is redundant.
        averaged_step(agent, key, index, delta, records[0]['rate'])
    else:
        # Exact original augmented update, with all targets computed before
        # changing any coefficient. Instrumentation above is read-only.
        variants = set()
        permutations = PERMUTATIONS if agent.symmetry else (PERMUTATIONS[0],)
        for p in permutations:
            variants.add(tuple((transform_key(r['key'], p), p[r['action']], r['reward'],
                                transform_key(r['next_key'], p) if r['next_key'] is not None else None,
                                tuple(transform_vector(r['mask'], p)) if r['next_key'] is not None else None)
                               for r in records))
        changes = {}
        for trajectory in sorted(variants):
            key, index = trajectory[0][:2]
            delta = backup_target(agent, trajectory) - values_for(agent, key)[index]
            if not np.isfinite(delta):
                raise FloatingPointError('Non-finite tree-backup TD error')
            tiles = active_tiles(key)
            for tile in tiles:
                changes.setdefault(tile, np.zeros(6))[index] += records[0]['rate'] * delta / (len(tiles) * len(variants))
        for tile, change in changes.items():
            agent.q.setdefault(tile, np.zeros(6))[:] += change
    agent.backup_lengths[len(records)] += 1


def enqueue(agent, record):
    agent.transition_queue.append(record)
    if record['next_key'] is None:
        while agent.transition_queue:
            apply_backup(agent, agent.transition_queue)
            agent.transition_queue.pop(0)
    elif len(agent.transition_queue) >= agent.n_step:
        apply_backup(agent, agent.transition_queue)
        agent.transition_queue.pop(0)
