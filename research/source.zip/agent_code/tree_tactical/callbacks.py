"""Inference for frozen tactical FQI; original dynamic mask, no forced actions."""
import os
from pathlib import Path
import numpy as np
from .features import ACTIONS,allowed,describe
from .dynamic import candidate_mask
from .tactical import tactical_key
from .model import load_model


def setup(self):
    if self.train: raise ValueError('Fit tactical trees offline using the experiment entry point')
    path=Path(os.environ.get('FQI_MODEL',str(Path(__file__).parent/'model.pkl')))
    self.predictor,self.metadata=load_model(path)
    self.seed=int(os.environ.get('FQI_SEED','42'))
    self.policy_round=None


def act(self,game_state):
    if self.policy_round!=game_state['round']:
        self.policy_round=game_state['round']
        self.rng=np.random.default_rng(np.random.SeedSequence([self.seed,self.policy_round,101]))
    info=describe(game_state)
    mask=candidate_mask(game_state,info,allowed(info,True))
    if not mask.any(): raise ValueError('Empty dynamic candidate mask')
    key=info['key'] if self.predictor.features==16 else tactical_key(game_state,info)
    values=self.predictor.values(tuple(key))
    candidates=np.flatnonzero(mask)
    best=candidates[np.isclose(values[candidates],values[candidates].max())]
    return ACTIONS[int(self.rng.choice(best))]
