# Tactical Extra Trees FQI research agent

Completed result: this is the **joint** candidate, not a promoted model.
It won 51/120 (42.5%) on the independent maps, tying the older 300-game
random-data tree. The adopted block Q won 62/120 on those same maps.
The 60% screening result must not be reported as its final win rate.
The checkpoint is preserved for research and the negative result is retained.

This folder implements the joint tree experiment in `TREE_TACTICAL_PLAN.md`.
The completed experiment copies its screening-selected checkpoint here and
records its independent evaluation in `TREE_TACTICAL_RESULTS.md` and
`experiments/tree_tactical_v3/decision.json`. A copied checkpoint alone does
not mean it was recommended. The tournament submission remains Superfortress.

The version-2 checkpoint contains its feature count and estimator type:

- `control`: original 16 features and one shared 32-tree state/action regressor.
- `tactical`: 28 features and six separate 32-tree action regressors.
- `joint`: the tactical representation and a reduced auxiliary attack reward
  when the opponent has at least two currently available geometric exits.

All variants use the original dynamic safety candidates, D4 augmentation and
averaged Q prediction. They do not force coin collection or inherit Q-table
weights. The geometric features do not predict hidden opponent actions.
The larger variants also increase total tree capacity; the experiment does
not isolate that effect from the new features.

Training is offline. From the framework root, once a checkpoint is present:

```powershell
python main.py play --no-gui --agents tree_tactical rule_based_agent rule_based_agent rule_based_agent --scenario classic --n-rounds 3
```

`FQI_MODEL` optionally selects a compatible version-2 checkpoint; otherwise
the agent loads the adjacent `model.pkl`. Inference forces every regressor
to one thread. Recorded runtime: Python 3.10.9, NumPy 1.23.5, scikit-learn
1.2.1. Reproduce with these versions because serialized sklearn estimators
are version dependent. Only load trusted locally produced checkpoints.

Reproduction entry points in the project root are `prepare_tree_tactical.py`
and `experiment_tree_tactical.py`. They refuse to overwrite existing output;
use a fresh checkout/output directory to reproduce the run. Raw data,
source snapshots, episode splits, model selection and paired results are
saved in the experiment directory. Review and understand this AI-assisted
implementation before using it in the course report.
