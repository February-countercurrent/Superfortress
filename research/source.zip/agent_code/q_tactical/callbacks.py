"""Frozen tabular Q-learning inference. AI-assisted; student review required."""
import json
from pathlib import Path
import numpy as np
from .features import ACTIONS, allowed, describe, prior_key
from .escape import escape_costs
from .tactics import evaluate_bomb

def setup(self):
    root = Path(__file__).resolve().parent
    data = json.loads((root / 'model.json').read_text(encoding='utf-8'))
    self.policy = json.loads((root / 'policy.json').read_text(encoding='utf-8'))
    if data['version'] != 4 or data['actions'] != list(ACTIONS):
        raise ValueError('Incompatible model')
    self.q = {tuple(map(int, k.split(','))): np.array(v) for k, v in data['q'].items()}
    self.prior = {tuple(map(int, k.split(','))): np.array(v) for k, v in data['prior'].items()}
    if any(len(key) != 16 for key in self.q):
        raise ValueError('Final agent requires 16-feature Q table')
    self.rng = np.random.default_rng(self.policy['seed'])

def act(self, game_state):
    info = describe(game_state, anticipate=False, attack_features=False)
    candidates = np.flatnonzero(allowed(info, True))
    raw = self.q.get(info['key'])
    if raw is None:
        raw = self.prior.get(prior_key(info['key']), np.zeros(6))
    scores = raw - escape_costs(game_state, info, self.policy['bomb_cost'], 1.)
    if info['safe'][5] and game_state['others']:
        tactical = evaluate_bomb(game_state)
        scores = scores.copy()
        scores[5] += tactical['adjustment']
    best = candidates[np.isclose(scores[candidates], scores[candidates].max())]
    return ACTIONS[int(self.rng.choice(best))]
