"""Bounded space-time escape search; no opponent-policy or kill guarantees.

Compare reachable surviving endpoints with/without our bomb over the same
horizon. Opponent searches ignore agent occupancy (optimistic escape), while
our search retains observed opponent obstacles and spends the first turn
planting. Crates open after explosion, bomb timers follow official physics.
"""
import numpy as np
import settings
from .features import DELTAS, blast


def timeline(state, plant, horizon):
    field = state['field']
    danger = np.zeros((horizon + 1,) + field.shape, dtype=bool)
    opens = np.where(field == 0, 0, horizon + 2)
    occupied = np.zeros(field.shape, dtype=int)
    bombs = list(state['bombs'])
    if plant:
        bombs.append((tuple(state['self'][3]), settings.BOMB_TIMER))
    for p, timer in bombs:
        p = tuple(p)
        detonation = timer + 1
        occupied[p] = max(occupied[p], detonation)
        for cell in blast(field, p):
            danger[detonation:detonation + settings.EXPLOSION_TIMER, cell[0], cell[1]] = True
            if field[cell] == 1:
                opens[cell] = min(opens[cell], detonation + 1)
    for tick in range(1, horizon + 1):
        danger[tick] |= state['explosion_map'] >= tick
    return opens, occupied, danger


def advance(reachable, tick, schedule, blockers=(), wait_only=False):
    opens, occupied, danger = schedule
    destinations = reachable.copy()  # waiting on an already occupied bomb is legal
    if not wait_only:
        moves = np.zeros_like(reachable)
        moves[:, :-1] |= reachable[:, 1:]
        moves[1:, :] |= reachable[:-1, :]
        moves[:, 1:] |= reachable[:, :-1]
        moves[:-1, :] |= reachable[1:, :]
        destinations |= moves & (occupied < tick)
    destinations &= (opens <= tick) & ~danger[tick]
    for p in blockers:
        destinations[tuple(p)] = False
    return destinations


def endpoints(start, schedule, blockers=(), plant_first=False):
    reach = np.zeros_like(schedule[0], dtype=bool)
    reach[tuple(start)] = True
    for tick in range(1, len(schedule[2])):
        reach = advance(reach, tick, schedule, blockers, plant_first and tick == 1)
        if not reach.any():
            break
    return reach


def escape_branches(state, schedule):
    """Count viable movement directions on the turn after planting, not WAIT."""
    pos = tuple(state['self'][3])
    blockers = [tuple(o[3]) for o in state['others']]
    first = np.zeros_like(schedule[0], dtype=bool)
    first[pos] = True
    first = advance(first, 1, schedule, blockers, wait_only=True)
    if not first.any():
        return 0
    choices = advance(first, 2, schedule, blockers)
    count = 0
    for dx, dy in DELTAS:
        p = pos[0] + dx, pos[1] + dy
        if not choices[p]:
            continue
        reach = np.zeros_like(first)
        reach[p] = True
        for tick in range(3, len(schedule[2])):
            reach = advance(reach, tick, schedule, blockers)
        count += bool(reach.any())
    return count


def evaluate_bomb(state):
    pos = tuple(state['self'][3])
    nearby = [o for o in state['others'] if abs(o[3][0] - pos[0]) + abs(o[3][1] - pos[1]) <= 6]
    if not nearby or not state['self'][2]:
        return {'adjustment': 0., 'targets': [], 'self_branches': None}
    horizon = max([settings.BOMB_TIMER + settings.EXPLOSION_TIMER, int(state['explosion_map'].max())]
                  + [t + settings.EXPLOSION_TIMER for _, t in state['bombs']])
    baseline = timeline(state, False, horizon)
    planted = timeline(state, True, horizon)
    blockers = [tuple(o[3]) for o in state['others']]
    self_survives = bool(endpoints(pos, planted, blockers, plant_first=True).any())
    branches = escape_branches(state, planted)
    targets = []
    for other in nearby:
        before = int(endpoints(other[3], baseline).sum())
        after = int(endpoints(other[3], planted).sum())
        targets.append({'name': other[0], 'before': before, 'after': after,
                        'trap': before > 0 and after == 0,
                        'pressure': max(0., 1 - after / before) if before else 0.})
    # Fixed initial experimental weights, not probabilities or learned rewards.
    traps = sum(t['trap'] for t in targets)
    pressure = max((t['pressure'] for t in targets), default=0.)
    adjustment = 3. * min(traps, 1) + .8 * pressure - (.4 if branches <= 1 else 0.)
    if not self_survives:
        adjustment = -10.  # original timed shield remains the actual action filter
    return {'adjustment': adjustment, 'targets': targets, 'self_branches': branches,
            'self_survives': self_survives, 'horizon': horizon}
