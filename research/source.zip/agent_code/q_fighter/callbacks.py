"""Tabular Q-learning with six actions and an optional safety shield."""
import json
import os
from pathlib import Path

import numpy as np

from .features import ACTIONS, allowed, describe, prior_key
from .escape import escape_costs, effective_bomb_cost


def setup(self):
    self.rng = np.random.default_rng(int(os.environ.get('QF_SEED', '42')))
    self.model_path = Path(os.environ.get('QF_MODEL', str(Path(__file__).resolve().parent / 'model.json')))
    self.shield = os.environ.get('QF_SHIELD', '1') == '1'
    self.q, self.visits, self.episodes = {}, {}, 0
    if self.model_path.exists():
        data = json.loads(self.model_path.read_text(encoding='utf-8'))
        if data['version'] != 4 or data['actions'] != list(ACTIONS):
            raise ValueError('Incompatible bomber model')
        self.q = {tuple(map(int, k.split(','))): np.array(v, dtype=float) for k, v in data['q'].items()}
        self.visits = {tuple(map(int, k.split(','))): np.array(v, dtype=int) for k, v in data.get('visits', {}).items()}
        self.episodes = data['episodes']
        self.training_config = data.get('config', {})
        self.prior = {tuple(map(int, k.split(','))): np.array(v, dtype=float) for k, v in data['prior'].items()}
    else:
        raise FileNotFoundError(f'Train first: {self.model_path}')
    self.epsilon = 0.
    self.attack_features = os.environ.get('QF_ATTACK_FEATURES',
        str(int(self.training_config.get('attack_features', False)))) == '1'
    self.escape_risk = os.environ.get('QF_ESCAPE_RISK', '1') == '1'
    self.bomb_cost = float(os.environ.get('QF_BOMB_COST', '1'))
    self.bomb_cost_mode = os.environ.get('QF_BOMB_COST_MODE', data.get('policy', {}).get('bomb_cost_mode', 'full'))
    if self.bomb_cost_mode not in ('full', 'off', 'late_behind'):
        raise ValueError('Invalid QF_BOMB_COST_MODE')
    self.score_round, self.highest_seen_score = None, 0
    self.contest_scale = float(os.environ.get('QF_CONTEST_SCALE', '1'))
    self.anticipate = os.environ.get('QF_ANTICIPATE',
                         str(int(self.training_config.get('anticipate', False)))) == '1'


def act(self, game_state):
    if self.score_round != game_state['round']:
        self.score_round, self.highest_seen_score = game_state['round'], 0
    self.highest_seen_score = max([self.highest_seen_score, game_state['self'][1]]
                                 + [o[1] for o in game_state['others']])
    info = describe(game_state, self.anticipate, self.attack_features)
    candidates = np.flatnonzero(allowed(info, self.shield))
    if self.train and self.rng.random() < self.epsilon:
        return ACTIONS[int(self.rng.choice(candidates))]
    values = values_for(self, info['key'])
    if self.escape_risk and self.shield:
        bomb_cost = effective_bomb_cost(game_state, self.bomb_cost, self.bomb_cost_mode, self.highest_seen_score)
        values = values - escape_costs(game_state, info, bomb_cost, self.contest_scale)
    best = candidates[np.isclose(values[candidates], values[candidates].max())]
    return ACTIONS[int(self.rng.choice(best))]


def values_for(self, key):
    if key in self.q:
        return self.q[key]
    if len(key) == 18 and key[:16] in self.q:
        return self.q[key[:16]]
    return self.prior.get(prior_key(key), np.zeros(6))
