"""Terminal-safe one-step learning, metrics, and portable JSON checkpoints."""
import csv
import json
import os
from collections import Counter

import numpy as np

from .features import ACTIONS, allowed, describe
from .callbacks import values_for


def setup_training(self):
    self.alpha = float(os.environ.get('QF_ALPHA', '.15'))
    self.gamma = float(os.environ.get('QF_GAMMA', '.7'))
    self.shaping = float(os.environ.get('QF_SHAPING', '0'))
    self.progress = float(os.environ.get('QF_PROGRESS', '.8'))
    self.decay = float(os.environ.get('QF_DECAY', '.99'))
    self.epsilon_start = float(os.environ.get('QF_EPSILON', '.35'))
    self.death_penalty = float(os.environ.get('QF_DEATH_PENALTY',
                               str(getattr(self, 'training_config', {}).get('death_penalty', 25.))))
    self.start_episode = self.episodes
    self.epsilon = self.epsilon_start
    self.pending = None
    self.counts = Counter()
    self.total_reward = 0.


def update(self, old, action, new, events):
    if old is None or action not in ACTIONS:
        return
    info = describe(old, self.anticipate, getattr(self, 'attack_features', False))
    reward = (8 * events.count('COIN_COLLECTED') + events.count('CRATE_DESTROYED')
              + .5 * events.count('COIN_FOUND') + 15 * events.count('KILLED_OPPONENT')
              - .2 * events.count('BOMB_DROPPED') - events.count('INVALID_ACTION')
              - self.death_penalty * int('GOT_KILLED' in events or 'KILLED_SELF' in events) - .03)
    future, next_potential = 0., 0.
    if new is not None:
        next_info = describe(new, self.anticipate, getattr(self, 'attack_features', False))
        future = values_for(self, next_info['key'])[allowed(next_info, self.shield)].max()
        next_potential = -next_info['distance']
    reward += self.shaping * (self.gamma * next_potential + info['distance'])
    # Balanced local shaping avoids reward for alternating toward/away moves.
    # This is an experimental reward heuristic, not an optimality guarantee.
    if not info['threatened'] and info['target']:
        if action in ACTIONS[:4]:
            reward += self.progress * info['progress'][ACTIONS.index(action)]
        elif action == 'WAIT' and info['distance'] > 0:
            reward -= self.progress
    if action == 'BOMB':
        reward += .5 * min(info['yield'], 3) if info['safe'][5] else 0.
        reward += 1.5 * info['enemy_hits'] if info['safe'][5] else 0.
        if info['yield'] == 0 and info['enemy_hits'] == 0:
            reward -= 1.
    if action == 'WAIT' and not info['threatened']:
        reward -= .2
    if info['key'] not in self.q:
        self.q[info['key']] = values_for(self, info['key']).copy()
    values = self.q[info['key']]
    inherited_visits = self.visits.get(info['key'][:16], np.zeros(6, dtype=int))
    visits = self.visits.setdefault(info['key'], inherited_visits.copy())
    index = ACTIONS.index(action)
    visits[index] += 1
    rate = max(.02, self.alpha / (1 + visits[index] / 200))
    values[index] += rate * (reward + self.gamma * future - values[index])
    self.counts.update(events)
    self.total_reward += reward


def game_events_occurred(self, old_game_state, self_action, new_game_state, events):
    if self.pending is not None:
        update(self, *self.pending)
    self.pending = (old_game_state, self_action, new_game_state, list(events))


def end_of_round(self, last_game_state, last_action, events):
    if self.pending is not None:
        previous = self.pending[0]
        if previous is not None and (previous['round'], previous['step']) != (last_game_state['round'], last_game_state['step']):
            update(self, *self.pending)
    self.pending = None
    update(self, last_game_state, last_action, None, events)
    self.episodes += 1
    self.model_path.parent.mkdir(parents=True, exist_ok=True)
    data = {'version': 4, 'actions': list(ACTIONS), 'episodes': self.episodes,
            'prior': {','.join(map(str, k)): v.tolist() for k, v in self.prior.items()},
            'q': {','.join(map(str, k)): v.tolist() for k, v in self.q.items()},
            'visits': {','.join(map(str, k)): v.tolist() for k, v in self.visits.items()},
            'config': {'alpha': self.alpha, 'gamma': self.gamma, 'shaping': self.shaping,
                       'progress': self.progress, 'decay': self.decay, 'shield': self.shield,
                       'death_penalty': self.death_penalty, 'epsilon_start': self.epsilon_start,
                       'anticipate': self.anticipate,
                       'attack_features': getattr(self, 'attack_features', False)}}
    temporary = self.model_path.with_suffix('.tmp')
    temporary.write_text(json.dumps(data), encoding='utf-8')
    temporary.replace(self.model_path)
    metrics = self.model_path.with_suffix('.csv')
    new_file = not metrics.exists()
    names = ['COIN_COLLECTED', 'CRATE_DESTROYED', 'BOMB_DROPPED', 'KILLED_SELF', 'GOT_KILLED', 'KILLED_OPPONENT']
    with metrics.open('a', newline='', encoding='utf-8') as handle:
        writer = csv.writer(handle)
        if new_file:
            writer.writerow(['episode', 'steps', 'epsilon', 'states', 'reward'] + names)
        writer.writerow([self.episodes, last_game_state['step'], self.epsilon, len(self.q), self.total_reward]
                        + [self.counts[name] for name in names])
    self.counts.clear()
    self.total_reward = 0.
    self.epsilon = max(.05, self.epsilon_start * self.decay ** (self.episodes - self.start_episode))
