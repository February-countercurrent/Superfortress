"""D4 transforms of directional legacy features; context scalars stay fixed."""
PERMUTATIONS = tuple(tuple((r + sign*i) % 4 for i in range(4)) + (4,5)
                     for sign in (1,-1) for r in range(4))


def transform_key(key, permutation):
    if len(key) != 19:
        raise ValueError('Expected 19-feature context observation')
    result=list(key)
    for old in range(4):
        result[permutation[old]]=key[old]
        result[6+permutation[old]]=key[6+old]
    return tuple(result)
