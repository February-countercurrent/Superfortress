"""Causal score memory and decision-time context from public observations only."""
import settings


class ScoreLedger:
    def __init__(self):
        self.round = None
        self.latest = -1
        self.scores = {}
        self.cache = {}

    def observe(self, state, after_action=False):
        # The framework's post-action observation still has the action's step.
        # It represents the *next* decision; align its time with the next act().
        decision_step = int(state['step']) + int(after_action)
        if self.round != state['round']:
            self.round = state['round']
            self.latest = -1
            self.scores = {}
            self.cache = {}
        if decision_step in self.cache:
            return self.cache[decision_step]
        if decision_step < self.latest:
            raise ValueError('Unseen historical observation would leak future score memory')
        alive = {other[0] for other in state['others']}
        for name, score, _, _ in state['others']:
            self.scores[name] = int(score)
        stale = int(bool(set(self.scores) - alive))
        own = int(state['self'][1])
        gap = own - max(self.scores.values()) if self.scores else 0
        kill = settings.REWARD_KILL
        category = 0 if gap <= -kill else 1 if gap < 0 else 2 if gap == 0 else 3 if gap < kill else 4
        remaining = max(0, settings.MAX_STEPS - decision_step + 1)
        phase = 0 if remaining > settings.MAX_STEPS // 2 else 1 if remaining > settings.MAX_STEPS // 8 else 2
        result = (category, phase, stale)
        self.cache[decision_step] = result
        self.latest = decision_step
        return result


def annotate(agent, state, after_action=False):
    if state is None:
        return None
    # Freeze context when the observation arrives, before a delayed update.
    return {**state, '_q_context': agent.score_ledger.observe(state, after_action)}


def observed_context(agent, state):
    if '_q_context' in state:
        return tuple(state['_q_context'])
    return agent.score_ledger.observe(state)
