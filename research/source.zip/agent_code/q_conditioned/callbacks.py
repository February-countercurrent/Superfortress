"""Additive sparse linear Q-learning over overlapping categorical feature blocks."""
import json
import os
from pathlib import Path
import numpy as np
from .features import ACTIONS, allowed, describe
from .escape import escape_costs
from .dynamic import candidate_mask

# Use exactly the original 16 observations. Action-specific coefficients
# preserve interactions within each block; no new tactical observations yet.
BLOCKS = ((10, 12), (0, 1, 2, 3, 4, 5, 12), (6, 7, 8, 9, 10, 13),
          (10, 11, 13), (10, 14, 15), (5, 11, 12, 14), (10, 12, 14, 15))


def active_tiles(key):
    if len(key) != 16:
        raise ValueError('Expected original 16-feature observation')
    return [(i, *[key[j] for j in group]) for i, group in enumerate(BLOCKS)]


def values_for(self, key):
    return sum((self.q.get(tile, np.zeros(6)) for tile in active_tiles(key)), np.zeros(6))


def setup(self):
    self.rng = np.random.default_rng(int(os.environ.get('QL_SEED', '42')))
    self.model_path = Path(os.environ.get('QL_MODEL', str(Path(__file__).parent / 'model.json')))
    data = json.loads(self.model_path.read_text(encoding='utf-8'))
    if data['version'] != 6 or data['actions'] != list(ACTIONS) or data['blocks'] != [list(b) for b in BLOCKS]:
        raise ValueError('Incompatible linear Q checkpoint')
    self.q = {tuple(map(int, k.split(','))): np.array(v, dtype=float) for k, v in data['q'].items()}
    self.visits = {tuple(map(int, k.split(','))): np.array(v, dtype=int) for k, v in data.get('visits', {}).items()}
    self.episodes = data['episodes']
    self.prior = {}
    self.training_config = data.get('config', {})
    self.epsilon = 0.
    self.shield, self.anticipate, self.attack_features = True, False, False


def act(self, game_state):
    info = describe(game_state)
    candidates = np.flatnonzero(candidate_mask(game_state, info, allowed(info, True)))
    if self.train and self.rng.random() < self.epsilon:
        return ACTIONS[int(self.rng.choice(candidates))]
    scores = values_for(self, info['key']) - escape_costs(game_state, info, 0., 1.)
    best = candidates[np.isclose(scores[candidates], scores[candidates].max())]
    return ACTIONS[int(self.rng.choice(best))]
