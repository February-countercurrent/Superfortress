"""Collect complete one-step transitions; fit forests offline between batches."""
from collections import Counter
import csv
import os
from pathlib import Path

import numpy as np

from .callbacks import encode
from .features import ACTIONS


def reward_for(info, action, events):
    reward = (8 * events.count('COIN_COLLECTED') + events.count('CRATE_DESTROYED')
              + .5 * events.count('COIN_FOUND') + 15 * events.count('KILLED_OPPONENT')
              - .2 * events.count('BOMB_DROPPED') - events.count('INVALID_ACTION')
              - 25 * int('GOT_KILLED' in events or 'KILLED_SELF' in events) - .03)
    if not info['threatened'] and info['target']:
        if action in ACTIONS[:4]:
            reward += .8 * info['progress'][ACTIONS.index(action)]
        elif action == 'WAIT' and info['distance'] > 0:
            reward -= .8
    if action == 'BOMB':
        if info['safe'][5]:
            reward += .5 * min(info['yield'], 3) + 1.5 * info['enemy_hits']
        if info['yield'] == 0 and info['enemy_hits'] == 0:
            reward -= 1
    if action == 'WAIT' and not info['threatened']:
        reward -= .2
    return reward


def setup_training(self):
    self.data_dir = Path(os.environ['FQI_DATA_DIR'])
    self.data_dir.mkdir(parents=True, exist_ok=True)
    self.pending = None
    self.transitions = []
    self.counts = Counter()


def observe(self, old, action, new, events):
    if old is None:
        return
    if action not in ACTIONS:
        raise ValueError('Unexpected executed action')
    x, mask, info = encode(old)
    a = ACTIONS.index(action)
    if not mask[a]:
        raise ValueError('Recorded action was outside deployed safety mask')
    if new is None:
        next_x, next_mask = np.zeros(16, dtype=np.int8), np.zeros(6, dtype=bool)
    else:
        next_x, next_mask, _ = encode(new)
    self.transitions.append(dict(x=x, a=a, r=reward_for(info, action, events),
        next_x=next_x, mask=mask.copy(), next_mask=next_mask.copy(), terminal=new is None,
        round=old['round'], step=old['step']))
    self.counts.update(events)


def game_events_occurred(self, old_game_state, self_action, new_game_state, events):
    if self.pending is not None:
        observe(self, *self.pending)
    self.pending = old_game_state, self_action, new_game_state, list(events)


def end_of_round(self, last_game_state, last_action, events):
    if self.pending is not None:
        previous = self.pending[0]
        if previous is not None and (previous['round'], previous['step']) != (last_game_state['round'], last_game_state['step']):
            observe(self, *self.pending)
    self.pending = None
    observe(self, last_game_state, last_action, None, list(events))
    records = self.transitions
    assert records and sum(r['terminal'] for r in records) == 1 and records[-1]['terminal']
    assert [r['step'] for r in records] == list(range(1, last_game_state['step'] + 1))
    data = {name: np.asarray([r[name] for r in records]) for name in records[0]}
    path = self.data_dir / f"round_{last_game_state['round']:05d}.npz"
    with path.open('xb') as handle:
        np.savez_compressed(handle, **data)
    csv_path = self.data_dir / 'episodes.csv'
    exists = csv_path.exists()
    names = ['COIN_COLLECTED', 'CRATE_DESTROYED', 'KILLED_OPPONENT', 'KILLED_SELF', 'GOT_KILLED', 'BOMB_DROPPED']
    with csv_path.open('a', newline='', encoding='utf-8') as handle:
        writer = csv.writer(handle)
        if not exists:
            writer.writerow(['round', 'transitions', 'epsilon', 'reward', *names])
        writer.writerow([last_game_state['round'], len(records), self.epsilon,
                         float(data['r'].sum()), *[self.counts[n] for n in names]])
    self.transitions = []
    self.counts.clear()
