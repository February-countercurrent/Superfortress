# Extra Trees Fitted Q Iteration research agent

This is an independent, AI-assisted research model. It is not the tournament
submission. Student review, understanding and refinement are required.

The included `model.pkl` is the preselected iteration-20 checkpoint from
`experiments/tree_fqi_v1`. It uses 16 original state features, six one-hot action
indicators, 32 Extra Trees, D4 augmentation/averaging, and the adopted dynamic
safety mask. No old Q weights are inherited. No extra escape score offsets or
history-based resource controller are used.

From the original framework's root:

```powershell
python main.py play --no-gui --agents tree_fqi rule_based_agent rule_based_agent rule_based_agent --scenario classic --n-rounds 3
```

The research environment uses Python 3.10.9, NumPy 1.23.5 and scikit-learn 1.2.1.
Use only trusted locally produced pickle checkpoints and the recorded library
versions. Inference forces `n_jobs=1`. `FQI_MODEL` can select an explicit model
path; the default is the model alongside this file.

`train.py` collects transitions into `FQI_DATA_DIR`; it does not fit the forest
inside a game callback. `fit_tree_fqi.py` performs offline Bellman regression.
See `TREE_FQI_PLAN.md`, `TREE_FQI_RESULTS.md` and `experiment_tree_fqi.py` in the
project root for the fixed pilot protocol, raw data and reproducible commands.
