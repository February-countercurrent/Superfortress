"""D4-averaged, scalar state-action Extra Trees Q regression.

AI-assisted research implementation; review and refinement by the student are
required. Pickle checkpoints are exclusively locally generated trusted files.
"""
from functools import lru_cache
from pathlib import Path
import pickle

import numpy as np

from .features import ACTIONS
from .symmetry_maps import PERMUTATIONS


def transform_keys(keys, permutation):
    keys = np.asarray(keys, dtype=np.float32).reshape(-1, 16)
    result = keys.copy()
    for old in range(4):
        result[:, permutation[old]] = keys[:, old]
        result[:, 6 + permutation[old]] = keys[:, 6 + old]
    return result


def state_actions(keys, actions):
    keys = np.asarray(keys, dtype=np.float32).reshape(-1, 16)
    actions = np.asarray(actions, dtype=int)
    if actions.shape != (len(keys),) or ((actions < 0) | (actions >= 6)).any():
        raise ValueError('Invalid state/action batch')
    # One-hot action avoids imposing an artificial order on the action label.
    return np.concatenate((keys, np.eye(6, dtype=np.float32)[actions]), axis=1)


class D4Queries:
    """Precompute repeated transformed observations for batch Bellman targets."""
    def __init__(self, keys):
        keys = np.asarray(keys, dtype=np.float32).reshape(-1, 16)
        self.count = len(keys)
        transformed = np.concatenate([transform_keys(keys, p) for p in PERMUTATIONS])
        self.keys, inverse = np.unique(transformed, axis=0, return_inverse=True)
        self.inverse = inverse.reshape(8, self.count)
        self.inputs = state_actions(np.repeat(self.keys, 6, axis=0),
                                    np.tile(np.arange(6), len(self.keys)))

    def predict(self, forest):
        if forest is None:
            return np.zeros((self.count, 6), dtype=float)
        if self.count == 0:
            return np.empty((0, 6), dtype=float)
        raw = np.concatenate([forest.predict(self.inputs[i:i + 65536])
                              for i in range(0, len(self.inputs), 65536)]).reshape(-1, 6)
        aligned = [raw[self.inverse[g]][:, list(p)] for g, p in enumerate(PERMUTATIONS)]
        result = np.mean(aligned, axis=0)
        if not np.isfinite(result).all():
            raise FloatingPointError('Non-finite tree predictions')
        return result


class ForestQ:
    def __init__(self, forest):
        self.forest = forest
        self._cached = lru_cache(maxsize=8192)(self._one)

    def _one(self, key):
        return tuple(D4Queries([key]).predict(self.forest)[0])

    def values(self, key):
        return np.asarray(self._cached(tuple(key)), dtype=float)


def bellman_targets(rewards, terminal, next_values, next_masks, gamma):
    target = np.asarray(rewards, dtype=float).copy()
    live = ~np.asarray(terminal, dtype=bool)
    masks = np.asarray(next_masks, dtype=bool)
    if not masks[live].any(axis=1).all():
        raise ValueError('Nonterminal observation has no allowed action')
    target[live] += gamma * np.where(masks[live], next_values[live], -np.inf).max(axis=1)
    if not np.isfinite(target).all():
        raise FloatingPointError('Non-finite Bellman targets')
    return target


def save_model(path, forest, **metadata):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    data = dict(version=1, features=16, actions=list(ACTIONS),
                estimator=forest, d4_mean=True, **metadata)
    temporary = path.with_suffix('.tmp')
    with temporary.open('wb') as handle:
        pickle.dump(data, handle, protocol=pickle.HIGHEST_PROTOCOL)
    temporary.replace(path)


def load_model(path):
    with Path(path).open('rb') as handle:
        data = pickle.load(handle)
    if (data['version'] != 1 or data['features'] != 16
            or data['actions'] != list(ACTIONS) or not data['d4_mean']):
        raise ValueError('Incompatible tree checkpoint')
    forest = data['estimator']
    if forest is not None:
        if forest.n_features_in_ != 22:
            raise ValueError('Expected 16 state features and 6 action indicators')
        forest.n_jobs = 1  # Agent inference is strictly single-threaded.
    return ForestQ(forest), {k: v for k, v in data.items() if k != 'estimator'}
