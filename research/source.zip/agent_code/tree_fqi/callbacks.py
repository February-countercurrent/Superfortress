"""Tree Q policy with the adopted features and dynamic candidate mask."""
import os
from pathlib import Path

import numpy as np

from .features import ACTIONS, allowed, describe
from .dynamic import candidate_mask
from .model import load_model


def encode(state):
    info = describe(state)
    mask = candidate_mask(state, info, allowed(info, True))
    if not mask.any():
        raise ValueError('Candidate mask must be nonempty')
    return np.asarray(info['key'], dtype=np.int8), mask, info


def setup(self):
    self.model_path = Path(os.environ.get('FQI_MODEL', str(Path(__file__).parent / 'model.pkl')))
    self.predictor, self.metadata = load_model(self.model_path)
    self.seed = int(os.environ.get('FQI_SEED', '42'))
    self.epsilon = float(os.environ.get('FQI_EPSILON', '1')) if self.train else 0.
    if not 0 <= self.epsilon <= 1:
        raise ValueError('Exploration must be between 0 and 1')
    self.policy_round = None


def act(self, game_state):
    if self.policy_round != game_state['round']:
        self.policy_round = game_state['round']
        self.rng = np.random.default_rng(np.random.SeedSequence([self.seed, self.policy_round, 101]))
        self.exploration_rng = np.random.default_rng(np.random.SeedSequence([self.seed, self.policy_round, 104]))
    key, mask, _ = encode(game_state)
    candidates = np.flatnonzero(mask)
    if self.train and self.exploration_rng.random() < self.epsilon:
        selected = self.rng.choice(candidates)
    else:
        values = self.predictor.values(tuple(key))
        best = candidates[np.isclose(values[candidates], values[candidates].max())]
        selected = self.rng.choice(best)
    return ACTIONS[int(selected)]
