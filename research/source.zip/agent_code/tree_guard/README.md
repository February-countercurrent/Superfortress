# 当前采用的树模型

用户已明确采纳：28维、六动作ExtraTrees联合模型，加提前撤离WAIT修正。当前入口为 agent_code/tree_guard，权重与已测试的 tree_escape 完全相同，Python代码逐字节一致。树模型当前版本以根目录 CURRENT_TREE_RESEARCH.json 为准。

新地图120局：56胜（46.7%），均分6.233，自杀8次；同图原联合树49胜、自杀20次。胜率差95%区间仍跨零；这是用户确认的工程采纳，未改写原实验的自动判定。

默认启用撤离修正，种子42；离线拟合模型，推理不训练。此次采纳无需重训。可用 FQI_ESCAPE_GUARD=0 关闭修正用于对照。

原试验代理、逐局数据、Superfortress分块Q提交包及其指针保留。评估细节见 TREE_ESCAPE_RESULTS.md；本目录是树模型研究版本，不是新的比赛提交。
