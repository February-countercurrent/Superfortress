# Strong-opponent teacher candidate

Research candidate only; adoption status is in candidate.json.
The 28-feature inference source is byte-identical to tree_guard.
Training uses the original400 episode maps, replacing100 random strong
trajectories with frozen q_guard demonstrations. Rewards are unchanged.
Experiment: experiments/tree_strong_teacher_v1.
This does not replace the submitted Superfortress agent.
AI-assisted implementation; student review and understanding required.
