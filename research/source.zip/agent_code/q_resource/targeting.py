"""Prefer reachable resources to pursuit, preserving immediate safe attacks.

An inference hypothesis, not a learned reward or guaranteed improvement.
Only target descriptors change; the original physical safety data is retained.
"""
import numpy as np
from .features import DELTAS, crate_yields, distance_map


def resource_target(state, info):
    if info['target'] != 3 or info['threatened']:
        return info
    # Preserve shooting opportunities already approved by the static shield.
    # The existing dynamic shield still has the final say in act().
    if info['enemy_hits'] > 0 and info['safe'][5]:
        return info
    field = state['field']
    position = tuple(state['self'][3])
    free = field == 0
    for p, _ in state['bombs']:
        free[tuple(p)] = False
    for other in state['others']:
        free[tuple(other[3])] = False
    free[position] = True
    distances = distance_map(free, state['coins'])
    target = 1
    if distances[position] < 0:
        yields = crate_yields(field.shape, field.astype(np.int8).tobytes())
        targets = list(zip(*np.where((yields > 0) & free)))
        distances = distance_map(free, targets)
        target = 2
    distance = int(distances[position])
    if distance < 0:
        return info
    neighbors = [(position[0]+dx, position[1]+dy) for dx, dy in DELTAS]
    key = list(info['key'])
    key[6:10] = [int(0 <= distances[p] < distance) for p in neighbors]
    key[10] = target
    key[13] = 0 if distance == 0 else 1 if distance == 1 else 2
    progress = tuple(int(np.sign(distance-distances[p])) if distances[p] >= 0 else -1
                     for p in neighbors)
    return {**info, 'key': tuple(key), 'target': target, 'distance': distance,
            'progress': progress}
