"""Small spatial value network and compact observation encoding."""
import numpy as np
import torch
from torch import nn
from .features import describe, allowed

CHANNELS, AUX_SIZE, SIZE = 12, 12, 17
REWARD_SCALE = 10.


def encode(state, info=None):
    if state['field'].shape != (SIZE, SIZE):
        raise ValueError('DQN expects the official 17x17 board')
    info = describe(state) if info is None else info
    field = state['field']
    board = np.zeros((CHANNELS, SIZE, SIZE), dtype=np.uint8)
    board[0] = (field == -1) * 255
    board[1] = (field == 1) * 255
    for p in state['coins']:
        board[2, p[0], p[1]] = 255
    pos = tuple(state['self'][3])
    board[3, pos[0], pos[1]] = 255
    for other in state['others']:
        p = other[3]
        board[4 if other[2] else 5, p[0], p[1]] = 255
    for p, timer in state['bombs']:
        board[6, p[0], p[1]] = round(255 * min(5, max(0, timer + 1)) / 5)
        board[7, p[0], p[1]] = 255
    board[8] = np.clip(state['explosion_map'] * 127, 0, 255).astype(np.uint8)
    xx, yy = np.indices((SIZE, SIZE))
    board[9] = np.rint((xx - pos[0] + 16) * 255 / 32).astype(np.uint8)
    board[10] = np.rint((yy - pos[1] + 16) * 255 / 32).astype(np.uint8)
    board[11].fill(255 if state['self'][2] else 0)
    top = max([o[1] for o in state['others']], default=state['self'][1])
    mask = allowed(info, True)
    aux = np.array([np.clip(state['self'][1] / 20, 0, 1), np.clip(top / 20, 0, 1),
        np.clip((state['self'][1] - top) / 20, -1, 1), state['step'] / 400,
        len(state['others']) / 3, len(state['coins']) / 9, *mask.astype(float)], dtype=np.float32)
    return board, aux, mask.copy()


class QNetwork(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv = nn.Sequential(nn.Conv2d(CHANNELS, 16, 3, padding=1), nn.ReLU(),
            nn.Conv2d(16, 32, 3, stride=2, padding=1), nn.ReLU(),
            nn.Conv2d(32, 32, 3, stride=2, padding=1), nn.ReLU(), nn.Flatten())
        self.head = nn.Sequential(nn.Linear(32 * 5 * 5 + AUX_SIZE, 128), nn.ReLU(), nn.Linear(128, 6))

    def forward(self, board, aux):
        return self.head(torch.cat([self.conv(board.float() / 255.), aux.float()], dim=1))


def double_targets(rewards, done, online, target, masks, gamma):
    indices = online.masked_fill(~masks, -1e9).argmax(dim=1, keepdim=True)
    bootstrap = target.gather(1, indices).squeeze(1)
    return rewards + gamma * (1. - done.float()) * bootstrap
