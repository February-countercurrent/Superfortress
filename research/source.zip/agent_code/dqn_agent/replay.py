import numpy as np
from .network import CHANNELS, AUX_SIZE, SIZE


class Replay:
    def __init__(self, capacity=6000):
        self.capacity, self.size, self.position = capacity, 0, 0
        self.boards = np.empty((capacity, CHANNELS, SIZE, SIZE), dtype=np.uint8)
        self.next_boards = np.empty_like(self.boards)
        self.aux = np.empty((capacity, AUX_SIZE), dtype=np.float32)
        self.next_aux = np.empty_like(self.aux)
        self.actions = np.empty(capacity, dtype=np.int64)
        self.rewards = np.empty(capacity, dtype=np.float32)
        self.done = np.empty(capacity, dtype=bool)
        self.masks = np.empty((capacity, 6), dtype=bool)

    def add(self, old, action, reward, new, done):
        i = self.position
        self.boards[i], self.aux[i] = old[:2]
        self.next_boards[i], self.next_aux[i], self.masks[i] = new
        self.actions[i], self.rewards[i], self.done[i] = action, reward, done
        self.position = (i + 1) % self.capacity
        self.size = min(self.capacity, self.size + 1)

    def sample(self, rng, count):
        ix = rng.choice(self.size, count, replace=False)
        return [x[ix] for x in [self.boards, self.aux, self.actions, self.rewards,
                self.next_boards, self.next_aux, self.done, self.masks]]
