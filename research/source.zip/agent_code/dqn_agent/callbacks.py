"""CPU single-thread DQN inference; official timed safety and escape costs."""
import os
from pathlib import Path
import numpy as np
import torch
from .features import ACTIONS, describe
from .escape import escape_costs
from .network import QNetwork, encode, REWARD_SCALE


def setup(self):
    torch.set_num_threads(1)
    self.seed = int(os.environ.get('DQN_SEED', '42'))
    torch.manual_seed(self.seed)
    self.rng = np.random.default_rng(self.seed)
    self.model_path = Path(os.environ.get('DQN_MODEL', str(Path(__file__).parent / 'model.pt')))
    self.net = QNetwork().cpu()
    self.episodes = self.steps = self.updates = 0
    self.checkpoint = None
    if self.model_path.exists():
        self.checkpoint = torch.load(self.model_path, map_location='cpu')
        if self.checkpoint.get('version') != 1:
            raise ValueError('Incompatible DQN checkpoint')
        self.net.load_state_dict(self.checkpoint['network'])
        self.episodes = self.checkpoint['episodes']
        self.steps = self.checkpoint['steps']
        self.updates = self.checkpoint['updates']
    elif not self.train:
        raise FileNotFoundError(f'DQN checkpoint missing: {self.model_path}')
    self.net.eval()
    self.epsilon = 0.


def act(self, game_state):
    info = describe(game_state)
    board, aux, mask = encode(game_state, info)
    candidates = np.flatnonzero(mask)
    if self.train and self.rng.random() < self.epsilon:
        return ACTIONS[int(self.rng.choice(candidates))]
    with torch.no_grad():
        values = self.net(torch.from_numpy(board[None]), torch.from_numpy(aux[None]))[0].numpy()
    # Q values use reward/10 internally; restore original reward units before
    # applying the same escape/contest preference as the frozen Q-table agent.
    scores = values * REWARD_SCALE - escape_costs(game_state, info, bomb_cost=0., contest_scale=1.)
    best = candidates[np.isclose(scores[candidates], scores[candidates].max())]
    return ACTIONS[int(self.rng.choice(best))]
