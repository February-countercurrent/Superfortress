"""Terminal-safe Double DQN training; target network, replay, Huber loss."""
from collections import Counter
import csv
import numpy as np
import torch
from .features import ACTIONS, describe
from .network import QNetwork, encode, double_targets, REWARD_SCALE
from .replay import Replay

CONFIG = {'gamma': .9, 'learning_rate': 1e-4, 'batch_size': 32, 'replay_capacity': 6000,
          'warmup': 1024, 'update_every': 4, 'target_every_updates': 500,
          'epsilon_decay_steps': 60000, 'epsilon_min': .1, 'reward_scale': REWARD_SCALE}


def setup_training(self):
    self.target = QNetwork().cpu()
    self.target.load_state_dict(self.net.state_dict())
    self.target.eval()
    self.optimizer = torch.optim.Adam(self.net.parameters(), lr=CONFIG['learning_rate'])
    if self.checkpoint:
        if self.checkpoint['config'] != CONFIG:
            raise ValueError('Training configuration mismatch')
        if 'optimizer' in self.checkpoint:
            self.optimizer.load_state_dict(self.checkpoint['optimizer'])
            self.target.load_state_dict(self.checkpoint['target'])
    self.replay = Replay(CONFIG['replay_capacity'])
    self.pending = None
    self.counts = Counter()
    self.reward_sum = self.loss_sum = self.loss_count = 0
    self.epsilon = max(.1, 1 - .9 * self.steps / CONFIG['epsilon_decay_steps'])


def reward_for(old, action, events):
    info = describe(old)
    reward = (8 * events.count('COIN_COLLECTED') + events.count('CRATE_DESTROYED')
        + .5 * events.count('COIN_FOUND') + 15 * events.count('KILLED_OPPONENT')
        - .2 * events.count('BOMB_DROPPED') - events.count('INVALID_ACTION')
        - 25 * int('GOT_KILLED' in events or 'KILLED_SELF' in events) - .03)
    if not info['threatened'] and info['target']:
        if action in ACTIONS[:4]:
            reward += .8 * info['progress'][ACTIONS.index(action)]
        elif action == 'WAIT' and info['distance'] > 0:
            reward -= .8
    if action == 'BOMB':
        reward += (.5 * min(info['yield'], 3) + 1.5 * info['enemy_hits']) if info['safe'][5] else 0
        if info['yield'] == 0 and info['enemy_hits'] == 0:
            reward -= 1
    if action == 'WAIT' and not info['threatened']:
        reward -= .2
    return reward / REWARD_SCALE


def observe(self, old, action, new, events):
    if old is None or action not in ACTIONS:
        return
    previous = encode(old)
    if new is None:
        mask = np.array([False, False, False, False, True, False])
        following = (np.zeros_like(previous[0]), np.zeros_like(previous[1]), mask)
    else:
        following = encode(new)
    reward = reward_for(old, action, events)
    self.replay.add(previous, ACTIONS.index(action), reward, following, new is None)
    self.steps += 1
    self.epsilon = max(.1, 1 - .9 * self.steps / CONFIG['epsilon_decay_steps'])
    self.counts.update(events)
    self.reward_sum += reward * REWARD_SCALE
    if self.replay.size < CONFIG['warmup'] or self.steps % CONFIG['update_every']:
        return
    board, aux, actions, rewards, next_board, next_aux, done, masks = [torch.from_numpy(x)
        for x in self.replay.sample(self.rng, CONFIG['batch_size'])]
    with torch.no_grad():
        targets = double_targets(rewards, done, self.net(next_board, next_aux),
                                 self.target(next_board, next_aux), masks, CONFIG['gamma'])
    predicted = self.net(board, aux).gather(1, actions[:, None]).squeeze(1)
    loss = torch.nn.functional.smooth_l1_loss(predicted, targets)
    if not torch.isfinite(loss):
        raise FloatingPointError('Non-finite DQN loss')
    self.optimizer.zero_grad(set_to_none=True)
    loss.backward()
    torch.nn.utils.clip_grad_norm_(self.net.parameters(), 10.)
    self.optimizer.step()
    self.updates += 1
    if self.updates % CONFIG['target_every_updates'] == 0:
        self.target.load_state_dict(self.net.state_dict())
    self.loss_sum += float(loss.item())
    self.loss_count += 1


def game_events_occurred(self, old_game_state, self_action, new_game_state, events):
    if self.pending is not None:
        observe(self, *self.pending)
    self.pending = (old_game_state, self_action, new_game_state, list(events))


def end_of_round(self, last_game_state, last_action, events):
    if self.pending is not None:
        old = self.pending[0]
        if old is not None and (old['round'], old['step']) != (last_game_state['round'], last_game_state['step']):
            observe(self, *self.pending)
    self.pending = None
    observe(self, last_game_state, last_action, None, events)
    self.episodes += 1
    data = {'version': 1, 'network': self.net.state_dict(), 'target': self.target.state_dict(),
        'optimizer': self.optimizer.state_dict(), 'episodes': self.episodes, 'steps': self.steps,
        'updates': self.updates, 'config': CONFIG, 'seed': self.seed,
        'resume_note': 'Replay is not persisted; restart is a warm restart, not exact trajectory continuation.'}
    self.model_path.parent.mkdir(parents=True, exist_ok=True)
    temp = self.model_path.with_suffix('.tmp')
    torch.save(data, temp)
    temp.replace(self.model_path)
    path = self.model_path.with_suffix('.csv')
    exists = path.exists()
    names = ['COIN_COLLECTED', 'KILLED_OPPONENT', 'KILLED_SELF', 'GOT_KILLED', 'BOMB_DROPPED']
    with path.open('a', newline='') as handle:
        writer = csv.writer(handle)
        if not exists:
            writer.writerow(['episode', 'steps_total', 'updates', 'epsilon', 'reward', 'mean_loss', *names])
        writer.writerow([self.episodes, self.steps, self.updates, self.epsilon, self.reward_sum,
                         self.loss_sum / max(self.loss_count, 1), *[self.counts[n] for n in names]])
    self.counts.clear()
    self.reward_sum = self.loss_sum = self.loss_count = 0
