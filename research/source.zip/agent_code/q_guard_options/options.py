"""Three fixed restrictions, separately evaluated; no learned features changed."""
import numpy as np
from .features import allowed, blast
from .dynamic import candidate_mask_with_status
from .occupancy import filter_actions as full_filter


def threat_arrival(state):
    position = tuple(state['self'][3])
    times = [int(t) + 1 for p, t in state['bombs'] if position in blast(state['field'], tuple(p))]
    if state['explosion_map'][position] > 0:
        times.append(0)
    return min(times) if times else None


def filter_actions(state, info, original, scores, option='tie', enabled=True, deadline=None):
    if option not in ('full', 'tie', 'fallback', 'imminent'):
        raise ValueError(option)
    gate = bool(enabled and info['threatened'] and not state['self'][2])
    condition = gate
    extra = dict(option=option, condition_passed=condition, dynamic_fallback=None, threat_arrival=None)
    if gate and option == 'fallback':
        _, flag = candidate_mask_with_status(state, info, allowed(info, True))
        condition = bool(flag)
        extra['dynamic_fallback'] = condition
    if gate and option == 'imminent':
        arrival = threat_arrival(state)
        condition = arrival is not None and arrival <= 1
        extra['threat_arrival'] = arrival
    extra['condition_passed'] = condition
    if gate and not condition:
        return original, dict(eligible=True, reason='condition_skipped', applied=False, search=None, **extra)
    mask, details = full_filter(state, info, original, enabled=enabled, deadline=deadline)
    details.update(extra)
    if option == 'tie' and details['reason'] == 'filtered':
        choices = np.flatnonzero(original)
        best = choices[np.isclose(scores[choices], scores[choices].max())]
        intersection = np.zeros(6, dtype=bool)
        intersection[best] = mask[best]
        if not intersection.any():
            mask = original
            details['reason'] = 'no_certified_original_best'
        else:
            mask = intersection
            details['reason'] = 'tie_filtered'
        details['applied'] = bool(np.any(mask != original))
    return mask, details
