"""Stage-one tabular Q-learning: coin navigation, not tournament-ready.

AI-assisted initial implementation; student review and refinement are pending.
The path feature describes coin locations; learned Q values select the action.
"""
import json
import os
from collections import deque
from pathlib import Path

import numpy as np

ACTIONS = ('UP', 'RIGHT', 'DOWN', 'LEFT', 'WAIT')
DELTAS = ((0, -1), (1, 0), (0, 1), (-1, 0))
MODEL_PATH = Path(__file__).resolve().parent / 'model.json'


def describe(state):
    """Return compact state, legal actions, and distance to nearest coin.

    Multi-source BFS respects walls, crates, bombs and occupied opponent tiles.
    The four direction bits preserve ties between shortest paths.
    """
    field = state['field']
    position = tuple(state['self'][3])
    blocked = {tuple(b[0]) for b in state['bombs']}
    blocked.update(tuple(a[3]) for a in state['others'])

    def free(p):
        x, y = p
        return (0 <= x < field.shape[0] and 0 <= y < field.shape[1]
                and field[x, y] == 0 and p not in blocked)

    distances = {}
    queue = deque()
    for coin in state['coins']:
        coin = tuple(coin)
        if free(coin):
            distances[coin] = 0
            queue.append(coin)
    while queue:
        x, y = queue.popleft()
        for dx, dy in DELTAS:
            p = (x + dx, y + dy)
            if p not in distances and free(p):
                distances[p] = distances[(x, y)] + 1
                queue.append(p)
    distance = distances.get(position)
    legal, directions = [], []
    for dx, dy in DELTAS:
        p = (position[0] + dx, position[1] + dy)
        legal.append(free(p))
        directions.append(int(distance is not None
                              and distances.get(p, float('inf')) < distance))
    # 0: no reachable coin; 1: adjacent; 2: farther away.
    category = 0 if distance is None else (1 if distance <= 1 else 2)
    features = tuple(map(int, legal)) + tuple(directions) + (category,)
    return features, np.array(legal + [True], dtype=bool), distance


def state_to_features(game_state):
    return None if game_state is None else describe(game_state)[0]


def setup(self):
    self.rng = np.random.default_rng(int(os.environ.get('Q_SEED', '42')))
    self.q = {}
    self.episodes = 0
    self.model_path = Path(os.environ.get('Q_MODEL', str(MODEL_PATH))).resolve()
    if self.model_path.exists():
        data = json.loads(self.model_path.read_text(encoding='utf-8'))
        if data['version'] != 1 or data['actions'] != list(ACTIONS):
            raise ValueError('Incompatible Q-learning checkpoint')
        self.q = {tuple(map(int, k.split(','))): np.array(v, dtype=float)
                  for k, v in data['q'].items()}
        self.episodes = data['episodes']
    elif not self.train and os.environ.get('Q_ALLOW_UNTRAINED') != '1':
        raise FileNotFoundError(f'Train the agent first: {self.model_path}')
    self.epsilon = 0.0


def act(self, game_state):
    features, legal, _ = describe(game_state)
    candidates = np.flatnonzero(legal)
    if self.train and self.rng.random() < self.epsilon:
        return ACTIONS[int(self.rng.choice(candidates))]
    values = self.q.get(features, np.zeros(len(ACTIONS)))
    best = candidates[np.isclose(values[candidates], values[candidates].max())]
    return ACTIONS[int(self.rng.choice(best))]
