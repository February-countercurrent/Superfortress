"""One-step Q-learning with potential-based coin-distance shaping."""
import csv
import json
import os
from pathlib import Path

import numpy as np

from .callbacks import ACTIONS, describe


def setup_training(self):
    self.alpha = float(os.environ.get('Q_ALPHA', '0.2'))
    self.gamma = float(os.environ.get('Q_GAMMA', '0.95'))
    self.shaping = float(os.environ.get('Q_SHAPING', '0.2'))
    self.metrics_path = Path(os.environ.get('Q_METRICS', str(self.model_path.with_suffix('.csv'))))
    self.round_reward = 0.0
    self.round_coins = 0
    self.pending = None
    self.epsilon = max(0.05, 0.8 * 0.99 ** self.episodes)


def potential(distance):
    return 0.0 if distance is None else -float(distance)


def update(self, old_state, action, new_state, events):
    if old_state is None or action not in ACTIONS:
        return
    features, _, distance = describe(old_state)
    reward = (5.0 * events.count('COIN_COLLECTED') - 0.02
              - 1.0 * events.count('INVALID_ACTION')
              - 5.0 * events.count('GOT_KILLED')
              - 5.0 * events.count('KILLED_SELF'))
    future = 0.0
    next_potential = 0.0
    if new_state is not None:
        next_features, legal, next_distance = describe(new_state)
        future = self.q.get(next_features, np.zeros(len(ACTIONS)))[legal].max()
        next_potential = potential(next_distance)
    # Terminal states have zero potential and no bootstrap value.
    reward += self.shaping * (self.gamma * next_potential - potential(distance))
    values = self.q.setdefault(features, np.zeros(len(ACTIONS)))
    index = ACTIONS.index(action)
    values[index] += self.alpha * (reward + self.gamma * future - values[index])
    self.round_reward += reward
    self.round_coins += events.count('COIN_COLLECTED')


def game_events_occurred(self, old_game_state, self_action, new_game_state, events):
    # The upstream framework sends both callbacks for a survivor's final step.
    # Defer one transition so end_of_round can give it exactly one terminal update.
    if self.pending is not None:
        update(self, *self.pending)
    self.pending = (old_game_state, self_action, new_game_state, list(events))


def end_of_round(self, last_game_state, last_action, events):
    if self.pending is not None:
        previous = self.pending[0]
        if previous is not None and (previous['round'], previous['step']) != (
                last_game_state['round'], last_game_state['step']):
            update(self, *self.pending)
    self.pending = None
    update(self, last_game_state, last_action, None, events)
    self.episodes += 1
    self.model_path.parent.mkdir(parents=True, exist_ok=True)
    data = {'version': 1, 'actions': list(ACTIONS), 'episodes': self.episodes,
            'q': {','.join(map(str, k)): v.tolist() for k, v in self.q.items()},
            'hyperparameters': {'alpha': self.alpha, 'gamma': self.gamma,
                                'shaping': self.shaping}}
    temporary = self.model_path.with_suffix('.tmp')
    temporary.write_text(json.dumps(data), encoding='utf-8')
    temporary.replace(self.model_path)
    self.metrics_path.parent.mkdir(parents=True, exist_ok=True)
    new_file = not self.metrics_path.exists()
    with self.metrics_path.open('a', newline='', encoding='utf-8') as handle:
        writer = csv.writer(handle)
        if new_file:
            writer.writerow(['episode', 'steps', 'coins', 'shaped_return', 'epsilon', 'states'])
        writer.writerow([self.episodes, last_game_state['step'], self.round_coins,
                         self.round_reward, self.epsilon, len(self.q)])
    self.round_reward = 0.0
    self.round_coins = 0
    self.epsilon = max(0.05, 0.8 * 0.99 ** self.episodes)
