"""Use the learned enemy-bearing residual only to resolve existing move ties."""
from types import SimpleNamespace

import numpy as np

from . import residual
from .features import ACTIONS, describe
from .symmetry_maps import PERMUTATIONS, transform_key


def setup(self):
    if self.train:
        raise ValueError('q_direction_tie is an inference-only experiment')
    residual.setup(self)
    self.base_policy = SimpleNamespace(
        q={k: v for k, v in self.q.items() if k[0] < 7},
        direction_mode=self.direction_mode)


def averaged_residual(self, key):
    """Direction preferences, without adding them to the baseline Q values."""
    total = np.zeros(6)
    if not residual.residual_active(key):
        return total
    for permutation in PERMUTATIONS:
        transformed = residual.policy_key(self, transform_key(key, permutation))
        tile = residual.active_tiles(transformed)[-1]
        total += self.q.get(tile, np.zeros(6))[list(permutation)]
    return total / len(PERMUTATIONS)


def refine_movement_tie(best, key, preferences):
    """Return a subset of the old greedy set, or preserve that set exactly.

    np.isclose uses the same tie convention as the accepted policy. Ties
    involving WAIT/BOMB, unique choices, and other phases never change.
    """
    if len(best) < 2 or np.any(best >= 4) or not residual.residual_active(key):
        return best
    values = preferences[best]
    return best[np.isclose(values, values.max())]


def decision(self, game_state):
    mask, scores, urgent_corrected = residual.scored_actions(self.base_policy, game_state)
    candidates = np.flatnonzero(mask)
    best = candidates[np.isclose(scores[candidates], scores[candidates].max())]
    selected = best
    if len(best) > 1 and np.all(best < 4):
        key = describe(game_state)['key']
        if residual.residual_active(key):
            selected = refine_movement_tie(best, key, averaged_residual(self, key))
    return mask, scores, urgent_corrected, best, selected


def act(self, game_state):
    *_, selected = decision(self, game_state)
    return ACTIONS[int(self.rng.choice(selected))]
