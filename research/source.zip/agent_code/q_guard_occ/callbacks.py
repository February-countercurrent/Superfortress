"""Independent candidate: adopted E plus bounded persistent-occupancy retreat."""
import json
import os
import time
from pathlib import Path

import numpy as np

from . import base
from .features import ACTIONS, describe
from .history import PursuitLedger
from .resource_inventory import CoinInventory
from .switching import SwitchController
from .occupancy import filter_actions

MODES = {'A': (False, False, False), 'B': (True, False, False),
         'C': (True, True, False), 'D': (True, False, True), 'E': (True, True, True)}


def encode(value):
    if isinstance(value, np.generic):
        return value.item()
    raise TypeError(type(value).__name__)


def setup(self):
    base.setup(self)
    self.occupancy_mode = os.environ.get('QL_OCCUPANCY_MODE', 'on')
    if self.occupancy_mode not in ('off', 'on'):
        raise ValueError('QL_OCCUPANCY_MODE must be off or on')
    self.guard_mode = 'E'
    if self.guard_mode not in MODES:
        raise ValueError('QL_GUARD_MODE must be A, B, C, D, or E')
    self.guard_seed = int(os.environ.get('QL_SEED', '42'))
    # Public classic tournament rule, fixed with the accepted policy. This
    # must work without the evaluation harness providing environment values.
    self.coin_total = 9
    self.guard_round = None
    trace = os.environ.get('QL_GUARD_TRACE', '')
    self.guard_trace = Path(trace).open('x', encoding='utf-8', buffering=1) if trace else None


def act(self, game_state):
    deadline = time.perf_counter() + .2
    enabled, inventory_guard, bomb_guard = MODES[self.guard_mode]
    if self.guard_round != game_state['round']:
        self.guard_round = game_state['round']
        self.rng = np.random.default_rng(np.random.SeedSequence([self.guard_seed, self.guard_round, 101]))
        self.proposal_rng = np.random.default_rng(np.random.SeedSequence([self.guard_seed, self.guard_round, 102]))
        self.occupancy_rng = np.random.default_rng(np.random.SeedSequence([self.guard_seed, self.guard_round, 103]))
        self.guard_ledger = PursuitLedger()
        self.guard_controller = SwitchController(inventory_guard, bomb_guard)
        self.coin_inventory = CoinInventory(self.coin_total)
    inventory = self.coin_inventory.observe(game_state)
    ledger = self.guard_ledger
    history = ledger.observe(game_state)
    mask, scores, urgent = base.scored_actions(self, game_state)
    info = describe(game_state)
    candidates = np.flatnonzero(mask)
    best = candidates[np.isclose(scores[candidates], scores[candidates].max())]
    baseline = int(self.rng.choice(best))
    selected = baseline
    details = dict(activated=False, reason='off', commitment=None, allowed=[], guard=None, accepted=False)
    if enabled:
        options, details = self.guard_controller.select_guarded(
            game_state, info, mask, scores, ledger, history, self.proposal_rng, inventory, baseline)
        if options and baseline not in options:
            selected = int(self.proposal_rng.choice(options))
        self.guard_controller.after_action(selected, details)
    assert mask[selected]
    assert not info['threatened'] or selected == baseline
    assert not bomb_guard or selected != 5 or baseline == 5
    refined, occupancy = filter_actions(game_state, info, mask,
        enabled=self.occupancy_mode == 'on', deadline=deadline)
    occupancy['candidate_mask'] = refined.tolist()
    if not refined[selected]:
        viable = np.flatnonzero(refined)
        revised_best = viable[np.isclose(scores[viable], scores[viable].max())]
        selected = int(self.occupancy_rng.choice(revised_best))
    assert mask[selected] and refined[selected]
    occupancy['changed'] = selected != baseline if occupancy['eligible'] else False
    ledger.remember_action(game_state, ACTIONS[selected])
    if self.guard_trace:
        record = dict(round=game_state['round'], step=game_state['step'], mode=self.guard_mode,
                      position=list(game_state['self'][3]), own_score=game_state['self'][1],
                      history=history, original_target=info['target'], threatened=bool(info['threatened']),
                      urgent_corrected=urgent, candidate_mask=mask.tolist(), scores=scores.tolist(),
                      baseline_best=best.tolist(), baseline_action=ACTIONS[baseline], action=ACTIONS[selected],
                      changed=selected != baseline, inventory=inventory, decision=details,
                      bomb_available=bool(game_state['self'][2]), occupancy=occupancy,
                      random_streams=[self.guard_seed, self.guard_round, 101, 102])
        self.guard_trace.write(json.dumps(record, default=encode) + '\n')
    return ACTIONS[selected]
