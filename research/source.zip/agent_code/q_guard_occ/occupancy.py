"""Offline single-moving-opponent game with persistent positions and both orders.

Known bomb schedule only, no future enemy BOMB, all other enemies WAIT until
killed by a known blast. Own policy can adapt after each observed transition.
Each reported certificate concerns ONE moving enemy, not simultaneous movement
of all enemies. Any unfinished search makes the integration keep the old policy.
"""
from functools import lru_cache
import time

import numpy as np

import settings
from .features import DELTAS, forecast, blast

STAY = 4


def timeline(state, plant, horizon):
    field = state['field']
    danger = np.zeros((horizon + 1,) + field.shape, dtype=bool)
    opens = np.where(field == 0, 0, horizon + 2)
    occupied = np.zeros(field.shape, dtype=int)
    bombs = list(state['bombs'])
    if plant:
        bombs.append((tuple(state['self'][3]), settings.BOMB_TIMER))
    for p, timer in bombs:
        p = tuple(p)
        detonation = timer + 1
        occupied[p] = max(occupied[p], detonation)
        for cell in blast(field, p):
            danger[detonation:detonation + settings.EXPLOSION_TIMER, cell[0], cell[1]] = True
            if field[cell] == 1:
                opens[cell] = min(opens[cell], detonation + 1)
    for tick in range(1, horizon + 1):
        danger[tick] |= state['explosion_map'] >= tick
    return opens, occupied, danger


def move(position, action, other, enterable, fixed=frozenset()):
    if position is None or action == STAY:
        return position
    dx, dy = DELTAS[action]
    destination = position[0] + dx, position[1] + dy
    if not (0 <= destination[0] < enterable.shape[0] and 0 <= destination[1] < enterable.shape[1]):
        return position
    if enterable[destination] and destination != other and destination not in fixed:
        return destination
    return position


def transition(own, enemy, own_action, enemy_action, own_first, enterable, danger, fixed=frozenset()):
    if own_first:
        own = move(own, own_action, enemy, enterable, fixed)
        enemy = move(enemy, enemy_action, own, enterable, fixed)
    else:
        enemy = move(enemy, enemy_action, own, enterable, fixed)
        own = move(own, own_action, enemy, enterable, fixed)
    alive = not danger[own]
    if enemy is not None and danger[enemy]:
        enemy = None
    return own, enemy, alive


class NodeLimit(Exception):
    pass


class TimeLimit(Exception):
    pass


def evaluate(state, plant=False, max_nodes=20000, first_actions=None, deadline=None):
    started = time.perf_counter()
    horizon = max([6 if plant else 1, int(state['explosion_map'].max())]
                  + [int(timer) + 2 for _, timer in state['bombs']])
    opens, occupied, danger = timeline(state, plant, horizon)
    enter = [(opens <= tick) & (occupied < tick) for tick in range(horizon + 1)]
    own = tuple(state['self'][3])
    actions = [STAY] if plant else list(range(5)) if first_actions is None else list(first_actions)
    by_enemy = []
    for index, other in enumerate(state['others']):
        enemy = tuple(other[3])
        static = {tuple(o[3]) for j, o in enumerate(state['others']) if j != index}
        fixed = [frozenset(static)]
        for tick in range(1, horizon + 1):
            fixed.append(frozenset(static))
            static = {p for p in static if not danger[tick][p]}
        nodes = 0

        @lru_cache(None)
        def winning(tick, p, q):
            nonlocal nodes
            nodes += 1
            if nodes > max_nodes:
                raise NodeLimit
            if tick > horizon:
                return True
            return any(action_wins(tick, p, q, a) for a in range(5))

        def action_wins(tick, p, q, a):
            if deadline is not None and time.perf_counter() >= deadline:
                raise TimeLimit
            following = set()
            for b in (range(5) if q is not None else (STAY,)):
                for own_first in (True, False):
                    pp, qq, alive = transition(p, q, a, b, own_first, enter[tick], danger[tick], fixed[tick])
                    if not alive:
                        return False
                    following.add((pp, qq))
            return all(winning(tick + 1, pp, qq) for pp, qq in sorted(following, key=repr))

        safe, exhausted, timed_out = {}, False, False
        try:
            for action in actions:
                safe[action] = action_wins(1, own, enemy, action)
        except NodeLimit:
            exhausted = True
        except TimeLimit:
            exhausted, timed_out = True, True
        by_enemy.append(dict(enemy=other[0], actions={str(a): safe.get(a) for a in actions},
                             nodes=nodes, budget_exhausted=exhausted, timed_out=timed_out))
    if by_enemy:
        combined = {}
        for action in actions:
            values = [r['actions'][str(action)] for r in by_enemy]
            combined[str(action)] = False if False in values else None if None in values else True
    else:
        viable = forecast(state, new_bomb=plant)
        combined = {}
        for action in actions:
            q = own if action == STAY else (own[0] + DELTAS[action][0], own[1] + DELTAS[action][1])
            combined[str(action)] = bool(viable[q] and (action == STAY or enter[1][q]))
    return dict(plant=plant, horizon=horizon, actions=combined, one_enemy_models=by_enemy,
                nodes=sum(v['nodes'] for v in by_enemy), elapsed_ms=(time.perf_counter() - started) * 1000)


def filter_actions(state, info, original, enabled=True, deadline=None):
    details = dict(eligible=False, reason='off', applied=False, search=None)
    if not enabled:
        return original, details
    if not info['threatened'] or state['self'][2]:
        details['reason'] = 'outside_escape_gate'
        return original, details
    details['eligible'] = True
    result = evaluate(state, first_actions=np.flatnonzero(original[:5]).tolist(), deadline=deadline)
    details['search'] = result
    if any(r['budget_exhausted'] for r in result['one_enemy_models']):
        details['reason'] = 'search_incomplete'
        return original, details
    certified = original.copy()
    certified[5] = False
    for action in np.flatnonzero(original[:5]):
        certified[action] = result['actions'].get(str(action)) is True
    if not certified.any():
        details['reason'] = 'empty_intersection'
        return original, details
    details.update(reason='filtered', applied=bool(np.any(certified != original)))
    return certified, details
