"""Tabular Q-learning with six actions and an optional safety shield."""
import json
import os
from pathlib import Path

import numpy as np

from .features import ACTIONS, allowed, describe


def setup(self):
    self.rng = np.random.default_rng(int(os.environ.get('QB_SEED', '42')))
    self.model_path = Path(os.environ.get('QB_MODEL', str(Path(__file__).resolve().parent / 'model.json')))
    self.shield = os.environ.get('QB_SHIELD', '1') == '1'
    self.q, self.visits, self.episodes = {}, {}, 0
    if self.model_path.exists():
        data = json.loads(self.model_path.read_text(encoding='utf-8'))
        if data['version'] != 3 or data['actions'] != list(ACTIONS):
            raise ValueError('Incompatible bomber model')
        self.q = {tuple(map(int, k.split(','))): np.array(v, dtype=float) for k, v in data['q'].items()}
        self.visits = {tuple(map(int, k.split(','))): np.array(v, dtype=int) for k, v in data.get('visits', {}).items()}
        self.episodes = data['episodes']
    elif not self.train and os.environ.get('QB_ALLOW_UNTRAINED') != '1':
        raise FileNotFoundError(f'Train first: {self.model_path}')
    self.epsilon = 0.


def act(self, game_state):
    info = describe(game_state)
    candidates = np.flatnonzero(allowed(info, self.shield))
    if self.train and self.rng.random() < self.epsilon:
        return ACTIONS[int(self.rng.choice(candidates))]
    values = self.q.get(info['key'], np.zeros(6))
    best = candidates[np.isclose(values[candidates], values[candidates].max())]
    return ACTIONS[int(self.rng.choice(best))]
