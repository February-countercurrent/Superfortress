"""Terminal-safe one-step learning, metrics, and portable JSON checkpoints."""
import csv
import json
import os
from collections import Counter

import numpy as np

from .features import ACTIONS, allowed, describe


def setup_training(self):
    self.alpha = float(os.environ.get('QB_ALPHA', '.15'))
    self.gamma = float(os.environ.get('QB_GAMMA', '.7'))
    self.shaping = float(os.environ.get('QB_SHAPING', '0'))
    self.progress = float(os.environ.get('QB_PROGRESS', '.8'))
    self.decay = float(os.environ.get('QB_DECAY', '.99'))
    self.epsilon = max(.05, .8 * self.decay ** self.episodes)
    self.pending = None
    self.counts = Counter()
    self.total_reward = 0.


def update(self, old, action, new, events):
    if old is None or action not in ACTIONS:
        return
    info = describe(old)
    reward = (8 * events.count('COIN_COLLECTED') + events.count('CRATE_DESTROYED')
              + .5 * events.count('COIN_FOUND') + 15 * events.count('KILLED_OPPONENT')
              - .2 * events.count('BOMB_DROPPED') - events.count('INVALID_ACTION')
              - 25 * int('GOT_KILLED' in events or 'KILLED_SELF' in events) - .03)
    future, next_potential = 0., 0.
    if new is not None:
        next_info = describe(new)
        future = self.q.get(next_info['key'], np.zeros(6))[allowed(next_info, self.shield)].max()
        next_potential = -next_info['distance']
    reward += self.shaping * (self.gamma * next_potential + info['distance'])
    # Balanced local shaping avoids reward for alternating toward/away moves.
    # This is an experimental reward heuristic, not an optimality guarantee.
    if not info['threatened'] and info['target']:
        if action in ACTIONS[:4]:
            reward += self.progress * info['progress'][ACTIONS.index(action)]
        elif action == 'WAIT' and info['distance'] > 0:
            reward -= self.progress
    if action == 'BOMB':
        reward += .5 * min(info['yield'], 3) if info['safe'][5] else 0.
        if info['yield'] == 0 and not old['others']:
            reward -= 1.
    if action == 'WAIT' and not info['threatened']:
        reward -= .2
    values = self.q.setdefault(info['key'], np.zeros(6))
    visits = self.visits.setdefault(info['key'], np.zeros(6, dtype=int))
    index = ACTIONS.index(action)
    visits[index] += 1
    rate = max(.02, self.alpha / (1 + visits[index] / 200))
    values[index] += rate * (reward + self.gamma * future - values[index])
    self.counts.update(events)
    self.total_reward += reward


def game_events_occurred(self, old_game_state, self_action, new_game_state, events):
    if self.pending is not None:
        update(self, *self.pending)
    self.pending = (old_game_state, self_action, new_game_state, list(events))


def end_of_round(self, last_game_state, last_action, events):
    if self.pending is not None:
        previous = self.pending[0]
        if previous is not None and (previous['round'], previous['step']) != (last_game_state['round'], last_game_state['step']):
            update(self, *self.pending)
    self.pending = None
    update(self, last_game_state, last_action, None, events)
    self.episodes += 1
    self.model_path.parent.mkdir(parents=True, exist_ok=True)
    data = {'version': 3, 'actions': list(ACTIONS), 'episodes': self.episodes,
            'q': {','.join(map(str, k)): v.tolist() for k, v in self.q.items()},
            'visits': {','.join(map(str, k)): v.tolist() for k, v in self.visits.items()},
            'config': {'alpha': self.alpha, 'gamma': self.gamma, 'shaping': self.shaping,
                       'progress': self.progress, 'decay': self.decay, 'shield': self.shield}}
    temporary = self.model_path.with_suffix('.tmp')
    temporary.write_text(json.dumps(data), encoding='utf-8')
    temporary.replace(self.model_path)
    metrics = self.model_path.with_suffix('.csv')
    new_file = not metrics.exists()
    names = ['COIN_COLLECTED', 'CRATE_DESTROYED', 'BOMB_DROPPED', 'KILLED_SELF', 'GOT_KILLED']
    with metrics.open('a', newline='', encoding='utf-8') as handle:
        writer = csv.writer(handle)
        if new_file:
            writer.writerow(['episode', 'steps', 'epsilon', 'states', 'reward'] + names)
        writer.writerow([self.episodes, last_game_state['step'], self.epsilon, len(self.q), self.total_reward]
                        + [self.counts[name] for name in names])
    self.counts.clear()
    self.total_reward = 0.
    self.epsilon = max(.05, .8 * self.decay ** self.episodes)
