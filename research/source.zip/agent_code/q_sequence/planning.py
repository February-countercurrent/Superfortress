"""Receding-horizon move/plant/escape plans with optimistic enemy reach sets.

At most two moves before planting. Executes only the first action and replans.
Enemy movement is a reachable envelope, not a guessed trajectory. Checks own
escape against each nearby bomb-ready enemy planting now, one at a time.
This bounded model is not a full multiplayer minimax solver.
"""
import numpy as np
import settings
from .features import DELTAS, blast

STEPS = (*DELTAS, (0, 0))
HORIZON = settings.BOMB_TIMER + settings.EXPLOSION_TIMER + 2


def schedule(state, planting=None, extra_bomb=None):
    field = state['field']
    opens = np.where(field == 0, 0, HORIZON + 2)
    occupied = np.zeros((HORIZON + 1,) + field.shape, dtype=bool)
    danger = np.zeros_like(occupied)
    bombs = [(tuple(p), 1, t + 1) for p, t in state['bombs']]
    if planting:
        p, tick = planting
        bombs.append((tuple(p), tick, tick + settings.BOMB_TIMER))
    if extra_bomb is not None:
        bombs.append((tuple(extra_bomb), 1, 1 + settings.BOMB_TIMER))
    for p, placed, explodes in bombs:
        occupied[placed:explodes + 1, p[0], p[1]] = True
        for cell in blast(field, p):
            danger[explodes:explodes + settings.EXPLOSION_TIMER, cell[0], cell[1]] = True
            if field[cell] == 1:
                opens[cell] = min(opens[cell], explodes + 1)
    for tick in range(1, HORIZON + 1):
        danger[tick] |= state['explosion_map'] >= tick
    return opens, occupied, danger


def advance(reach, tick, grid):
    opens, occupied, danger = grid
    moves = np.zeros_like(reach)
    moves[:, :-1] |= reach[:, 1:]
    moves[1:, :] |= reach[:-1, :]
    moves[:, 1:] |= reach[:, :-1]
    moves[:-1, :] |= reach[1:, :]
    return (reach | (moves & ~occupied[tick])) & (opens <= tick) & ~danger[tick]


def singleton(shape, position):
    mask = np.zeros(shape, dtype=bool)
    mask[tuple(position)] = True
    return mask


def trace(start, grid):
    reachable = [singleton(grid[0].shape, start)]
    for tick in range(1, HORIZON + 1):
        reachable.append(advance(reachable[-1], tick, grid))
    return reachable


def own_escape(state, path, grid):
    """Prescribed movement prefix and planting WAIT, then any safe escape."""
    pos = tuple(state['self'][3])
    opens, occupied, danger = grid
    for tick, destination in enumerate(path + [path[-1] if path else pos], 1):
        if opens[destination] > tick or danger[tick][destination]:
            return False
        if destination != pos and occupied[tick][destination]:
            return False
        pos = destination
    reach = singleton(opens.shape, pos)
    for tick in range(len(path) + 2, HORIZON + 1):
        reach = advance(reach, tick, grid)
    return bool(reach.any())


def enumerate_plans(state, info, scores):
    pos = tuple(state['self'][3])
    enemies = [o for o in state['others'] if abs(o[3][0]-pos[0]) + abs(o[3][1]-pos[1]) <= 6]
    if not enemies or not state['self'][2]:
        return []
    base = schedule(state)
    traces = [trace(o[3], base) for o in enemies]
    blockers = {tuple(o[3]) for o in state['others']}
    prefixes = [([], 5)]
    frontier = [([], pos, None)]
    for depth in (1, 2):
        following = []
        seen = set()
        for path, previous, first in frontier:
            for action, (dx, dy) in enumerate(STEPS):
                dest = previous[0] + dx, previous[1] + dy
                first_action = action if first is None else first
                if not info['safe'][first_action] or dest in blockers:
                    continue
                if not (0 <= dest[0] < base[0].shape[0] and 0 <= dest[1] < base[0].shape[1]):
                    continue
                if base[0][dest] > depth or base[2][depth][dest]:
                    continue
                if dest != previous and base[1][depth][dest]:
                    continue
                if (dest, first_action) in seen:
                    continue
                seen.add((dest, first_action))
                candidate = path + [dest]
                following.append((candidate, dest, first_action))
                prefixes.append((candidate, first_action))
        frontier = following
    results = []
    for path, first in prefixes:
        if not info['safe'][first]:
            continue
        site = path[-1] if path else pos
        planting = (site, len(path) + 1)
        grid = schedule(state, planting)
        if not own_escape(state, path, grid):
            continue
        # Reject plans lacking a route if any one observed nearby opponent
        # plants immediately; does not enumerate future or simultaneous bombs.
        if any(not own_escape(state, path, schedule(state, planting, tuple(o[3]))) for o in enemies if o[2]):
            continue
        pressure, traps = 0., 0
        for enemy, old_trace in zip(enemies, traces):
            before = int(old_trace[-1].sum())
            after = int(trace(enemy[3], grid)[-1].sum())
            traps += before > 0 and after == 0
            if before:
                pressure = max(pressure, max(0., 1 - after / before))
        # A move into an enemy's reachable envelope is a possible collision,
        # so prefer less contested prefixes without declaring them impossible.
        contested = sum(any(t[tick][cell] for t in traces) for tick, cell in enumerate(path, 1))
        value = 5. * min(traps, 1) + pressure - .15 * len(path) - .5 * contested
        results.append({'first_action': first, 'path': path, 'planting_tick': planting[1],
            'planting_position': site, 'pressure': pressure, 'traps': int(traps),
            'contested_steps': contested, 'value': value, 'q_tiebreak': float(scores[first])})
    return results


def choose_plan(state, info, scores):
    # Leave resource collection with the learned policy. Plan attacks when it
    # already targets combat, or after every crate and coin has gone.
    exhausted = not state['coins'] and not np.any(state['field'] == 1)
    if info['target'] != 3 and not exhausted:
        return None
    if exhausted and state['step'] >= 300 and state['self'][1] > max([o[1] for o in state['others']], default=-1):
        return None  # no new attack override while visibly leading late
    plans = enumerate_plans(state, info, scores)
    useful = [p for p in plans if p['traps'] or p['value'] >= .25]
    return max(useful, key=lambda p: (p['value'], p['q_tiebreak'])) if useful else None
