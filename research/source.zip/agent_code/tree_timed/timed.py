"""Six public attack descriptors; they never change the deployed safety mask.

Potential enemy survival omits player occupancy and unknown future bombs.
Adjacent candidate sites describe current geometry, not a move-then-bomb plan.
"""
import numpy as np
import settings
from .features import DELTAS,blast,forecast,distance_map
from .tactical import tactical_key

NO_TARGET,ALREADY_TRAPPED,NEW_TRAP,REDUCED_ROUTES,UNCHANGED,UNAVAILABLE=range(6)


def first_actions(field,viable,occupied,position):
    points=[position]+[(position[0]+dx,position[1]+dy) for dx,dy in DELTAS]
    return sum(bool(viable[p]) and bool(field[p]==0) and (p==position or p not in occupied) for p in points)


def descriptors(state):
    field=state['field'];position=tuple(state['self'][3])
    enemies=[tuple(o[3]) for o in state['others']]
    occupied={tuple(p) for p,_ in state['bombs']}
    origins=[position]+[(position[0]+dx,position[1]+dy) for dx,dy in DELTAS]
    open_state=dict(state,others=[])
    original_viable=None;before={};codes=[]
    for origin in origins:
        if field[origin]!=0 or origin in occupied or origin in enemies:
            codes.append(UNAVAILABLE);continue
        ray=set(blast(field,origin));targets=[p for p in enemies if p in ray]
        if not targets:
            codes.append(NO_TARGET);continue
        if original_viable is None:
            original_viable=forecast(open_state)
        for p in targets:
            if p not in before:before[p]=first_actions(field,original_viable,occupied,p)
        extra=dict(open_state,bombs=list(state['bombs'])+[(origin,settings.BOMB_TIMER)])
        after_viable=forecast(extra);blocked=occupied|{origin}
        after={p:first_actions(field,after_viable,blocked,p) for p in targets}
        # Prefer the strongest newly created pressure across ray targets.
        if any(before[p]>0 and after[p]==0 for p in targets):code=NEW_TRAP
        elif any(0<after[p]<before[p] for p in targets):code=REDUCED_ROUTES
        elif any(before[p]==0 for p in targets):code=ALREADY_TRAPPED
        else:code=UNCHANGED
        codes.append(code)
    ray=set(blast(field,position));targets=[p for p in enemies if p in ray]
    lengths=[]
    for enemy in targets:
        free=field==0
        for p in occupied|{position}:free[p]=False
        free[enemy]=True  # The enemy may leave its own underlying bomb.
        outside=free.copy()
        for p in ray:outside[p]=False
        distance=int(distance_map(free,list(zip(*np.where(outside))))[enemy])
        lengths.append(5 if distance<0 else min(distance,4))
    return np.asarray(codes+[max(lengths,default=0)],dtype=np.int8)


def timed_key(state,info=None):
    return np.concatenate((tactical_key(state,info),descriptors(state)))
