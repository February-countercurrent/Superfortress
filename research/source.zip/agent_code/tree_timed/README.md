# Timed attack feature experiment

Inference-only research candidate, not the submitted Superfortress agent.
The original 28 features remain intact; five timed attack categories and one
escape-distance category are appended. Safety masks, retreat correction,
random streams, rewards and ExtraTrees capacity are unchanged.

Indices 28 and 33 are D4 invariants; indices 29..32 rotate with UP/RIGHT/DOWN/LEFT.
Attack categories: 0 no ray target, 1 already trapped by known hazards,
2 a newly blocked escape, 3 fewer viable first actions, 4 no reduction,
5 unavailable bomb site. Multi-target priority is new trap, reduced routes,
already trapped, unchanged. Distance is the hardest ray target's shortest
static route off the prospective blast: 0 no target, 1/2/3 moves, 4 at least
four moves, 5 no static route. Player blocking is omitted for enemy escape.

Use only the separately fitted 34-feature model for candidate deployment.
The decoder accepts historical feature sizes solely for equivalence testing.
AI-assisted implementation; student review and understanding are required.
