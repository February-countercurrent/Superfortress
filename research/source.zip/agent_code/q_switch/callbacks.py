"""Frozen Q policy with an optional eight-action resource commitment."""
import json
import os
from pathlib import Path

import numpy as np

from . import base
from .features import ACTIONS, describe
from .history import PursuitLedger
from .switching import SwitchController


def encode(value):
    if isinstance(value, np.generic):
        return value.item()
    raise TypeError(type(value).__name__)


def setup(self):
    base.setup(self)
    self.switch_mode = os.environ.get('QL_SWITCH_MODE', 'switch')
    if self.switch_mode not in ('off', 'switch'):
        raise ValueError('QL_SWITCH_MODE must be off or switch')
    self.switch_round = None
    self.switch_ledger = PursuitLedger()
    self.switch_controller = SwitchController()
    trace = os.environ.get('QL_SWITCH_TRACE', '')
    self.switch_trace = Path(trace).open('x', encoding='utf-8', buffering=1) if trace else None


def act(self, game_state):
    if self.switch_round != game_state['round']:
        self.switch_round = game_state['round']
        self.switch_ledger = PursuitLedger()
        self.switch_controller = SwitchController()
    ledger = self.switch_ledger
    history = ledger.observe(game_state)
    mask, scores, urgent = base.scored_actions(self, game_state)
    info = describe(game_state)
    candidates = np.flatnonzero(mask)
    best = candidates[np.isclose(scores[candidates], scores[candidates].max())]
    baseline = int(self.rng.choice(best))
    selected = baseline
    details = dict(activated=False, reason='off', commitment=None, allowed=[])
    if self.switch_mode == 'switch':
        options, details = self.switch_controller.select(game_state, info, mask, scores, ledger, history, self.rng)
        if options and baseline not in options:
            selected = int(self.rng.choice(options))
        self.switch_controller.after_action(selected, details)
    assert mask[selected]
    if info['threatened']:
        assert selected == baseline
    ledger.remember_action(game_state, ACTIONS[selected])
    if self.switch_trace:
        record = dict(round=game_state['round'], step=game_state['step'], mode=self.switch_mode,
                      position=list(game_state['self'][3]), own_score=game_state['self'][1],
                      history=history, original_target=info['target'], threatened=bool(info['threatened']),
                      urgent_corrected=urgent, candidate_mask=mask.tolist(), scores=scores.tolist(),
                      baseline_best=best.tolist(), baseline_action=ACTIONS[baseline], action=ACTIONS[selected],
                      changed=selected != baseline, decision=details)
        self.switch_trace.write(json.dumps(record, default=encode) + '\n')
    return ACTIONS[selected]
