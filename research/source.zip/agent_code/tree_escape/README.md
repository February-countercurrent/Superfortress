# Tactical tree escape experiment

Frozen joint-tree checkpoint (SHA256 397045e64700cb64b3413c1145c3ace4bad258e53ed8db2657feaed8d1ce5ed9),
28 features, six ExtraTrees heads, D4 averaging and original dynamic safety mask.
Inference-only WAIT-to-retreat guard, no retraining. When threatened and WAIT
is uniquely preferred, choose an originally safe masked move that strictly
shortens the static route outside every observed blast. Q ranks equally short
moves. The model does not see hidden bomb owners or future opponent moves.

Research candidate only. See TREE_ESCAPE_PLAN.md and the resulting evaluation;
the Superfortress tournament submission and default pilot tree are unchanged.
Disable the guard with FQI_ESCAPE_GUARD=0 for equivalence testing. Optional
FQI_POLICY_TRACE logs policy decisions; this is not a packaged submission.
