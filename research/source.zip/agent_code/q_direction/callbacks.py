"""Frozen seven-block Q policy plus one local movement residual."""
import json
import hashlib
import os
from pathlib import Path
import numpy as np
from .features import ACTIONS, allowed, describe
from .escape import escape_costs
from .dynamic import candidate_mask, candidate_mask_with_status
from .symmetry_maps import PERMUTATIONS, transform_key

# Legacy observations retain their exact semantics. Only the eighth block
# sees the added bearings; seven existing blocks are read-only.
BASE_BLOCKS = ((), (0, 1, 2, 3, 4, 5, 12), (6, 7, 8, 9, 10, 13),
          (10, 11, 13), (10, 14, 15), (5, 11, 12, 14), (10, 12, 14, 15))
BLOCKS = BASE_BLOCKS + ((5,13,16,17,18,19),)


def frozen_base_digest(q):
    values = {','.join(map(str,k)):np.asarray(v,dtype=float).tolist()
              for k,v in q.items() if k[0] < 7}
    return hashlib.sha256(json.dumps(values,sort_keys=True,separators=(',',':')).encode()).hexdigest()


def policy_key(self, key):
    if len(key) != 20:
        raise ValueError('Expected 20-feature direction observation')
    if self.direction_mode == 'blind':
        return tuple(key[:16]) + (0,0,0,0)
    return tuple(key)


def residual_active(key):
    # Direction residual only changes calm attack movement. Resources,
    # emergencies, WAIT and BOMB retain their learned base values.
    return key[10] == 3 and key[12] == 0


def active_tiles(key):
    if len(key) != 20:
        raise ValueError('Expected 20-feature direction observation')
    groups = BLOCKS if residual_active(key) else BASE_BLOCKS
    return [(i, *[key[j] for j in group]) for i, group in enumerate(groups)]


def trainable_tiles(self, key, action):
    key = policy_key(self,key)
    return [active_tiles(key)[-1]] if action < 4 and residual_active(key) else []


def values_for(self, key):
    key = policy_key(self,key)
    tiles = active_tiles(key)
    result = sum((self.q.get(tile, np.zeros(6)) for tile in tiles[:7]), np.zeros(6))
    if len(tiles) == 8:
        residual = self.q.get(tiles[-1],np.zeros(6))
        result[:4] += residual[:4]
    return result


def averaged_values(self, key):
    # p maps original actions to transformed actions. Index by p to align each
    # prediction back to the actual board before averaging. Keep all eight
    # group elements: identical states can still permute directional actions.
    return sum((values_for(self, transform_key(key,p))[list(p)]
                for p in PERMUTATIONS),np.zeros(6))/len(PERMUTATIONS)


def setup(self):
    self.rng = np.random.default_rng(int(os.environ.get('QL_SEED', '42')))
    self.model_path = Path(os.environ.get('QL_MODEL', str(Path(__file__).parent / 'model.json')))
    data = json.loads(self.model_path.read_text(encoding='utf-8'))
    if data['version'] != 8 or data['actions'] != list(ACTIONS) or data['blocks'] != [list(b) for b in BLOCKS]:
        raise ValueError('Incompatible linear Q checkpoint')
    self.q = {tuple(map(int, k.split(','))): np.array(v, dtype=float) for k, v in data['q'].items()}
    self.direction_mode = data['direction_mode']
    if self.direction_mode not in ('direction','blind'):
        raise ValueError('Unknown direction residual mode')
    self.frozen_base_sha256 = data['frozen_base_sha256']
    if frozen_base_digest(self.q) != self.frozen_base_sha256:
        raise ValueError('Frozen base hash does not match checkpoint')
    for tile,values in self.q.items():
        if values.shape != (6,) or not np.isfinite(values).all() or not 0 <= tile[0] <= 7:
            raise ValueError('Invalid block weights')
        if tile[0] < 7:
            values.flags.writeable = False
        elif np.any(values[4:] != 0):
            raise ValueError('Residual must not change WAIT or BOMB values')
    self.visits = {tuple(map(int, k.split(','))): np.array(v, dtype=int) for k, v in data.get('visits', {}).items()}
    self.episodes = data['episodes']
    self.prior = {}
    self.training_config = data.get('config', {})
    self.epsilon = 0.
    self.shield, self.anticipate, self.attack_features = True, False, False


def action_mask(game_state, info):
    return candidate_mask(game_state, info, allowed(info, True))


def scored_actions(self, game_state):
    info = describe(game_state)
    mask, fallback = candidate_mask_with_status(game_state, info, allowed(info, True))
    candidates = np.flatnonzero(mask)
    raw = averaged_values(self, info['key'])
    scores = raw - escape_costs(game_state, info, 0., 1.)
    best = candidates[np.isclose(scores[candidates], scores[candidates].max())]
    corrected = False
    # When the worst-case intersection is empty, preserving every static
    # candidate is necessary. Do not then let contested-tile cost alone turn
    # an otherwise preferred retreat into a unique WAIT. Keep distance cost,
    # the learned Q ranking, and the SAME safety mask. Ordinary choices and
    # any tie including a move are left exactly as before.
    if info['threatened'] and fallback and mask[:4].any() and np.array_equal(best, [4]):
        retreat_scores = raw - escape_costs(game_state, info, 0., 0.)
        retreat_best = candidates[np.isclose(retreat_scores[candidates], retreat_scores[candidates].max())]
        if np.all(retreat_best < 4):
            scores = retreat_scores
            corrected = True
    return mask, scores, corrected


def act(self, game_state):
    mask, scores, _ = scored_actions(self, game_state)
    candidates = np.flatnonzero(mask)
    if self.train and self.rng.random() < self.epsilon:
        return ACTIONS[int(self.rng.choice(candidates))]
    best = candidates[np.isclose(scores[candidates], scores[candidates].max())]
    return ACTIONS[int(self.rng.choice(best))]
