"""D4 experience augmentation, averaged before touching shared block weights."""
import numpy as np
from .callbacks import trainable_tiles, values_for
from .symmetry_maps import PERMUTATIONS, transform_key

# Each permutation maps an old action index to its transformed index.


def transform_vector(vector, permutation):
    result = np.empty_like(vector)
    result[list(permutation)] = vector
    return result


def augmented_update(agent, key, action, next_key, mask, reward, rate):
    variants = set()
    for permutation in PERMUTATIONS:
        variants.add((transform_key(key, permutation), permutation[action],
                      transform_key(next_key, permutation) if next_key is not None else None,
                      tuple(transform_vector(mask, permutation)) if next_key is not None else None))
    changes = {}
    # Compute every target and residual against the SAME pre-update weights.
    for old, index, new, candidates in sorted(variants):
        future = 0. if new is None else values_for(agent, new)[np.array(candidates, dtype=bool)].max()
        delta = reward + agent.gamma * future - values_for(agent, old)[index]
        if not np.isfinite(delta):
            raise FloatingPointError('Non-finite symmetry TD error')
        tiles = trainable_tiles(agent,old,index)
        for tile in tiles:
            changes.setdefault(tile, np.zeros(6))[index] += rate * delta / (len(tiles) * len(variants))
    for tile, change in changes.items():
        agent.q.setdefault(tile, np.zeros(6))[:] += change
    return len(variants)
