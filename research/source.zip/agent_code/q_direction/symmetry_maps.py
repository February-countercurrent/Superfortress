"""D4 transformations of the legacy state and four enemy bearings."""
PERMUTATIONS = tuple(tuple((r + sign*i) % 4 for i in range(4)) + (4,5)
                     for sign in (1,-1) for r in range(4))


def transform_key(key, permutation):
    if len(key) != 20:
        raise ValueError('Expected 20-feature direction observation')
    result=list(key)
    for old in range(4):
        result[permutation[old]]=key[old]
        result[6+permutation[old]]=key[6+old]
        result[16+permutation[old]]=key[16+old]
    return tuple(result)
