"""Truncated greedy-policy tree backup over up to three real transitions."""
import numpy as np
from .callbacks import active_tiles, values_for
from .symmetry import PERMUTATIONS, transform_key, transform_vector


def backup_target(agent, trajectory):
    result = None
    for i in range(len(trajectory)-1, -1, -1):
        key, action, reward, next_key, mask = trajectory[i]
        if next_key is None:
            result = reward
            continue
        q = values_for(agent, next_key)
        mask = np.array(mask, dtype=bool)
        value = float(q[mask].max())
        target = reward + agent.gamma * value
        if i + 1 < len(trajectory):
            following = trajectory[i+1]
            if following[0] != next_key:
                raise ValueError('Non-contiguous multi-step trajectory')
            # Exact ties define a uniform greedy target policy. A non-greedy
            # behavior action cuts later credit, without importance weights.
            greedy = mask & (q == value)
            probability = float(greedy[following[1]]) / int(greedy.sum())
            target += agent.gamma * probability * (result - q[following[1]])
        result = target
    return float(result)


def apply_backup(agent, records):
    variants = set()
    permutations = PERMUTATIONS if agent.symmetry else (PERMUTATIONS[0],)
    for p in permutations:
        variants.add(tuple((transform_key(r['key'],p), p[r['action']], r['reward'],
                           transform_key(r['next_key'],p) if r['next_key'] is not None else None,
                           tuple(transform_vector(r['mask'],p)) if r['next_key'] is not None else None)
                          for r in records))
    changes = {}
    for trajectory in sorted(variants):
        key,index = trajectory[0][:2]
        delta = backup_target(agent,trajectory) - values_for(agent,key)[index]
        if not np.isfinite(delta):
            raise FloatingPointError('Non-finite tree-backup TD error')
        tiles = active_tiles(key)
        for tile in tiles:
            changes.setdefault(tile,np.zeros(6))[index] += records[0]['rate'] * delta / (len(tiles)*len(variants))
    for tile,change in changes.items():
        agent.q.setdefault(tile,np.zeros(6))[:] += change
    agent.backup_lengths[len(records)] += 1


def enqueue(agent, record):
    agent.transition_queue.append(record)
    if record['next_key'] is None:
        while agent.transition_queue:
            apply_backup(agent,agent.transition_queue)
            agent.transition_queue.pop(0)
    elif len(agent.transition_queue) >= agent.n_step:
        apply_backup(agent,agent.transition_queue)
        agent.transition_queue.pop(0)
