# Narrow attack-reward candidate

Research candidate only; adoption status is in candidate.json.
The 28-feature inference source is byte-identical to tree_guard. Only
training shaping differs for single, escapable, short-route pure attacks.
The validated experiment is experiments/tree_attack_reward_v1.
This does not replace the submitted Superfortress agent.
AI-assisted implementation; student review and understanding required.
