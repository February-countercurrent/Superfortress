"""Training-only wrapper: coin collector on mixed rounds, rule policy on strong rounds."""
from agent_code.coin_collector_agent import callbacks as weak
from training_opponent_pool import setup_pool, act_pool


def setup(self):
    setup_pool(self, weak)


def act(self, game_state):
    return act_pool(self, game_state)
