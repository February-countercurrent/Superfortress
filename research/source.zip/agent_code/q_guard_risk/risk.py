"""Public-state occupancy certificates as small, learnable action features."""
from collections import Counter, OrderedDict
import hashlib
import json
from math import fsum
import os
import time

import numpy as np

from . import base
from .features import describe
from .occupancy import filter_actions
from .symmetry_maps import PERMUTATIONS, transform_key


def frozen_digest(q):
    data = {','.join(map(str,k)): v.tolist() for k,v in q.items()}
    return hashlib.sha256(json.dumps(data, sort_keys=True, separators=(',',':')).encode()).hexdigest()


def setup_risk(agent):
    data = json.loads(agent.model_path.read_text(encoding='utf-8'))
    saved = data.get('risk_residual')
    agent.risk_mode = saved['mode'] if saved else os.environ.get('QL_RISK_MODE', 'risk')
    if agent.risk_mode not in ('risk', 'blind'):
        raise ValueError('Invalid risk feature mode')
    agent.risk_bound = .5
    agent.risk_weights = np.array(saved['weights'] if saved else np.zeros((2,2)), dtype=float)
    if (agent.risk_weights.shape != (2,2) or not np.isfinite(agent.risk_weights).all()
            or np.abs(agent.risk_weights).max() > agent.risk_bound):
        raise ValueError('Invalid residual coefficients')
    agent.frozen_base_sha256 = frozen_digest(agent.q)
    if saved and (saved['frozen_base_sha256'] != agent.frozen_base_sha256
                  or saved['bound'] != .5 or saved['version'] != 1):
        raise ValueError('Frozen model or residual definition mismatch')
    for key, values in agent.q.items():
        if key[0] >= 7:
            raise ValueError('Only the seven legacy blocks may exist')
        values.flags.writeable = False
    agent.risk_cache = OrderedDict()
    agent.risk_q_cache = OrderedDict()
    agent.risk_metrics = Counter()
    agent.risk_update_counts = Counter()


def observation_id(state):
    # The engine may label an after-action state with the old step number.
    # Include its full public contents, never just round/step or object identity.
    return (state['round'], state['step'], state['field'].shape,
            state['field'].tobytes(), state['explosion_map'].tobytes(),
            tuple((tuple(p),int(t)) for p,t in state['bombs']),
            tuple(map(tuple,state['coins'])),
            (*state['self'][:3], tuple(state['self'][3])),
            tuple((*a[:3],tuple(a[3])) for a in state['others']))


def encode_flags(mode, original, refined, reason):
    if reason != 'filtered':
        return (0,)*5
    return tuple(0 if not original[a] else 1 if mode == 'blind' or refined[a] else 2
                 for a in range(5))


def frame(agent, state):
    identity = observation_id(state)
    if identity in agent.risk_cache:
        agent.risk_metrics['cache_hits'] += 1
        agent.risk_cache.move_to_end(identity)
        return agent.risk_cache[identity]
    # Only frozen base predictions are cached; learned residuals are read fresh.
    info = describe(state)
    mask, scores, urgent = base.scored_actions(agent, state)
    flags = (0,)*5
    details = dict(reason='outside_escape_gate', eligible=False)
    if info['threatened'] and not state['self'][2] and not urgent:
        refined, details = filter_actions(state, info, mask, deadline=time.perf_counter()+.2)
        flags = encode_flags(agent.risk_mode, mask, refined, details['reason'])
        agent.risk_metrics['searches'] += 1
        agent.risk_metrics[details['reason']] += 1
        if details.get('search'):
            agent.risk_metrics['search_nodes'] += details['search']['nodes']
    elif urgent:
        details['reason'] = 'preserve_urgent_correction'
    info = {**info, 'key': tuple(info['key']) + flags}
    assert len(info['key']) == 21
    value = info, mask, scores, urgent, details
    agent.risk_cache[identity] = value
    if len(agent.risk_cache) > 64:
        agent.risk_cache.popitem(last=False)
    return value


def parameter_for(key, action):
    if len(key) != 21:
        raise ValueError('Expected legacy16 plus five action risk codes')
    if action == 5 or key[16+action] == 0:
        return None
    if key[16+action] not in (1,2):
        raise ValueError('Invalid risk code')
    return int(action == 4), key[16+action]-1


def residual_values(agent, key):
    result = np.zeros(6)
    for action in range(5):
        parameter = parameter_for(key, action)
        if parameter is not None:
            result[action] = agent.risk_weights[parameter]
    return result


def learning_values(agent, key):
    if len(key) != 21:
        raise ValueError('Expected21 features')
    old_key = tuple(key[:16])
    if old_key not in agent.risk_q_cache:
        predictions = [base.values_for(agent, transform_key(old_key, p))[list(p)] for p in PERMUTATIONS]
        value = np.array([fsum(q[a] for q in predictions)/8 for a in range(6)])
        agent.risk_q_cache[old_key] = value
        if len(agent.risk_q_cache) > 8192:
            agent.risk_q_cache.popitem(last=False)
    value = agent.risk_q_cache[old_key]
    return value + residual_values(agent, key)


def transform_risk_key(key, permutation):
    result = list(transform_key(key[:16], permutation)) + list(key[16:])
    for old in range(4):
        result[16+permutation[old]] = key[16+old]
    return tuple(result)
