"""Semi-gradient TD for four bounded coefficients, with frozen old Q."""
import numpy as np
from .risk import learning_values, parameter_for


def averaged_step(agent, key, action, delta, rate):
    if not np.isfinite(delta):
        raise FloatingPointError('Non-finite residual TD error')
    parameter = parameter_for(key, action)
    if parameter is None:
        agent.risk_update_counts['inactive_updates'] += 1
        return
    agent.risk_update_counts['active_updates'] += 1
    agent.risk_update_counts[str(parameter)] += 1
    before = float(agent.risk_weights[parameter])
    proposed = before + rate * delta / 7
    agent.risk_weights[parameter] = np.clip(proposed, -agent.risk_bound, agent.risk_bound)
    agent.risk_update_counts['projected_updates'] += int(abs(proposed) > agent.risk_bound)
