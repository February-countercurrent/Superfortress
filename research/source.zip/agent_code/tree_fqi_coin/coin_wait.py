"""Break repeated calm waiting beside a visible, shield-approved coin."""
import numpy as np
from .features import DELTAS


class CoinWaitGuard:
    def __init__(self):
        self.previous = None
        self.current = None
        self.waits = 0
        self.eligible = False

    def options(self, state, info, mask, values):
        position = tuple(state['self'][3])
        visible = set(map(tuple, state['coins']))
        adjacent = tuple(sorted(p for p in visible if abs(p[0]-position[0])+abs(p[1]-position[1]) == 1))
        current = (state['round'], state['step'], position, state['self'][1], adjacent)
        previous = self.previous
        continuous = (previous is not None and current[0] == previous[0]
            and current[1] == previous[1]+1 and current[2:] == previous[2:])
        if not continuous:
            self.waits = 0
        self.current = current
        moves = [i for i,(dx,dy) in enumerate(DELTAS)
                 if mask[i] and (position[0]+dx,position[1]+dy) in visible]
        self.eligible = bool(not info['threatened'] and info['target'] == 1
                             and info['distance'] == 1 and moves)
        candidates = np.flatnonzero(mask)
        best = candidates[np.isclose(values[candidates], values[candidates].max())]
        if self.eligible and self.waits >= 2 and np.array_equal(best, [4]):
            moves = np.asarray(moves)
            return moves[np.isclose(values[moves], values[moves].max())].tolist()
        return []

    def remember(self, action):
        if self.current is None:
            raise ValueError('Observe before remembering an action')
        self.waits = self.waits+1 if self.eligible and action == 4 else 0
        self.previous, self.current = self.current, None
