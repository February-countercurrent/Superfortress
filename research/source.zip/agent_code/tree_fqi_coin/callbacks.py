"""Frozen tree Q with a narrowly tested repeated-WAIT coin guard."""
import json
import os
from pathlib import Path
import numpy as np

from .features import ACTIONS, allowed, describe
from .dynamic import candidate_mask
from .model import load_model
from .coin_wait import CoinWaitGuard


def encode(state):
    info = describe(state)
    mask = candidate_mask(state, info, allowed(info, True))
    if not mask.any():
        raise ValueError('Candidate mask must be nonempty')
    return np.asarray(info['key'], dtype=np.int8), mask, info


def setup(self):
    if self.train:
        raise ValueError('This frozen-policy experiment is inference-only')
    self.model_path = Path(os.environ.get('FQI_MODEL', str(Path(__file__).parent/'model.pkl')))
    self.predictor, self.metadata = load_model(self.model_path)
    self.seed = int(os.environ.get('FQI_SEED', '42'))
    self.policy_round = None
    self.coin_guard_enabled = os.environ.get('FQI_COIN_GUARD', '1') == '1'
    trace = os.environ.get('FQI_POLICY_TRACE')
    self.policy_trace = Path(trace).open('x', encoding='utf-8') if trace else None


def act(self, game_state):
    if self.policy_round != game_state['round']:
        self.policy_round = game_state['round']
        self.rng = np.random.default_rng(np.random.SeedSequence([self.seed, self.policy_round, 101]))
        self.guard_rng = np.random.default_rng(np.random.SeedSequence([self.seed, self.policy_round, 105]))
        self.coin_guard = CoinWaitGuard()
    key, mask, info = encode(game_state)
    values = self.predictor.values(tuple(key))
    candidates = np.flatnonzero(mask)
    best = candidates[np.isclose(values[candidates], values[candidates].max())]
    baseline = int(self.rng.choice(best))
    options = self.coin_guard.options(game_state, info, mask, values)
    selected = int(self.guard_rng.choice(options)) if options and self.coin_guard_enabled else baseline
    assert mask[selected]
    if selected != baseline:
        assert baseline == 4 and selected < 4 and not info['threatened']
    if self.policy_trace:
        record = dict(round=game_state['round'], step=game_state['step'],
            position=list(game_state['self'][3]), score=game_state['self'][1],
            baseline=baseline, selected=selected, options=options,
            changed=selected != baseline, prior_waits=self.coin_guard.waits,
            eligible=self.coin_guard.eligible, threatened=bool(info['threatened']),
            coins=[list(p) for p in game_state['coins']], mask=mask.tolist(), q=values.tolist())
        self.policy_trace.write(json.dumps(record, default=int)+'\n')
        self.policy_trace.flush()
    self.coin_guard.remember(selected)
    return ACTIONS[selected]
