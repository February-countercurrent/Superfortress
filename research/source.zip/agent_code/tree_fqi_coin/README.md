# Tree FQI coin-WAIT guard — not adopted

Research-only inference variant. It uses the original pilot tree weights without
retraining. A public-observation history rule breaks the third consecutive calm
WAIT beside the same visible coin when the original dynamic mask permits taking
it and WAIT is still uniquely preferred by the tree.

The rule fixed a verified 27-step wait, but on 120 fresh paired games it won
43 games versus the pilot's 44, with 7 suicides versus 6. It did not meet the
predeclared upgrade criteria. The default `tree_fqi` and the submitted
`Superfortress` are unchanged. Do not treat this folder as the adopted model.

`FQI_COIN_GUARD=0` disables the rule for equivalence checks. Model loading and
policy seed use the research agent's `FQI_MODEL` / `FQI_SEED` settings.
`FQI_POLICY_TRACE` optionally records decision details to a new file.
Dependencies match the original tree agent (NumPy and scikit-learn).

Protocol and evidence: `TREE_FQI_COIN_PLAN.md`, `TREE_FQI_COIN_RESULTS.md`,
`experiment_tree_fqi_coin.py`, `experiments/tree_fqi_coin_v1`.
This is a deployment rule around learned Q values, not an additional learned model.
