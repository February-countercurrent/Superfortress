"""Write the final, reviewed result without modifying any submitted bytes."""
from datetime import datetime, timezone
import shutil
from finalize_guard_release import ROOT, OUT, RELEASE, SCENES, read, save, digest


def main():
    v=read(OUT/'review_verification.json')
    assert v['verified'] and v['recommended']=='adopted'
    timing=read(OUT/'holdout_timing.json')['adopted']
    max_ms=max(r['latency']['max_ms'] for r in timing)
    screen=v['counts']['screen']; final=v['counts']['holdout']['adopted']; total=final['combined']
    lines=['# 截止前最终筛选与提交包验证', '',
        '保留已经采用的q_guard、1150局权重。没有新增训练，也没有新增策略规则。',
        '两个1250局候选没有在同图筛选中超过采用版，本轮未找到提高胜率的证据。', '',
        '## 权重筛选（开发数据）', '',
        '| 版本 | 混合胜场 | 三规则对手胜场 | 总胜率 | 平均得分 | 自杀 |',
        '|---|---:|---:|---:|---:|---:|']
    labels={'adopted':'采用1150','aligned_a':'对称学习1250 A','aligned_b':'对称学习1250 B'}
    for arm,labels_ in labels.items():
        m=screen[arm]['combined']
        lines.append(f"| {labels_} | {screen[arm]['mixed']['wins']}/30 | {screen[arm]['strong']['wins']}/30 | {m['wins']}/60 = {m['wins']/60:.1%} | {m['score']/60:.3f} | {m['suicides']} |")
    lines += ['', '固定模型、相同策略、种子42。地图/对手种子327002、327003；共180局。',
        '三者同为29胜，原采用版得分最高。按预先固定的规则不进入候选替换复核。', '',
        '## 实际提交包的独立测试', '',
        '选择保留采用版后，另用地图/对手种子337002、337003，各60局。',
        '这120局没有用于选择模型或调整参数。和筛选数据分开报告。', '',
        '| 对手配置 | 严格胜率 | 平均得分 | 存活 | 自杀 |',
        '|---|---:|---:|---:|---:|']
    for scene,label in [('mixed','混合'),('strong','三个规则对手'),('combined','合计')]:
        m=final[scene]; n=m['rounds']
        lines.append(f"| {label} | {m['wins']}/{n} = {m['wins']/n:.1%} | {m['score']/n:.3f} | {m['survived']}/{n} | {m['suicides']}/{n} |")
    low,high=v['descriptive_wilson95']
    lines += ['', f'合计胜率的描述性Wilson95%区间约为[{low:.1%}, {high:.1%}]。',
        '严格获胜指独占最高分，平局不算胜。两种对手配置各占一半；这不是对',
        '其他同学模型的胜率保证。得分按金币1分、击杀5分核验，游戏原始记录保留。',
        '历史97/180=53.9%采用了不同地图及随批次变化的策略种子，不能与本批',
        '点估计直接相减并称为策略提升或退步；历史单批64.2%也不是稳定水平。', '',
        '## 可提交文件及检查', '',
        '`release/guard_v2/final-project-agent-code.zip`，仅包含q_guard代理目录。',
        '保留分块Q、D4、动态逃生、紧急撤离和资源门控E；固定本地模型与默认种子42。',
        '历史代码、权重、采用清单和旧final_v1包均保持原样；CURRENT_SUBMISSION.json指向新包。',
        '全部300局评估的胜负、得分、地图配对、模型/代码/包哈希已重新核验。',
        '另有2253次决策的默认及冲突环境等价、8局成对全动作等价、原版框架6局短运行检查。',
        f'最终120局中观察到的单次最大决策耗时{max_ms:.2f}ms，超过500ms为0。',
        '测试环境Python3.10.9、NumPy1.23.5、pygame2.5.0。使用原版Git框架快照；没有运行Docker。',
        '耗时是本机实测，不是所有状态/机器的上界。没有自动上传。', '',
        f"ZIP SHA256：`{v['archive_sha256']}`。", '',
        '协议：FINAL_CHECKPOINT_NOTES.md；原始数据：experiments/final_checkpoint_v1；',
        '复现说明和逐局参考结果：release/guard_v2/reproduction。']
    report='\n'.join(lines)+'\n'
    (ROOT/'FINAL_CHECKPOINT_RESULTS.md').write_text(report,encoding='utf-8')
    (RELEASE/'EVALUATION.md').write_text(report,encoding='utf-8')
    for scene in SCENES:
        shutil.copy2(OUT/'holdout/adopted'/(scene+'.rounds.jsonl'),
                     RELEASE/'reproduction'/('expected_holdout_'+scene+'.rounds.jsonl'))
    for name in ('config.json','selection.json','decision.json','screen_results.json',
                 'holdout_results.json','review_verification.json'):
        shutil.copy2(OUT/name,RELEASE/'verification'/name)
    for name in ('finalize_guard_release.py','verify_guard_release.py','evaluate_final_checkpoints.py',
                 'review_final_checkpoints.py','document_guard_release.py','FINAL_CHECKPOINT_NOTES.md'):
        shutil.copy2(ROOT/name,RELEASE/'reproduction'/name)
    pointer=read(ROOT/'CURRENT_SUBMISSION.json')
    pointer.update(evaluation_complete=True,strict_wins=total['wins'],evaluation_games=120,
                   strict_win_rate=total['wins']/120,mean_score=total['score']/120,
                   evaluation_scope='Equal-weight mixed and three-rule opponents; independent maps; fixed policy seed42',
                   updated_at=datetime.now(timezone.utc).isoformat())
    save(ROOT/'CURRENT_SUBMISSION.json',pointer)
    assert digest(RELEASE/'final-project-agent-code.zip')==v['archive_sha256']
    notes=ROOT/'PROJECT_NOTES.md'
    heading='# Bomberman Q-learning project\n'
    old=notes.read_text(encoding='utf-8')
    assert old.startswith(heading)
    status=f'''\n## 当前：新提交包guard_v2已验证，最后权重筛选无提升，保留q_guard1150

截止前三小时完成三个固定权重的同图180局筛选：采用1150、对称学习1250 A/B均29/60=48.3%，总得分398/395/390；按预定规则保留采用版。另120张未用于筛选的新地图，实际固定种子42的提交包{total['wins']}/120={total['wins']/120:.1%}、均分{total['score']/120:.3f}。详见FINAL_CHECKPOINT_RESULTS.md。不能将不同地图/策略种子的历史53.9%与本批直接解释为提升或退步。

正式可用包为release/guard_v2/final-project-agent-code.zip，SHA256 {v['archive_sha256']}。CURRENT_SUBMISSION.json记录包位置和成绩；CURRENT_CANDIDATE.json是仍受历史实验保护的采用清单，其中submission_zip_replaced=false表示旧final_v1文件未被覆盖，不表示没有新包。旧包仍保留，请上传guard_v2内的同名ZIP。

新包保持1150原权重，16维/7块/D4/动态逃生/紧急撤离/资源门控E，仅固定默认种子42、本地模型和关闭实验追踪。2253次决策等价、8局实际成对全动作等价、原框架6局检查、300局正式评估和原始指标/哈希复核完成。没有训练、没有新增策略、没有自动上传；实验complete、needs_review=false。以下为历史记录，当前提交位置以本段为准。
'''
    notes.write_text(heading+status+old[len(heading):],encoding='utf-8')
    print(report)


if __name__=='__main__':
    main()
