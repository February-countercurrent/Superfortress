"""Describe extra feature support on the unchanged training/diagnostic split."""
from pathlib import Path
import numpy as np
from fit_tree_fqi import read_data
from experiment_tree_fqi_batches import save
from finalize_guard_release import digest

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'experiments/tree_timed_v1'


def main():
    d=read_data(OUT/'data');result={}
    for name,mask in [('training',d['round']%5!=0),('diagnostic',d['round']%5==0)]:
        x=d['timed_x'][mask];actions=d['a'][mask]
        result[name]=dict(transitions=len(x),unique_original_keys=len(np.unique(x[:,:28],axis=0)),
            unique_extended_keys=len(np.unique(x,axis=0)),
            current_attack_categories=np.bincount(x[:,28],minlength=6).tolist(),
            bomb_current_attack_categories=np.bincount(x[actions==5,28],minlength=6).tolist(),
            escape_distance_categories=np.bincount(x[:,33],minlength=6).tolist())
    save(OUT/'feature_support.json',dict(verified=True,splits=result,script_sha256=digest(Path(__file__)),
        note='Category counts and distinct observations do not establish policy quality or sample sufficiency.'))
    print(result)


if __name__=='__main__':main()
