"""Offline one-transient-collision stress test for a prospective own bomb.

Opponent reachability overestimates destinations by ignoring other players.
The own nominal schedule keeps observed opponents fixed, like the existing
forecast. One attempted move into a potentially contested tile may fail and
consume one tick; later moves adapt. This is NOT a full adversarial-game proof,
does not model persistent blocking or newly placed opponent bombs, and is not
used by any deployed agent.
"""
import numpy as np
import settings

from agent_code.q_urgent.features import DELTAS
from agent_code.q_tactical.tactics import timeline


def neighbor_values(array, dx, dy):
    result = np.zeros_like(array)
    if dx == 1:
        result[:-1, :] = array[1:, :]
    elif dx == -1:
        result[1:, :] = array[:-1, :]
    elif dy == 1:
        result[:, :-1] = array[:, 1:]
    elif dy == -1:
        result[:, 1:] = array[:, :-1]
    return result


def evaluate(state, plant=True):
    horizon = max([settings.BOMB_TIMER + settings.EXPLOSION_TIMER if plant else 1, int(state['explosion_map'].max())]
                  + [timer + settings.EXPLOSION_TIMER for _, timer in state['bombs']])
    opens, occupied, danger = timeline(state, plant, horizon)
    # Opponent arrival before the tick's explosion can obstruct our move even
    # if that opponent then dies; only survivors propagate to the next tick.
    reach = np.zeros_like(opens, dtype=bool)
    blockers = np.zeros_like(reach)
    for other in state['others']:
        reach[tuple(other[3])] = True
        blockers[tuple(other[3])] = True
    contested = np.zeros_like(danger)
    for tick in range(1, horizon + 1):
        moved = np.zeros_like(reach)
        for dx, dy in DELTAS:
            moved |= neighbor_values(reach, dx, dy)
        arrival = (reach | (moved & (occupied < tick))) & (opens <= tick)
        contested[tick] = arrival
        reach = arrival & ~danger[tick]
    standing = np.array([(opens <= t) & ~danger[t] & ~blockers for t in range(horizon + 1)])
    used = standing[horizon].copy()
    unused = used.copy()
    for tick in range(horizon - 1, 0, -1):
        enter = occupied < tick + 1
        # WAIT never invokes the failed-movement branch.
        next_used = used.copy()
        next_unused = unused.copy()
        for dx, dy in DELTAS:
            success_used = neighbor_values(used & enter, dx, dy)
            success_unused = neighbor_values(unused & enter, dx, dy)
            may_be_contested = neighbor_values(contested[tick + 1], dx, dy)
            next_used |= success_used
            next_unused |= success_unused & (~may_be_contested | used)
        used = next_used & standing[tick]
        unused = next_unused & standing[tick]
    p = tuple(state['self'][3])
    if plant:
        return dict(nominal_survival=bool(used[p]), tolerates_one_contested_delay=bool(unused[p]),
                    horizon=horizon)
    nominal = []
    robust = []
    for dx, dy in (*DELTAS, (0, 0)):
        q = p[0] + dx, p[1] + dy
        movable = (dx, dy) == (0, 0) or occupied[q] < 1
        nominal.append(bool(movable and used[q]))
        robust.append(bool(movable and unused[q] and
                           ((dx, dy) == (0, 0) or not contested[1][q] or used[p])))
    return dict(nominal_actions=nominal, delay_tolerant_actions=robust, horizon=horizon)
