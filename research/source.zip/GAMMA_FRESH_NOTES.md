# 冻结gamma候选的新地图复核

已启动，尚无结果。脚本evaluate_gamma_fresh.py；输出experiments/gamma_fresh_v1。

- 冻结gamma_v1的gamma_07/model.json和gamma_09/model.json，各累计3600训练局。不训练、不修改奖励、特征或成本，不更新任何Q值。
- 新种子105001、105002、105003，每个种子两模型各100局，总600局。每局三个官方规则对手。两个进程使用独立源码与日志副本。
- 全部按预定局数完成，不根据途中成绩提前停止或调参。主要指标平均得分、独赢率；辅助指标存活、自杀、击杀。
- 结果与之前验证/测试分开报告。检查每一对地图hash一致，评估前后权重hash一致。
- 完成后自动写根目录results.json、analysis.json及status.json。analysis包含每模型300局汇总及按种子分层的配对bootstrap 95%区间。
- 这里只检验这两个固定权重对新地图的表现；即使某一模型更好，也不能据此证明不同训练种子下gamma0.9普遍更好。不会自动替换部署权重。

查看进度：gamma_07/status.json、gamma_09/status.json记录当前种子及已完成组数；seed_105001.rounds.jsonl等文件的最后一行round为当前组已完成局数。每完成100局会更新各组results.json。

环境变量QF_GAMMA只在训练中影响更新；本次不训练，所比较的是此前不同gamma学到的权重。其余决策参数完全相同，保留完整放弹与抢位成本，禁用新增攻击特征。
