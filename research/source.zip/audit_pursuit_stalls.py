"""Audit opportunity coverage, not counterfactual wins, on all archived games."""
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace

import numpy as np

from analyze_urgent_scoring import category, round_frames, state_arrays
from diagnose_symavg_survival import stable_rows
from agent_code.q_urgent import callbacks
from pursuit_stall import PursuitLedger, eligible, resource_options

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'experiments/urgent_scoring_v1'
OUT = ROOT / 'experiments/pursuit_stall_audit_v1'
THRESHOLDS = (1, 2, 3)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def dump(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False), encoding='utf-8')


def main():
    manifest = json.loads((ROOT / 'CURRENT_CANDIDATE.json').read_text())
    assert manifest['agent'] == 'q_urgent' and manifest['episodes'] == 1150
    previous_verification = json.loads((SOURCE / 'verification.json').read_text())
    inputs = ['CURRENT_CANDIDATE.json', manifest['model'], 'release/final_v1/final-project-agent-code.zip',
              'PURSUIT_STALL_NOTES.md', 'pursuit_stall.py', 'audit_pursuit_stalls.py',
              'test_pursuit_stall.py', 'analyze_urgent_scoring.py', 'diagnose_symavg_survival.py',
              'settings.py', 'environment.py', 'items.py',
              'experiments/urgent_scoring_v1/verification.json',
              'experiments/urgent_scoring_v1/model.json'] + list(manifest['code_sha256'])
    for scene in ('mixed', 'strong'):
        for name in ('score_frames.jsonl.gz', 'match.rounds.jsonl', 'manifest.json'):
            path = SOURCE / scene / name
            inputs.append(str(path.relative_to(ROOT)))
            key = str(path.relative_to(SOURCE))
            if name != 'manifest.json':
                assert digest(path) == previous_verification['output_sha256'][key]
        assert stable_rows(SOURCE / scene / 'match.rounds.jsonl') == stable_rows(
            ROOT / f'experiments/urgent_escape_v1/urgent_{scene}.rounds.jsonl')
    assert digest(ROOT / manifest['model']) == digest(SOURCE / 'model.json') == manifest['model_sha256']
    assert all(digest(ROOT / p) == h for p, h in manifest['code_sha256'].items())
    locked = {p: digest(ROOT / p) for p in inputs}
    OUT.mkdir(parents=True, exist_ok=False)
    dump(OUT / 'config.json', dict(created=datetime.now(timezone.utc).isoformat(),
         source=str(SOURCE.relative_to(ROOT)), primary_threshold=2, sensitivity_thresholds=[1, 3],
         training=False, new_games=0, policy_changed=False, input_sha256=locked,
         detector_inputs='Public pre-action observations and previous own chosen actions only',
         events_use='Verification only; outcomes used only after detector results to stratify summaries'))
    data = json.loads((SOURCE / 'model.json').read_text())
    policy = SimpleNamespace(q={tuple(map(int, k.split(','))): np.array(v) for k, v in data['q'].items()})
    rounds = []
    totals = Counter()
    group_totals = defaultdict(Counter)
    sensitivity = {str(t): defaultdict(Counter) for t in THRESHOLDS}
    checked = 0
    opportunities = (OUT / 'opportunities.jsonl').open('w', encoding='utf-8')
    cycles = (OUT / 'cycles.jsonl').open('w', encoding='utf-8')
    try:
        for scene in ('mixed', 'strong'):
            rows = {row['round']: row for row in stable_rows(SOURCE / scene / 'match.rounds.jsonl')}
            assert len(rows) == 60
            for number, frames in round_frames(SOURCE / scene / 'score_frames.jsonl.gz'):
                row = rows[number]
                group = category(row)
                ledger = PursuitLedger()
                counts = {t: Counter() for t in THRESHOLDS}
                last = {t: dict(gate=False, opportunity=False, intervention=False) for t in THRESHOLDS}
                prev = None
                observed_event_bombs = 0
                late_score = 0
                for f in frames:
                    state = state_arrays(f)
                    before_confirmed = ledger.counters['confirmed_bombs']
                    history = ledger.observe(state)
                    if prev is not None:
                        expected_gain = prev['events'].count('COIN_COLLECTED') + 5 * prev['events'].count('KILLED_OPPONENT')
                        assert state['self'][1] - prev['state']['self'][1] == expected_gain
                        planted = int('BOMB_DROPPED' in prev['events'])
                        assert ledger.counters['confirmed_bombs'] - before_confirmed == planted
                        observed_event_bombs += planted
                    if history['completed']:
                        cycle = history['completed']
                        start = frames[cycle['placed'] - 1]
                        assert 'BOMB_DROPPED' in start['events']
                        detonations = [x['step'] for x in frames[cycle['placed'] - 1:f['step'] - 1]
                                       if 'BOMB_EXPLODED' in x['events']]
                        assert cycle['placed'] + 4 in detonations
                        assert cycle['observed_complete'] >= cycle['placed'] + 7
                        cycles.write(json.dumps(dict(scene=scene, round=number, category=group, **cycle)) + '\n')
                    gate1 = eligible(history, f['info'], 1)
                    options = resource_options(state, f['candidate_mask']) if gate1 else None
                    if f['step'] > 200:
                        late_score += f['events'].count('COIN_COLLECTED') + 5 * f['events'].count('KILLED_OPPONENT')
                    # Every eligible observation and regular snapshots verify the actual deployed policy.
                    if gate1 or (f['step'] - 1) % 100 == 0 or f.get('urgent_escape_corrected'):
                        mask, scores, corrected = callbacks.scored_actions(policy, state)
                        np.testing.assert_array_equal(mask, f['candidate_mask'])
                        np.testing.assert_allclose(scores, f['adjusted_q'], rtol=0, atol=1e-12)
                        assert corrected == f.get('urgent_escape_corrected', False)
                        checked += 1
                    for threshold in THRESHOLDS:
                        c = counts[threshold]
                        c['frames'] += 1
                        stalled = history['streak'] >= threshold
                        gate = eligible(history, f['info'], threshold)
                        c['stalled_frames'] += int(stalled)
                        c['gate_frames'] += int(gate)
                        c['late_gate_frames'] += int(gate and f['step'] > 200)
                        opportunity = bool(gate and options['actions'])
                        intervention = bool(opportunity and f['chosen'] not in options['actions'])
                        for name, value in (('gate', gate), ('opportunity', opportunity), ('intervention', intervention)):
                            if value and not last[threshold][name]:
                                c[name + '_segments'] += 1
                            last[threshold][name] = value
                        if gate:
                            c['resource_exhausted_frames'] += int(not options['visible_coins'] and not options['crates'])
                            c['any_resources_frames'] += int(bool(options['visible_coins'] or options['crates']))
                            c['coin_reachable_frames'] += int(options['coin']['reachable'])
                            c['crate_reachable_frames'] += int(options['crate']['reachable'])
                            c['coin_action_frames'] += int(bool(options['coin']['actions']))
                            c['crate_action_frames'] += int(bool(options['crate']['actions']))
                            c['resources_but_no_action_frames'] += int(bool(options['visible_coins'] or options['crates']) and not opportunity)
                            if not opportunity and (options['coin']['reachable'] or options['crate']['reachable']):
                                c['reachable_but_no_action_frames'] += 1
                        if opportunity:
                            c['opportunity_frames'] += 1
                            c['already_resource_action_frames'] += int(not intervention)
                            c['preferred_' + options['preferred'] + '_frames'] += 1
                        if intervention:
                            c['intervention_frames'] += 1
                            c['late_intervention_frames'] += int(f['step'] > 200)
                            c['intervention_from_' + f['chosen']] += 1
                            c['intervention_to_' + options['preferred']] += 1
                    if gate1:
                        opportunities.write(json.dumps(dict(scene=scene, round=number, step=f['step'], category=group,
                            own_score=state['self'][1], position=list(state['self'][3]), history=history,
                            options=options, chosen=f['chosen'], target=f['info']['target'], threatened=f['info']['threatened'],
                            candidate_mask=f['candidate_mask'], adjusted_q=f['adjusted_q'],
                            primary_gate=eligible(history, f['info'], 2),
                            primary_intervention=bool(eligible(history, f['info'], 2) and options['actions']
                                                      and f['chosen'] not in options['actions']))) + '\n')
                    ledger.remember_action(state, f['chosen'])
                    prev = f
                assert ledger.counters['confirmed_bombs'] == observed_event_bombs
                assert observed_event_bombs + int('BOMB_DROPPED' in frames[-1]['events']) == row['agents']['q_urgent'].get('bombs', 0)
                # Censored records may include a final just-chosen bomb not observed yet.
                counters = dict(ledger.counters)
                counters['pending_censored'] = int(ledger.pending is not None)
                counters['last_action_unobserved'] = int(ledger.proposal is not None)
                totals.update(counters)
                group_totals[group].update(counters)
                record = dict(scene=scene, round=number, category=group, win=row['win'], score=row['score'],
                              survived=row['survived'], steps=row['steps'], observed_frames=len(frames),
                              no_score_after_200=frames[-1]['step'] > 200 and late_score == 0,
                              counters=counters, thresholds={str(t): dict(c) for t, c in counts.items()})
                rounds.append(record)
                for threshold, c in counts.items():
                    for target in ('all', group, 'scene_' + scene):
                        dest = sensitivity[str(threshold)][target]
                        dest.update(c)
                        dest['rounds'] += 1
                        for metric in ('gate', 'opportunity', 'intervention'):
                            dest[metric + '_rounds'] += int(c[metric + '_frames'] > 0)
                        dest['late_intervention_rounds'] += int(c['late_intervention_frames'] > 0)
                        if record['no_score_after_200']:
                            dest['no_score_after_200_rounds'] += 1
                            dest['no_score_after_200_intervention_rounds'] += int(c['intervention_frames'] > 0)
                            dest['no_score_after_200_late_intervention_rounds'] += int(c['late_intervention_frames'] > 0)
                if len(rounds) % 20 == 0:
                    dump(OUT / 'status.json', dict(phase='analyzing', rounds_completed=len(rounds), total_rounds=120))
                    print(f'{len(rounds)}/120 games audited', flush=True)
        assert len(rounds) == 120
    finally:
        opportunities.close()
        cycles.close()
    assert all(digest(ROOT / p) == h for p, h in locked.items()), 'A locked input changed'
    assert sum(r['observed_frames'] for r in rounds) == 41992
    assert sum(r['win'] for r in rounds) == 67
    assert sum(r['category'] == 'alive_loss' and r['no_score_after_200'] for r in rounds) == 27
    result = dict(rounds=120, frames=sum(r['observed_frames'] for r in rounds), new_games=0, training_rounds=0,
                  primary_threshold=2, categories=dict(Counter(r['category'] for r in rounds)),
                  cycle_totals=dict(totals), cycle_groups={k: dict(v) for k, v in group_totals.items()},
                  thresholds={t: {k: dict(v) for k, v in groups.items()} for t, groups in sensitivity.items()},
                  policy_frames_verified=checked,
                  limitations=['Descriptive archived trajectories; changing one action changes subsequent observations.',
                      'Public observation only, conservative global-progress reset; no unobserved opponent intent.',
                      'Per-step and segment counts are correlated; resource approaches are not guaranteed gains.',
                      'Outcome labels are used after detection, never for triggering. No new win-rate estimate.',
                      'This tests repeated ray-bomb cycles with alternatives, not all strategic mistakes.'])
    dump(OUT / 'rounds.json', rounds)
    dump(OUT / 'analysis.json', result)
    dump(OUT / 'verification.json', dict(verified=True, checked_own_bomb_confirmation=totals['confirmed_bombs'],
         policy_frames_verified=checked, contiguous_steps=True, own_score_transitions_checked=True,
         completed_bomb_timing_checked=True, locked_inputs_unchanged=True,
         output_sha256={p.name: digest(p) for p in OUT.iterdir() if p.suffix in ('.json', '.jsonl')
                        and p.name not in ('status.json', 'verification.json')}))
    dump(OUT / 'status.json', dict(phase='complete', rounds_completed=120, total_rounds=120, needs_review=True))
    print(json.dumps(dict(categories=result['categories'], primary=result['thresholds']['2'],
                         policy_frames_verified=checked), indent=2))


if __name__ == '__main__':
    main()
