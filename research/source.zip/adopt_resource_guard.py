"""Verify the self-contained E deployment, then record explicit user adoption."""
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
from types import SimpleNamespace
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'experiments/resource_guard_adoption_v1'
SOURCE = ROOT / 'experiments/resource_guard_v1'


def read(p):
    return json.loads(p.read_text(encoding='utf-8'))


def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def save(p, data):
    temp = p.with_suffix('.tmp')
    temp.write_text(json.dumps(data, indent=2), encoding='utf-8')
    temp.replace(p)


def normalized(p, agent):
    rows = [json.loads(line) for line in p.read_text().splitlines()]
    for row in rows:
        row['agents']['subject'] = row['agents'].pop(agent)
        row.pop('subject_max_action_ms')
        for stats in row['agents'].values():
            stats.pop('time', None)
    return rows


def main():
    old = read(ROOT / 'CURRENT_CANDIDATE.json')
    assert old['agent'] == 'q_urgent' and old['episodes'] == 1150
    old_hash = digest(ROOT / 'CURRENT_CANDIDATE.json')
    assert old_hash == digest(ROOT / 'accepted_candidates/q_urgent_1150.json')
    config = read(SOURCE / 'config.json')
    review = read(SOURCE / 'review_verification.json')
    assert review['verified'] and review['matches'] == 300
    assert all(digest(SOURCE / 'workspace' / p) == h for p, h in config['locked_sha256'].items())
    assert all(digest(SOURCE / p) == h for p, h in review['raw_sha256'].items())
    assert all(digest(ROOT / p) == h for p, h in old['code_sha256'].items())
    assert all(digest(ROOT / p) == h for p, h in config['source_sha256'].items())
    model = ROOT / 'agent_code/q_guard/model.json'
    assert digest(model) == digest(SOURCE / 'E/model.json') == old['model_sha256']
    # The adopted source is identical to evaluated E except its fixed defaults.
    source_agent = SOURCE / 'workspace/agent_code/q_switch_v2'
    for p in source_agent.glob('*.py'):
        if p.name != 'callbacks.py':
            assert digest(p) == digest(ROOT / 'agent_code/q_guard' / p.name)
    original = (source_agent / 'callbacks.py').read_text(encoding='utf-8')
    expected = original.replace('"""Inference-only factorial resource-guard experiment with frozen block Q."""',
        '"""Adopted E policy: frozen block Q and both resource guards for classic."""')
    expected = expected.replace("self.guard_mode = os.environ.get('QL_GUARD_MODE', 'E')", "self.guard_mode = 'E'")
    expected = expected.replace("    total = os.environ.get('QL_RESOURCE_COINS', '')\n    self.coin_total = int(total) if total else None",
        '    # Public classic tournament rule, fixed with the accepted policy. This\n'
        '    # must work without the evaluation harness providing environment values.\n    self.coin_total = 9')
    assert expected == (ROOT / 'agent_code/q_guard/callbacks.py').read_text(encoding='utf-8')
    OUT.mkdir(parents=True, exist_ok=False)
    from agent_code.q_guard import callbacks as accepted
    from agent_code.q_switch_v2 import callbacks as reference
    clean = {k: v for k, v in os.environ.items() if not k.startswith('QL_')}
    subject, control = SimpleNamespace(train=False), SimpleNamespace(train=False)
    with patch.dict(os.environ, clean, clear=True):
        accepted.setup(subject)
        assert subject.guard_mode == 'E' and subject.coin_total == 9 and subject.guard_seed == 42
        assert subject.model_path.resolve() == model and subject.episodes == 1150
    with patch.dict(os.environ, {**clean, 'QL_GUARD_MODE': 'E', 'QL_RESOURCE_COINS': '9'}, clear=True):
        reference.setup(control)
    assert subject.q.keys() == control.q.keys()
    import numpy as np
    for key in subject.q:
        np.testing.assert_array_equal(subject.q[key], control.q[key])
    # Stale experiment switches must not silently turn off the accepted policy.
    with patch.dict(os.environ, {**clean, 'QL_GUARD_MODE': 'A', 'QL_RESOURCE_COINS': '0'}, clear=True):
        fixed = SimpleNamespace(train=False)
        accepted.setup(fixed)
        assert fixed.guard_mode == 'E' and fixed.coin_total == 9

    workspace = OUT / 'workspace'
    shutil.copytree(SOURCE / 'workspace', workspace, ignore=shutil.ignore_patterns('logs', '__pycache__'))
    shutil.copytree(ROOT / 'agent_code/q_guard', workspace / 'agent_code/q_guard',
                    ignore=shutil.ignore_patterns('logs', '__pycache__'))
    (workspace / 'logs').mkdir(exist_ok=True)
    # Adapter only extends the harness's accepted names and leaves q_guard's
    # setup without injected model/coin/mode/seed. No physics changes.
    harness = (workspace / 'run_resource_guard_match.py').read_text()
    harness = harness.replace("('q_switch_v2', 'q_switch', 'q_urgent')", "('q_switch_v2', 'q_switch', 'q_urgent', 'q_guard')")
    harness = harness.replace("os.environ[prefix + '_MODEL'] = str(model)",
        "if args.agent != 'q_guard':\n        os.environ[prefix + '_MODEL'] = str(model)")
    harness = harness.replace("os.environ[prefix + '_SEED'] = str(args.seed)",
        "if args.agent != 'q_guard':\n        os.environ[prefix + '_SEED'] = str(args.seed)")
    harness = harness.replace("os.environ['QL_RESOURCE_COINS'] = str(settings.SCENARIOS[args.scenario]['COIN_COUNT'])",
        "if args.agent != 'q_guard':\n        os.environ['QL_RESOURCE_COINS'] = str(settings.SCENARIOS[args.scenario]['COIN_COUNT'])")
    harness = harness.replace("args.agent != 'q_switch_v2'", "args.agent in ('q_switch', 'q_urgent')")
    (workspace / 'run_resource_guard_match.py').write_text(harness)
    rows = {}
    for agent in ('q_switch_v2', 'q_guard'):
        command = [sys.executable, str(workspace / 'run_resource_guard_match.py'), '--agent', agent,
            '--model', str(SOURCE / 'E/model.json'), '--output', str(OUT / (agent + '.json')),
            '--rounds', '2', '--seed', '42', '--opponents', 'rule_based_agent', 'rule_based_agent', 'rule_based_agent']
        with (OUT / (agent + '.log')).open('w') as handle:
            subprocess.run(command, cwd=workspace, env=clean, check=True, stdout=handle, stderr=subprocess.STDOUT)
        rows[agent] = normalized(OUT / (agent + '.rounds.jsonl'), agent)
        assert read(OUT / (agent + '.latency.json'))['over_500ms'] == 0
    assert rows['q_switch_v2'] == rows['q_guard']
    assert digest(ROOT / 'CURRENT_CANDIDATE.json') == old_hash
    assert all(digest(ROOT / p) == h for p, h in config['source_sha256'].items())

    manifest = deepcopy(old)
    manifest.update(agent='q_guard', model='agent_code/q_guard/model.json',
        policy='Evaluated E: D4 block Q + urgent escape + short resource goals with coin-inventory and no-forced-BOMB guards',
        accepted_at=datetime.now(timezone.utc).isoformat(), accepted_by_user=True,
        acceptance_basis='Explicit user adoption after the 300-game factorial pilot; independent confirmation not yet run',
        evaluation_policy_source='experiments/resource_guard_v1/workspace/agent_code/q_switch_v2',
        previous_accepted='accepted_candidates/q_urgent_1150.json',
        runtime_config=dict(scenario='classic', total_coins=9, resource_mode='E',
                            required_cycles=2, max_commitment=8, rng='per-round separate base/proposal streams',
                            default_seed=42, inference_only=True, default_requires_environment=False),
        code_sha256={str(p.relative_to(ROOT)): digest(p) for p in (ROOT / 'agent_code/q_guard').glob('*.py')},
        evidence=[*old['evidence'], 'RESOURCE_GUARD_RESULTS.md',
                  'experiments/resource_guard_v1/review_verification.json',
                  'experiments/resource_guard_adoption_v1/verification.json'],
        submission_zip_replaced=False)
    result = dict(verified=True, checked_at=manifest['accepted_at'], old_manifest_sha256=old_hash,
        model_sha256=digest(model), evaluated_E_source_only_default_changes=True,
        default_environment_required=False, stale_mode_and_coin_overrides_ignored=True,
        real_equivalence_matches=4, actions_and_results_identical=True, training=False,
        formal_zip_sha256=digest(ROOT / 'release/final_v1/final-project-agent-code.zip'),
        previous_code_and_model_unchanged=True,
        deployment_code_sha256=manifest['code_sha256'],
        verification_harness_sha256=digest(workspace / 'run_resource_guard_match.py'))
    save(OUT / 'verification.json', result)
    target = ROOT / 'accepted_candidates/q_guard_1150.json'
    assert not target.exists()
    save(target, manifest)
    save(ROOT / 'CURRENT_CANDIDATE.json', manifest)
    assert digest(target) == digest(ROOT / 'CURRENT_CANDIDATE.json')
    assert all(digest(ROOT / p) == h for p, h in manifest['code_sha256'].items())
    save(OUT / 'status.json', dict(phase='complete', adopted=True, needs_review=False,
         agent='q_guard', mode='E', episodes=1150, manifest_sha256=digest(target)))
    print(json.dumps(dict(adopted=True, agent='q_guard', mode='E', episodes=1150,
        model_sha256=digest(model), real_equivalence_matches=4, formal_zip_replaced=False), indent=2))


if __name__ == '__main__':
    main()
