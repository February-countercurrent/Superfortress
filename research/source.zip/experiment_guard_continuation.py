"""Bounded, matched full-guard continuation; never mutate the adopted release."""
from concurrent.futures import ThreadPoolExecutor, as_completed
import csv
from datetime import datetime, timezone
import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
from types import SimpleNamespace
from unittest.mock import patch

import numpy as np

from finalize_guard_release import framework, digest, read, SCENES
from verify_guard_release import arrays, load_callbacks, rows
import evaluate_final_checkpoints as evaluation

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'experiments/guard_continuation_v1'
SOURCE = ROOT / 'agent_code/q_guard/model.json'
ARMS = ('adopted', 'raw', 'average')
ENV = dict(QF_ALPHA='.15', QF_GAMMA='.9', QF_EPSILON='.05', QF_DECAY='.99',
           QF_SHAPING='0', QF_PROGRESS='.8', QF_DEATH_PENALTY='25',
           QL_RATE_SCALE=str(1/3), QL_BOOTSTRAP_DYNAMIC='1', QL_SYMMETRY='1', QL_N_STEP='3')


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(value, indent=2), encoding='utf-8')
    temp.replace(path)


def run_match(arm, label, opponents, rounds, seed, *, train=False, smoke=False, trainable=False):
    workspace = OUT / 'workspaces' / arm
    folder = OUT / ('smoke' if smoke else 'training' if train else label.split('_')[0]) / arm
    folder.mkdir(parents=True, exist_ok=True)
    output = folder / (label + '.json')
    assert not output.exists() and not output.with_suffix('.rounds.jsonl').exists()
    model = folder / 'model.json' if train else workspace / 'agent_code/q_guard/model.json'
    if train:
        assert not model.exists()
        shutil.copy2(SOURCE, model)
    elif trainable:
        model = SOURCE
    agent = 'q_guard_train' if train or trainable else 'q_guard'
    env = {k: v for k, v in os.environ.items() if not k.startswith(('QL_', 'QF_'))}
    env.update(ENV)
    env['QL_LEARNING_Q'] = arm if arm in ('raw', 'average') else 'raw'
    env['QL_SNAPSHOT_DIR'] = str(folder / 'checkpoints') if train and not smoke else ''
    command = [sys.executable, str(workspace/'run_guard_training_match.py'), '--agent', agent,
               '--model', str(model), '--output', str(output), '--rounds', str(rounds),
               '--seed', str(seed), '--policy-seed', str(seed if train else 42),
               '--opponents', *opponents]
    if train:
        command.append('--train')
    started = time.monotonic()
    with output.with_suffix('.log').open('w', encoding='utf-8') as log:
        subprocess.run(command, cwd=workspace, env=env, stdout=log, stderr=subprocess.STDOUT,
                       check=True, timeout=2400)
    assert b'Traceback' not in output.with_suffix('.log').read_bytes()
    latency = read(output.with_suffix('.latency.json'))
    assert latency['over_500ms'] == 0
    result = dict(arm=arm, label=label, games=rounds, seconds=time.monotonic()-started,
                  agent=agent, model_sha256=digest(model), latency=latency)
    if train:
        result['training'] = check_training(model, arm, rounds)
    return result


def check_training(model, mode, rounds):
    data, base = read(model), read(SOURCE)
    assert data['episodes'] == base['episodes'] + rounds
    expected = dict(learning_value_mode=mode, behavior_policy='d4_average_urgent_escape_resource_E',
        attack_shaping='original', n_step=3, symmetry=True, bootstrap_dynamic=True,
        gradient_divisor=7, resource_mode='E', coin_total=9,
        alpha=.15, gamma=.9, rate_scale=1/3, epsilon_start=.05)
    for key, value in expected.items():
        assert data['config'][key] == value, key
    assert all(len(v) == 6 and np.isfinite(v).all() for v in data['q'].values())
    assert all(len(k.split(',')) == 16 for k in data['visits'])
    visits = lambda d: sum(sum(v) for v in d['visits'].values())
    count = read(model.with_suffix('.credit_metrics.json'))['counts']
    backups = read(model.with_suffix('.backup_metrics.json'))['updates']
    behavior = read(model.with_suffix('.behavior_metrics.json'))
    with model.with_suffix('.csv').open(newline='') as f:
        metrics = list(csv.DictReader(f))
    assert [int(r['episode']) for r in metrics] == list(range(1151, 1151+rounds))
    assert all(float(r['epsilon']) == .05 for r in metrics)
    assert visits(data)-visits(base) == backups == count['updates'] == sum(int(r['steps']) for r in metrics)
    assert behavior['actions'] == backups
    assert sum(count.get('effective_length_'+str(i), 0) for i in (1, 2, 3)) == backups
    return dict(updates=backups, credit=count, behavior=behavior,
                actual_exploration_fraction=behavior['exploration_draws']/backups,
                cut_branch_rate=count['cut_branches']/max(1, count['branch_opportunities']),
                three_step_reaches_last_rate=count['three_step_reaches_last']/max(1, count['three_step_windows']))


def main():
    OUT.mkdir(parents=True, exist_ok=False)
    started = time.monotonic()
    def status(phase, **more):
        save(OUT/'status.json', dict(phase=phase, pid=os.getpid(),
             updated_at=datetime.now(timezone.utc).isoformat(), elapsed_seconds=time.monotonic()-started, **more))
    current = read(ROOT/'CURRENT_CANDIDATE.json')
    assert current['agent'] == 'q_guard' and current['episodes'] == 1150
    assert digest(SOURCE) == current['model_sha256']
    protected = dict(current['code_sha256'])
    for p in (SOURCE, ROOT/'CURRENT_CANDIDATE.json', ROOT/'CURRENT_SUBMISSION.json',
              ROOT/'release/guard_v2/final-project-agent-code.zip',
              ROOT/'release/final_v1/final-project-agent-code.zip'):
        protected[str(p.relative_to(ROOT))] = digest(p)
    assert all(digest(ROOT/p) == h for p,h in protected.items())
    try:
        status('preparing_and_verifying')
        for arm in ARMS:
            workspace = OUT/'workspaces'/arm
            framework(workspace)
            shutil.copy2(ROOT/'run_guard_training_match.py', workspace/'run_guard_training_match.py')
            shutil.copytree(ROOT/'release/guard_v2/q_guard', workspace/'agent_code/q_guard')
            shutil.copytree(ROOT/'agent_code/q_guard_train', workspace/'agent_code/q_guard_train',
                            ignore=shutil.ignore_patterns('__pycache__'))
        locked = {str(p.relative_to(OUT)): digest(p) for p in (OUT/'workspaces').rglob('*.py')}
        config = dict(started_at=datetime.now(timezone.utc).isoformat(), training_seed=347001,
            screen_seeds=[347002,347003], holdout_seeds=[357002,357003], policy_seed=42,
            train_rounds_each=300, eval_rounds_per_scene=60, environment=ENV,
            plan_sha256=digest(ROOT/'GUARD_CONTINUATION_PLAN.md'), protected_sha256=protected,
            locked_sha256=locked, source_sha256=digest(SOURCE), python=sys.version, numpy=np.__version__)
        save(OUT/'config.json', config)
        # Replay complete chronological histories (not disconnected feature fixtures).
        from agent_code.q_guard_train import callbacks as learner
        packaged = load_callbacks('continuation_release_reference', ROOT/'release/guard_v2/q_guard')
        decisions = 0
        clean = {k:v for k,v in os.environ.items() if not k.startswith(('QL_', 'QF_'))}
        for scene in SCENES:
            a, b = SimpleNamespace(train=True), SimpleNamespace(train=False)
            with patch.dict(os.environ, {**clean, 'QL_MODEL': str(SOURCE), 'QL_SEED': '42'}, clear=True):
                learner.setup(a); packaged.setup(b)
            with gzip.open(ROOT/'experiments/guard_features_v1'/scene/'score_frames.jsonl.gz', 'rt', encoding='utf-8') as f:
                for line in f:
                    frame = json.loads(line)
                    if frame['round'] > 3:
                        break
                    state = arrays(frame['state'])
                    assert learner.act(a, state) == packaged.act(b, state)
                    decisions += 1
        checks = dict(chronological_equivalence_decisions=decisions)
        # Actual games also verify harness, history, serialization and terminal counts.
        with ThreadPoolExecutor(max_workers=2) as pool:
            futures = [pool.submit(run_match, arm, 'equivalence', SCENES['mixed'], 2, 347881,
                                   smoke=True, trainable=(arm=='raw')) for arm in ('adopted','raw')]
            checks['equivalence_games'] = [f.result() for f in futures]
        a = rows(OUT/'smoke/adopted/equivalence.rounds.jsonl')
        b = rows(OUT/'smoke/raw/equivalence.rounds.jsonl')
        assert [(r['map_hash'],r['action_sha256'],r['score'],r['win']) for r in a] == \
               [(r['map_hash'],r['action_sha256'],r['score'],r['win']) for r in b]
        with ThreadPoolExecutor(max_workers=2) as pool:
            futures = [pool.submit(run_match, arm, 'training', SCENES['mixed'], 2, 347891,
                                   train=True, smoke=True) for arm in ('raw','average')]
            checks['training_smoke'] = [f.result() for f in futures]
        save(OUT/'preflight.json', dict(verified=True, **checks))
        print('Preflight passed:', decisions, 'chronological decisions; paired games and both training smoke tests.', flush=True)
        status('training', completed_arms=[], target_episodes_each=1450, additional_rounds_each=300)
        training = {}
        with ThreadPoolExecutor(max_workers=2) as pool:
            futures = {pool.submit(run_match, arm, 'training', SCENES['mixed'], 300, 347001, train=True): arm
                       for arm in ('raw','average')}
            for f in as_completed(futures):
                arm = futures[f]; training[arm] = f.result()
                save(OUT/'training_results.json', training)
                status('training', completed_arms=list(training), target_episodes_each=1450)
                print('Training complete:', arm, training[arm]['training']['updates'], 'updates', flush=True)
        hashes = {'adopted': digest(SOURCE)}
        for arm in ('raw','average'):
            source = OUT/'training'/arm/'model.json'
            target = OUT/'workspaces'/arm/'agent_code/q_guard/model.json'
            shutil.copy2(source, target)
            hashes[arm] = digest(target)
            policy_path = target.parent/'policy.json'
            policy = read(policy_path)
            policy.update(episodes=1450, model_sha256=hashes[arm], continuation_mode=arm)
            save(policy_path, policy)
        save(OUT/'frozen_models.json', hashes)
        old_maps = set()
        for folder, dirs, files in os.walk(ROOT/'experiments'):
            dirs[:] = [d for d in dirs if d not in ('workspace','workspaces','guard_continuation_v1','__pycache__')]
            for name in files:
                if name.endswith('.rounds.jsonl'):
                    for r in rows(Path(folder)/name):
                        if 'map_hash' in r: old_maps.add(r['map_hash'])
        for p in (OUT/'training').rglob('*.rounds.jsonl'):
            old_maps.update(r['map_hash'] for r in rows(p))
        for p in (OUT/'smoke').rglob('*.rounds.jsonl'):
            old_maps.update(r['map_hash'] for r in rows(p))
        evaluation.OUT = OUT

        def batch(phase, arms, seed):
            status(phase, arms=list(arms), games_each=120)
            def run_arm(arm):
                result = []
                for i, scene in enumerate(SCENES):
                    result.append(run_match(arm, phase+'_'+scene, SCENES[scene], 60, seed+i))
                    # The shared analyzer expects scene names without phase prefixes.
                    source = OUT/phase/arm/(phase+'_'+scene+'.rounds.jsonl')
                    shutil.copy2(source, OUT/phase/arm/(scene+'.rounds.jsonl'))
                return result
            timing = {}
            with ThreadPoolExecutor(max_workers=2) as pool:
                futures = {pool.submit(run_arm, a): a for a in arms}
                for f in as_completed(futures):
                    arm = futures[f]; timing[arm] = f.result()
                    save(OUT/(phase+'_timing.json'), timing)
                    status(phase, completed_arms=list(timing), total_arms=len(arms))
                    print(phase, arm, 'complete', flush=True)
            assert all(digest(OUT/p) == h for p,h in locked.items())
            assert all(digest(ROOT/p) == h for p,h in protected.items())
            assert all(digest(OUT/'workspaces'/a/'agent_code/q_guard/model.json') == h for a,h in hashes.items())

        batch('screen', ARMS, 347002)
        screen, screen_maps = evaluation.analyze('screen', ARMS, 60, old_maps)
        best = max(ARMS, key=lambda a:(screen['results'][a]['combined']['totals']['win'],
            screen['results'][a]['combined']['totals']['score'], -ARMS.index(a)))
        base = screen['results']['adopted']['combined']['totals']
        candidate = screen['results'][best]['combined']['totals']
        advance = best != 'adopted' and candidate['win']-base['win'] >= 4 and candidate['score'] >= base['score']
        save(OUT/'selection.json', dict(screen_best=best, advance=advance,
             selected=best if advance else 'adopted', frozen_at=datetime.now(timezone.utc).isoformat()))
        promote = False
        if advance:
            batch('holdout', ('adopted',best), 357002)
            holdout, _ = evaluation.analyze('holdout', ('adopted',best), 60, old_maps|screen_maps)
            delta = holdout['comparisons'][best]
            promote = (delta['win']['paired_95ci'][0] > 0 and delta['score']['difference'] >= 0
                and all(holdout['results'][best][s]['totals']['win'] >=
                        holdout['results']['adopted'][s]['totals']['win'] for s in SCENES))
        decision = dict(recommended=best if promote else 'adopted', promotion_evidence_passed=promote,
             trained_rounds=600, evaluated_games=360+240*int(advance), source_unchanged=True,
             automatically_deployed=False, submitted_package_unchanged=True)
        save(OUT/'decision.json', decision)
        status('complete', needs_review=True, **decision)
        print(json.dumps(decision), flush=True)
        print({a:screen['results'][a]['combined']['totals'] for a in ARMS}, flush=True)
    except Exception as exc:
        status('failed', error=repr(exc))
        raise


if __name__ == '__main__':
    main()
