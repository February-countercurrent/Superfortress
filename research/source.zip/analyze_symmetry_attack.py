"""Diagnose a fixed chronological sample; counterfactual scores are not outcomes."""
from collections import Counter, defaultdict
import gzip
import json
from pathlib import Path
import numpy as np
from agent_code.q_tactical.tactics import evaluate_bomb

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'experiments/symmetry_attack_diagnosis_v1'


def main():
    rows = [json.loads(x) for x in (OUT/'match.rounds.jsonl').read_text().splitlines()]
    reference = [json.loads(x) for x in (ROOT/'experiments/symmetry_inference_v1/average_strong.rounds.jsonl').read_text().splitlines()][:20]
    assert len(rows) == len(reference) == 20
    for observed, expected in zip(rows, reference):
        for key in ('map_hash', 'steps', 'score', 'win', 'tie_for_first', 'survived'):
            assert observed[key] == expected[key], (key, observed['round'])
        for agent, stats in observed['agents'].items():
            for key, value in stats.items():
                if key != 'time':
                    assert value == expected['agents'][agent][key], (agent, key, observed['round'])
    counts = Counter(); gaps = []; attack_examples = []; history = defaultdict(list)
    with gzip.open(OUT/'score_frames.jsonl.gz', 'rt', encoding='utf-8') as handle:
        for line in handle:
            frame = json.loads(line); info = frame['info']; state = frame['state']
            mask = np.array(frame['candidate_mask'], dtype=bool)
            q = np.array(frame['adjusted_q']); chosen = frame['chosen']
            raw = np.array(frame['unaveraged_q']) - frame['costs']
            counts['steps'] += 1
            counts['action_'+chosen] += 1
            counts['attack_target_steps'] += int(info['target'] == 3)
            counts['threatened_steps'] += int(info['threatened'])
            counts['calm_wait'] += int(chosen == 'WAIT' and not info['threatened'])
            counts['empty_bomb'] += int(chosen == 'BOMB' and info['yield'] == 0 and info['enemy_hits'] == 0)
            previous = history[frame['round']]
            if len(previous) >= 2:
                earlier = previous[-2]
                reversal = state['self'][3] == earlier['state']['self'][3] and state['self'][3] != previous[-1]['state']['self'][3]
                calm_attack = all(x['info']['target'] == 3 and not x['info']['threatened'] for x in (earlier, previous[-1], frame))
                counts['calm_attack_two_step_returns'] += int(reversal and calm_attack)
            previous.append(frame)
            if info['enemy_hits'] and state['self'][2]:
                counts['ready_ray_attack'] += 1
                counts['static_safe_ray_attack'] += int(info['safe'][5])
                counts['dynamic_safe_ray_attack'] += int(mask[5])
            if not (info['enemy_hits'] and mask[5] and not info['threatened']):
                continue
            counts['calm_safe_ray_attack'] += 1
            counts['calm_safe_ray_bomb_chosen'] += int(chosen == 'BOMB')
            raw_prefers = np.isclose(raw[5], raw[mask].max())
            avg_prefers = np.isclose(q[5], q[mask].max())
            counts['raw_bomb_greedy_average_not'] += int(raw_prefers and not avg_prefers)
            counts['average_bomb_greedy_raw_not'] += int(avg_prefers and not raw_prefers)
            gap = float(q[mask].max()-q[5]); gaps.append(gap)
            state['field'] = np.array(state['field'])
            state['explosion_map'] = np.array(state['explosion_map'])
            # Restore JSON-shaped history after evaluating geometry.
            tactical = evaluate_bomb(state)
            state['field'] = state['field'].tolist()
            state['explosion_map'] = state['explosion_map'].tolist()
            trap = any(x['trap'] for x in tactical['targets'])
            pressure = max((x['pressure'] for x in tactical['targets']), default=0.)
            counts['model_trap_opportunities'] += int(trap)
            counts['model_trap_skipped'] += int(trap and chosen != 'BOMB')
            counts['no_endpoint_compression'] += int(pressure == 0.)
            if chosen != 'BOMB':
                attack_examples.append(dict(round=frame['round'], step=frame['step'], position=state['self'][3],
                    gap=gap, chosen=chosen, trap=trap, pressure=pressure, target=info['target'], yield_=info['yield']))
    report = dict(rounds=20, replay_exact=True, counts=counts,
        bomb_gap_percentiles=np.percentile(gaps,[0,25,50,75,100]).tolist() if gaps else [],
        skipped_attack_examples=sorted(attack_examples,key=lambda x:-x['pressure'])[:15],
        limitation='First 20 previously evaluated strong maps, diagnostic reuse; static ray hits and endpoint compression are not kill probabilities. Two-step returns can be legitimate pursuit. Same-state unaveraged scores are counterfactual, not replayed outcomes.')
    (OUT/'analysis.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(report,indent=2))


if __name__ == '__main__':
    main()
