"""Observe tactical features alongside the unchanged safe-random collector."""
import sys
import numpy as np
from agent_code.tree_fqi import train
from agent_code.tree_tactical.tactical import tactical_key,open_attack_bonus
from agent_code.tree_tactical.features import describe
import run_tree_fqi_match


class SnapshotContext:
    """Cache immutable observation objects, not the non-unique round/step pair."""
    def __init__(self):
        self.cache={}

    def __call__(self,state):
        identity=id(state)
        if identity not in self.cache:
            if len(self.cache)>=8: self.cache.clear()
            info=describe(state)
            # Retain the snapshot so its identity cannot be reused while cached.
            self.cache[identity]=(state,tactical_key(state,info),open_attack_bonus(state,'BOMB',info))
        return self.cache[identity][1:]


def next_decision_state(state):
    # The framework increments its clock only at the next do_step(), after
    # reporting this post-action snapshot. Encode the time of that decision.
    return dict(state,step=state['step']+1)


def main():
    original=train.observe
    context=SnapshotContext()
    def observe(self,old,action,new,events):
        original(self,old,action,new,events)
        if old is None: return
        x,bonus=context(old)
        next_x=np.zeros(28,dtype=np.int8) if new is None else context(next_decision_state(new))[0]
        self.transitions[-1].update(tactical_x=x.copy(),tactical_next_x=next_x.copy(),
                                   open_attack_bonus=bonus if action=='BOMB' else 0.)
    train.observe=observe
    run_tree_fqi_match.main()


if __name__=='__main__': main()
