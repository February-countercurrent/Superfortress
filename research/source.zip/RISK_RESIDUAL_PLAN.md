# Bounded occupancy-risk feature: fixed before training

One final small experiment. Start from the adopted 1150-episode weights and
legacy visit counts. Freeze all seven old blocks exactly. Preserve the submitted
ZIP, adopted sources and pointers. Do not select intermediate checkpoints.

Add five action-local codes for UP/RIGHT/DOWN/LEFT/WAIT: 0 inactive/unavailable,
1 certified by the existing single-moving-opponent occupancy model, 2 not
certified. Certificates are model results, not death probabilities. Only activate
while threatened with own bomb unavailable, and never override an urgent WAIT
correction. Incomplete search or all-uncertified actions disable the residual.
The original safety mask is unchanged; no BOMB correction is allowed.

Four new scalar coefficients are tied across rotations/reflections: movement vs
WAIT, crossed with certified vs uncertified. Each is initially zero and projected
to [-0.5,0.5] after updating. This bound is a conservative design choice, not an
optimized hyperparameter. Frozen D4-averaged Q plus the residual forms the value
function; the deployed behavior also retains original escape costs and E guards.

The risk arm observes codes 1/2. The blind control computes the same eligibility
and masks but maps both codes to 1; it has the same four-parameter architecture,
with the hidden category unvisited. Both learn only residual coefficients using
the original rewards, 3-step greedy tree backup, gamma .9, epsilon .05, the
inherited .15 visit-decaying rate scaled by 1/3 and divided by seven. Frozen base
coefficients have zero update. This deliberately tests a small calibration, not
full feature retraining or a convergence claim.

Train both arms for 300 rounds on mixed opponents, seed367001. Preserve every25
round snapshot for inspection/restart only; only final1450 weights are eligible.
Screen frozen, blind and risk on60 mixed +60 strong each, seeds367002/367003,
policy seed42. Rank by strict wins, game score, then frozen/blind/risk order.
Advance only with at least4/120 extra wins and no score decrease relative to
frozen. For risk, also require no fewer wins than blind. If advancing, freeze
selection and compare with frozen on untouched60+60 maps377002/377003.
Recommend a replacement only with paired win95% bootstrap lower bound >0,
no total-score decrease and neither opponent scene losing wins.

Maximum600 formal training and600 evaluation games; two CPU workers. Preserve
at least15 minutes before assumed19:00UTC submission deadline. No unplanned
feature variants, checkpoint search, longer training or automatic upload. If
preflight fails or runtime threatens that buffer, keep the already submitted ZIP.
