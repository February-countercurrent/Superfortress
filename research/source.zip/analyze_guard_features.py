"""Whole-cohort feature alias audit and causal-timeline leads, not new wins."""
from collections import Counter, defaultdict
import json
from pathlib import Path

import numpy as np

from analyze_urgent_scoring import round_frames, state_arrays
from agent_code.q_guard.features import ACTIONS, DELTAS, allowed, blast, describe
from agent_code.q_guard.dynamic import candidate_mask_with_status
from diagnose_guard_features import ROOT, OUT, SOURCE, digest, read, save, stable

NAME = 'q_switch_v2'


def collision(frame):
    occupied = {o[0]: tuple(o[3]) for o in frame['state']['others']}
    occupied[NAME] = tuple(frame['state']['self'][3])
    for a in frame['actions']:
        if a['agent'] == NAME and a['action'] in ACTIONS[:4]:
            dx, dy = DELTAS[ACTIONS.index(a['action'])]
            q = a['before'][0] + dx, a['before'][1] + dy
            return [n for n, p in occupied.items() if n != NAME and p == q] if a['before'] == a['after'] else []
        occupied[a['agent']] = tuple(a['after'])
    return []


def new_enemy_bombs(frame):
    return [dict(agent=a['agent'], position=a['before'], step=frame['step']) for a in frame['actions']
            if a['agent'] != NAME and 'BOMB_DROPPED' in a['events']]


def row_ref(scene, number, step):
    return dict(scene=scene, round=number, step=step)


def main():
    assert read(OUT / 'replay_verification.json')['verified']
    groups = defaultdict(list)
    records, deaths, bombs = [], [], []
    totals, outcomes = Counter(), Counter()
    for scene in ('mixed', 'strong'):
        folder = OUT / scene
        rows = {r['round']: r for r in stable(folder / 'match.rounds.jsonl')}
        traces = defaultdict(dict)
        for line in (folder / 'policy.trace.jsonl').read_text().splitlines():
            f = json.loads(line)
            traces[f['round']][f['step']] = f
        for number, frames in round_frames(folder / 'score_frames.jsonl.gz'):
            row, trace = rows[number], traces[number]
            assert len(frames) == row['agents'][NAME]['steps'] == len(trace)
            outcome = 'win' if row['win'] else 'tie' if row['tie_for_first'] else 'loss'
            outcomes[outcome + ('_alive' if row['survived'] else '_dead')] += 1
            state_list = [state_arrays(f) for f in frames]
            for i, (f, s) in enumerate(zip(frames, state_list)):
                t = trace[f['step']]
                assert f['step'] == i + 1 and f['chosen'] == t['action']
                assert f['candidate_mask'] == t['candidate_mask']
                np.testing.assert_allclose(f['adjusted_q'], t['scores'], rtol=0, atol=1e-12)
                key = tuple(f['info']['key'])
                assert len(key) == 16
                bomb_times = [timer + 1 for p, timer in s['bombs'] if tuple(s['self'][3]) in blast(s['field'], p)]
                arrival = min(bomb_times) if bomb_times else None
                if s['explosion_map'][tuple(s['self'][3])] > 0:
                    arrival = 0
                r = dict(**row_ref(scene, number, f['step']), key=list(key), position=f['state']['self'][3],
                         q=f['q'], scores=t['scores'], mask=t['candidate_mask'], best=t['baseline_best'],
                         action=f['chosen'], threatened=f['info']['threatened'],
                         branch=t['decision']['accepted'], hidden_coins=t['inventory']['hidden_exact'],
                         threat_arrival=arrival, collision=collision(f),
                         post_safe_any=any(f['post_safe']) if 'post_safe' in f else None,
                         dead=f['dead'], events=f['events'])
                groups[key].append(len(records))
                records.append(r)
                totals['observations'] += 1
                if 'BOMB_DROPPED' in f['events']:
                    counts = Counter(e for later in frames[i:i + 6] for e in later['events'])
                    bombs.append(dict(**row_ref(scene, number, f['step']), key=list(key),
                        position=f['state']['self'][3], baseline_action=t['baseline_action'],
                        source='branch_agreed' if t['decision']['accepted'] else 'base',
                        observed_selfkill=bool(counts['KILLED_SELF']), observed_kills=counts['KILLED_OPPONENT'],
                        observed_crates=counts['CRATE_DESTROYED'], observed_coins_found=counts['COIN_FOUND'],
                        observation_complete=frames[-1]['step'] >= f['step'] + 5))
            if frames[-1]['dead']:
                final = frames[-1]
                selfkill = 'KILLED_SELF' in final['events']
                own = [b for b in final['lethal'] if b['owner'] == NAME]
                assert bool(own) == selfkill
                assert int(selfkill) == row['agents'][NAME].get('suicides', 0)
                start = own[0]['placed'] - 1 if own else max(0, len(frames) - 8)
                path, first_loss = [], None
                for i in range(start, len(frames)):
                    f, s = frames[i], state_list[i]
                    info = {**f['info'], **{k: np.array(f['info'][k], dtype=bool) for k in ('safe', 'robust_safe', 'legal')}}
                    _, fallback = candidate_mask_with_status(s, info, allowed(info, True))
                    p = dict(step=f['step'], position=f['state']['self'][3], action=f['chosen'],
                        after_position=f['after_position'], key=f['info']['key'], baseline_action=trace[f['step']]['baseline_action'],
                        allowed=[ACTIONS[j] for j, v in enumerate(f['candidate_mask']) if v],
                        best=[ACTIONS[j] for j in trace[f['step']]['baseline_best']],
                        static_safe=[ACTIONS[j] for j, v in enumerate(f['info']['safe']) if v],
                        dynamic_fallback=fallback, collision=collision(f), new_enemy_bombs=new_enemy_bombs(f),
                        post_safe_any=any(f['post_safe']) if 'post_safe' in f else None,
                        branch=trace[f['step']]['decision']['accepted'])
                    if first_loss is None and f['info']['safe'][ACTIONS.index(f['chosen'])] and p['post_safe_any'] is False:
                        first_loss = f['step']
                    path.append(p)
                plant = trace[frames[start]['step']]
                deaths.append(dict(scene=scene, round=number, death_step=final['step'], suicide=selfkill,
                    score=row['score'], final_win=row['win'], lethal=final['lethal'],
                    plant_source=('branch_agreed' if plant['decision']['accepted'] else 'base') if own else None,
                    first_loss_step=first_loss, collision_since_plant=any(p['collision'] for p in path), path=path))
    totals['matches'] = 60
    totals['deaths'] = len(deaths)
    totals['suicides'] = sum(d['suicide'] for d in deaths)
    totals['bombs'] = len(bombs)
    totals['suicides_with_collision_since_plant'] = sum(d['suicide'] and d['collision_since_plant'] for d in deaths)
    assert totals['observations'] == 20160 and totals['deaths'] == 7 and totals['suicides'] == 3
    aliases = []
    for key, indices in groups.items():
        values = [records[i] for i in indices]
        raw = {tuple(np.round(v['q'], 10)) for v in values}
        assert len(raw) == 1, 'Identical Q features must imply identical learned Q'
        def count(field):
            return len({tuple(v[field]) if isinstance(v[field], list) else v[field] for v in values})
        variants = dict(masks=count('mask'), final_scores=len({tuple(np.round(v['scores'], 10)) for v in values}),
                        best_sets=count('best'), hidden_counts=count('hidden_coins'), threat_times=count('threat_arrival'))
        if len(values) > 1:
            totals['repeated_feature_keys'] += 1
            for name, n in variants.items():
                totals['keys_vary_' + name] += int(n > 1)
            if any(v > 1 for v in variants.values()):
                aliases.append(dict(key=list(key), observations=len(values), variants=variants, record_indices=indices))
    totals['feature_keys'] = len(groups)
    probes = []
    for death in deaths:
        if not death['suicide']:
            continue
        for p in death['path']:
            if p['step'] > (death['first_loss_step'] or death['death_step']):
                continue
            key = tuple(p['key'])
            target = next(r for r in records if (r['scene'], r['round'], r['step']) == (death['scene'], death['round'], p['step']))
            matches = [records[i] for i in groups[key] if (records[i]['scene'], records[i]['round']) != (death['scene'], death['round'])]
            strict = [r for r in matches if r['mask'] == target['mask'] and
                      np.allclose(r['scores'], target['scores'], rtol=0, atol=1e-10) and r['branch'] == target['branch']]
            probes.append(dict(**row_ref(death['scene'], death['round'], p['step']),
                               other_round_same_key=len(matches), same_key_mask_scores_branch=len(strict),
                               examples=[{k: r[k] for k in ('scene', 'round', 'step', 'action', 'threat_arrival', 'collision')} for r in strict[:8]]))
    for filename, data in (('deaths.json', deaths), ('bombs.json', bombs), ('state_records.json', records),
                           ('alias_groups.json', aliases), ('suicide_alias_probes.json', probes)):
        save(OUT / filename, data)
    result = dict(verified_replay=True, totals=dict(totals), round_outcomes=dict(outcomes),
        suicide_cases=[{k: d[k] for k in ('scene', 'round', 'death_step', 'plant_source', 'first_loss_step', 'collision_since_plant')} for d in deaths if d['suicide']],
        limitations=['Replay of existing 60 games, not independent evaluation.',
                     'Aliased features or different outcomes do not establish opposite optimal actions.',
                     'Masks, geometric escape costs and resource guards can distinguish some states outside the 16 learned inputs.'])
    save(OUT / 'analysis.json', result)
    save(OUT / 'status.json', dict(phase='initial_analysis_complete', needs_review=True, new_matches=0))
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
