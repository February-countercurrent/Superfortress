"""Replay every strong game from the frozen teacher confirmation, both arms."""
from concurrent.futures import ThreadPoolExecutor,as_completed
from datetime import datetime,timezone
import gzip
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

from experiment_tree_fqi import SCENES,read,rows
from experiment_tree_fqi_batches import save,clean_environment
from finalize_guard_release import digest,framework
from confirm_tree_teacher import MODELS,EXPECTED,SEEDS

ROOT=Path(__file__).resolve().parent
PRIOR=ROOT/'experiments/tree_teacher_confirmation_v1'
OUT=ROOT/'experiments/tree_attack_diagnosis_v1'


def replay(batch,arm):
    name=f'batch_{batch}_{arm}';workspace=OUT/'workspaces'/name
    folder=OUT/'replay'/name;folder.mkdir(parents=True)
    tick=time.monotonic()
    with (folder/'run.log').open('w',encoding='utf-8') as log:
        subprocess.run([sys.executable,'-X','utf8','trace_tree_attack_match.py',
            '--trace',str(folder/'trace.jsonl.gz'),'--bomb-trace',str(folder/'bombs.jsonl'),
            '--agent','tree_fqi','--model',str(workspace/'agent_code/tree_fqi/model.pkl'),
            '--output',str(folder/'match.json'),'--rounds','100','--seed',str(SEEDS[batch]['strong']),
            '--policy-seed','42','--opponents',*SCENES['strong']],cwd=workspace,
            env=clean_environment(),stdout=log,stderr=subprocess.STDOUT,check=True,timeout=3600)
    before=rows(PRIOR/'evaluation'/f'batch_{batch}'/arm/'strong.rounds.jsonl')
    after=rows(folder/'match.rounds.jsonl')
    assert len(before)==len(after)==100
    for a,b in zip(before,after):
        for key in ('round','map_hash','action_sha256','score','win','tie_for_first','survived','steps'):
            assert a[key]==b[key],(name,a['round'],key)
        for agent in a['agents']:
            assert {k:v for k,v in a['agents'][agent].items() if k!='time'}=={k:v for k,v in b['agents'][agent].items() if k!='time'}
    assert read(folder/'match.latency.json')['over_500ms']==0
    bomb_rows=rows(folder/'bombs.jsonl')
    subject=[b for b in bomb_rows if b['owner']=='tree_fqi']
    for row in after:
        bb=[b for b in subject if b['round']==row['round']];stats=row['agents']['tree_fqi']
        for key,value in dict(bombs=len(bb),crates=sum(b['crates'] for b in bb),
                              kills=sum(len(b['hits']) for b in bb),
                              suicides=sum(len(b['self_hits']) for b in bb)).items():
            assert value==stats.get(key,0),(name,row['round'],key,value,stats.get(key,0))
    steps=decisions=finished=0
    with gzip.open(folder/'trace.jsonl.gz','rt',encoding='utf-8') as f:
        for line in f:
            record=json.loads(line);steps+=1;decisions+=record['decision'] is not None
            finished+=record['after']['finished']
    assert finished==100 and steps==sum(r['steps'] for r in after)
    assert decisions==sum(r['agents']['tree_fqi']['steps'] for r in after)
    assert digest(workspace/'agent_code/tree_fqi/model.pkl')==EXPECTED[arm]
    result=dict(verified=True,games=100,decisions=decisions,world_steps=steps,
        exact_action_replay=True,bomb_credit_matches=True,seconds=time.monotonic()-tick,
        result_sha256={p.name:digest(p) for p in folder.iterdir() if p.suffix not in ('.log',)})
    save(folder/'verification.json',result)
    return result


def main():
    OUT.mkdir(parents=True,exist_ok=False);tick=time.monotonic()
    def status(phase,**kw):
        save(OUT/'status.json',dict(phase=phase,pid=os.getpid(),elapsed_seconds=time.monotonic()-tick,
            updated_at=datetime.now(timezone.utc).isoformat(),**kw));print(phase,kw,flush=True)
    try:
        status('preparing')
        prior=read(PRIOR/'config.json')
        protected={**prior['protected_sha256'],**prior['source_sha256']}
        for p in PRIOR.rglob('*'):
            if p.is_file() and '__pycache__' not in p.parts and 'logs' not in p.parts:
                protected[str(p.relative_to(ROOT))]=digest(p)
        for name in ('CURRENT_TREE_RESEARCH.json','retained_candidates/tree_teacher_v1.json'):
            protected[name]=digest(ROOT/name)
        assert all(digest(ROOT/n)==h for n,h in protected.items())
        assert all(digest(p)==EXPECTED[a] for a,p in MODELS.items())
        names=['trace_tree_attack_match.py','diagnose_tree_attack.py','TREE_ATTACK_DIAGNOSIS_PLAN.md',
               'run_tree_fqi_match.py']
        locked={n:digest(ROOT/n) for n in names}
        current=read(ROOT/'CURRENT_TREE_RESEARCH.json')
        locked.update(current['code_sha256'])
        save(OUT/'config.json',dict(protected_sha256=protected,source_sha256=locked,models=EXPECTED,
            seeds={b:SEEDS[b]['strong'] for b in SEEDS},rounds_per_batch=100,policy_seed=42,
            training=False,new_evaluation=False,workers=4))
        for n in locked:
            p=OUT/'sources'/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/n,p)
        jobs=[(b,a) for b in SEEDS for a in MODELS]
        for batch,arm in jobs:
            workspace=OUT/'workspaces'/f'batch_{batch}_{arm}';framework(workspace)
            for n in ('trace_tree_attack_match.py','run_tree_fqi_match.py'):
                shutil.copy2(ROOT/n,workspace/n)
            shutil.copytree(ROOT/'agent_code/tree_guard',workspace/'agent_code/tree_fqi',
                ignore=shutil.ignore_patterns('__pycache__','logs','model.pkl'))
            shutil.copy2(MODELS[arm],workspace/'agent_code/tree_fqi/model.pkl')
        status('replaying',total_games=600,completed=[])
        completed={}
        with ThreadPoolExecutor(max_workers=4) as pool:
            tasks={pool.submit(replay,*job):job for job in jobs}
            for task in as_completed(tasks):
                batch,arm=tasks[task];completed[f'batch_{batch}_{arm}']=task.result()
                save(OUT/'jobs.json',completed)
                status('replaying',total_games=600,completed=list(completed))
        assert all(digest(ROOT/n)==h for n,h in protected.items())
        assert all(digest(ROOT/n)==h for n,h in locked.items())
        save(OUT/'verification.json',dict(verified=True,identical_games=600,
            protected_files=len(protected),protected_unchanged=True,sources_unchanged=True,
            all_bomb_credit_matches=True,includes_steps_after_subject_death=True))
        status('replay_complete',verified=True)
    except Exception as e:
        status('failed',error=repr(e));raise


if __name__=='__main__': main()
