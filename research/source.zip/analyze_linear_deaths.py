"""Observable death indicators, not unsupported causal classifications."""
from collections import Counter
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'experiments/linear_diagnosis_v1'
ACTIONS = ['UP', 'RIGHT', 'DOWN', 'LEFT', 'WAIT', 'BOMB']


def stable_rows(path):
    rows = [json.loads(x) for x in path.read_text().splitlines()]
    for row in rows:
        for agent in row['agents'].values():
            agent.pop('time', None)
    return rows


def main():
    observed = stable_rows(OUT / 'match.rounds.jsonl')
    reference = stable_rows(ROOT / 'experiments/linear_v1/linear_strong.rounds.jsonl')
    assert len(observed) == len(reference) == 60
    assert observed == reference, 'Instrumentation changed the match outcomes'
    counts = Counter()
    examples = []
    for path in sorted(OUT.glob('death_*.json')):
        frames = json.loads(path.read_text())
        end = frames[-1]
        suicide = 'KILLED_SELF' in end['events']
        counts['deaths'] += 1
        counts['suicides'] += suicide
        counts['death_with_no_safe_action'] += not any(end['info']['safe'])
        own_lethal = [b for b in end['lethal'] if b['owner'] == 'q_linear']
        placements = [f for f in frames if any(b['placed'] == f['step'] for b in own_lethal)]
        unsafe_choices = [f['step'] for f in frames if any(f['info']['safe'])
                          and not f['info']['safe'][ACTIONS.index(f['chosen'])]]
        counts['window_unsafe_choice_despite_safe_option'] += bool(unsafe_choices)
        losses = []
        for f in frames:
            if any(f['info']['safe']) and (f['dead'] or not any(f.get('post_safe', []))):
                own = next(a for a in f['actions'] if a['agent'] == 'q_linear')
                blocked_move = False
                if f['chosen'] in ACTIONS[:4] and 'INVALID_ACTION' in own['events']:
                    dx, dy = [(0, -1), (1, 0), (0, 1), (-1, 0)][ACTIONS.index(f['chosen'])]
                    destination = [own['before'][0] + dx, own['before'][1] + dy]
                    earlier = f['actions'][:f['actions'].index(own)]
                    blocked_move = any(a['agent'] != 'q_linear' and a['after'] == destination for a in earlier)
                enemy_bombs = [a['agent'] for a in f['actions'] if a['agent'] != 'q_linear'
                               and 'BOMB_DROPPED' in a['events']]
                losses.append(dict(step=f['step'], action=f['chosen'],
                    chosen_safe=f['info']['safe'][ACTIONS.index(f['chosen'])],
                    own_events=own['events'], enemy_bomb_dropped_same_step=enemy_bombs,
                    invalid_action='INVALID_ACTION' in own['events'],
                    earlier_opponent_occupies_destination=blocked_move, dead=f['dead']))
        counts['window_safe_to_no_safe_transition'] += bool(losses)
        counts['window_loss_with_enemy_new_bomb'] += any(l['enemy_bomb_dropped_same_step'] for l in losses)
        counts['window_loss_with_invalid_action'] += any(l['invalid_action'] for l in losses)
        counts['window_loss_with_observed_move_collision'] += any(l['earlier_opponent_occupies_destination'] for l in losses)
        counts['own_lethal_placement_observed'] += bool(placements)
        counts['own_lethal_placement_marked_safe'] += bool(placements) and all(f['info']['safe'][5] for f in placements)
        examples.append(dict(round=end['round'], suicide=suicide, lethal=end['lethal'],
            death_step=end['step'], unsafe_choices=unsafe_choices, safety_losses=losses,
            own_lethal_placement_steps=[f['step'] for f in placements]))
    report = dict(reproduction_exact_except_timing=True, rounds=60, counts=dict(counts), cases=examples,
        limitation='Overlapping observed indicators within the last 12 steps. New enemy bombs and collisions are associations, not counterfactual causal proof.')
    (OUT / 'analysis.json').write_text(json.dumps(report, indent=2))
    print(json.dumps({k: v for k, v in report.items() if k != 'cases'}, indent=2))


if __name__ == '__main__':
    main()
