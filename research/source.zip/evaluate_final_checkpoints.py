"""One bounded screen and one untouched holdout using the actual release policy."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
import os
from pathlib import Path
import time
import numpy as np

from finalize_guard_release import ROOT, OUT, RELEASE, MODELS, SCENES, read, save, digest
from verify_guard_release import run_match, rows

METRICS = ('win', 'score', 'survived', 'suicides', 'coins', 'kills')


def matrix(data):
    return np.array([[float(r[m] if m in ('win', 'score', 'survived') else
                           r['agents']['q_guard'].get(m, 0)) for m in METRICS] for r in data])


def analyze(phase, arms, rounds, old_maps):
    results, data, maps = {}, {}, set()
    for arm in arms:
        results[arm] = {}
        for scene in SCENES:
            rows_ = rows(OUT / phase / arm / (scene + '.rounds.jsonl'))
            assert len(rows_) == rounds
            assert [r['round'] for r in rows_] == list(range(1, rounds+1))
            hashes = [r['map_hash'] for r in rows_]
            assert len(set(hashes)) == rounds and not (set(hashes) & old_maps)
            if arm != 'adopted':
                assert hashes == [r['map_hash'] for r in data['adopted', scene]]
            else:
                assert not maps & set(hashes)
                maps.update(hashes)
            for r in rows_:
                own = r['agents']['q_guard']
                other_scores = [s['score'] for name,s in r['agents'].items() if name != 'q_guard']
                assert r['score'] == own['score'] == own.get('coins', 0) + 5*own.get('kills', 0)
                assert r['win'] == (r['score'] > max(other_scores))
                assert r['policy_seed'] == 42 and r['subject_max_action_ms'] < 500
            data[arm, scene] = rows_
            a = matrix(rows_)
            results[arm][scene] = dict(rounds=rounds, totals=dict(zip(METRICS, a.sum(axis=0).tolist())),
                                       means=dict(zip(METRICS, a.mean(axis=0).tolist())))
        a = np.vstack([matrix(data[arm, s]) for s in SCENES])
        results[arm]['combined'] = dict(rounds=len(a), totals=dict(zip(METRICS, a.sum(axis=0).tolist())),
                                        means=dict(zip(METRICS, a.mean(axis=0).tolist())))
    comparisons = {}
    for arm in arms[1:]:
        rng = np.random.default_rng(337004)
        boots, diffs = [], []
        for scene in SCENES:
            d = matrix(data[arm, scene]) - matrix(data['adopted', scene])
            diffs.append(d)
            boots.append(d[rng.integers(rounds, size=(20000, rounds))].mean(axis=1))
        b, d = sum(boots)/len(boots), np.vstack(diffs)
        comparisons[arm] = {m: dict(difference=float(d[:,i].mean()),
             paired_95ci=np.quantile(b[:,i], [.025, .975]).tolist()) for i,m in enumerate(METRICS)}
    value = dict(results=results, comparisons=comparisons, distinct_maps=len(maps),
                 prior_maps_checked=len(old_maps), maps_paired=True, policy_seed=42)
    save(OUT / (phase + '_results.json'), value)
    return value, maps


def main():
    assert read(RELEASE / 'verification/verification.json')['verified']
    start = time.monotonic()
    build = read(OUT / 'build.json')
    locked = {str(p.relative_to(OUT)): digest(p) for p in (OUT / 'workspaces').rglob('*')
              if p.suffix in ('.py', '.json') and 'logs' not in p.parts}
    old_maps = set()
    for folder, dirs, files in os.walk(ROOT / 'experiments'):
        dirs[:] = [d for d in dirs if d not in ('workspace', 'workspaces', 'final_checkpoint_v1', '__pycache__')]
        for name in files:
            if name.endswith('.rounds.jsonl'):
                for r in rows(Path(folder) / name):
                    if 'map_hash' in r:
                        old_maps.add(r['map_hash'])
    save(OUT / 'config.json', dict(started_at=datetime.now(timezone.utc).isoformat(), pid=os.getpid(),
        plan_sha256=digest(ROOT / 'FINAL_CHECKPOINT_NOTES.md'), locked_sha256=locked,
        build=build, agent_seed=42, screen_seeds=[327002,327003], holdout_seeds=[337002,337003],
        models={k: str(v.relative_to(ROOT)) for k,v in MODELS.items()}, prior_maps=len(old_maps)))

    def status(phase, **extra):
        save(OUT / 'status.json', dict(phase=phase, updated_at=datetime.now(timezone.utc).isoformat(),
             elapsed_seconds=time.monotonic()-start, **extra))

    def batch(phase, arms, rounds, seed):
        assert time.monotonic()-start < 5400, 'Optional work budget exhausted'
        def run_arm(arm):
            # No simultaneous jobs may share framework log files.
            return [run_match(arm, scene, rounds, seed+i, phase) for i,scene in enumerate(SCENES)]
        status(phase, arms=list(arms), total_games=len(arms)*rounds*2)
        results = {}
        with ThreadPoolExecutor(max_workers=2) as pool:
            jobs = {pool.submit(run_arm, arm): arm for arm in arms}
            for f in as_completed(jobs):
                arm = jobs[f]
                results[arm] = f.result()
                save(OUT / (phase + '_timing.json'), results)
                status(phase, completed_arms=list(results), total_games=len(arms)*rounds*2)
                print(phase, arm, 'complete', flush=True)
        assert all(digest(OUT/p) == h for p,h in locked.items())
        assert all(digest(ROOT/p) == h for p,h in build['protected_sha256'].items())

    try:
        arms = list(MODELS)
        batch('screen', arms, 30, 327002)
        screen, screen_maps = analyze('screen', arms, 30, old_maps)
        best = max(arms, key=lambda a: (screen['results'][a]['combined']['totals']['win'],
                    screen['results'][a]['combined']['totals']['score'], -arms.index(a)))
        baseline = screen['results']['adopted']['combined']['totals']
        score = screen['results'][best]['combined']['totals']
        advance = best != 'adopted' and score['win']-baseline['win'] >= 3 and score['score'] >= baseline['score']
        selected = best if advance else 'adopted'
        save(OUT / 'selection.json', dict(selected=selected, advance=advance, screen_best=best,
             frozen_at=datetime.now(timezone.utc).isoformat(), plan_sha256=digest(ROOT/'FINAL_CHECKPOINT_NOTES.md')))
        holdout_arms = ['adopted', selected] if advance else ['adopted']
        batch('holdout', holdout_arms, 60, 337002)
        holdout, _ = analyze('holdout', holdout_arms, 60, old_maps | screen_maps)
        promote = False
        if advance:
            delta = holdout['comparisons'][selected]
            promote = delta['win']['paired_95ci'][0] > 0 and delta['score']['difference'] >= 0
            promote = promote and all(holdout['results'][selected][s]['totals']['win'] >=
                  holdout['results']['adopted'][s]['totals']['win'] for s in SCENES)
        save(OUT / 'decision.json', dict(recommended=selected if promote else 'adopted',
            promotion_evidence_passed=promote, automatically_deployed=False, trained_games=0,
            total_evaluation_games=180+120*len(holdout_arms),
            note='One development screen; one untouched holdout. No further checkpoint search.'))
        status('complete', needs_review=True)
        print(read(OUT / 'decision.json'), holdout['results'], flush=True)
    except Exception as e:
        status('failed', error=repr(e))
        raise


if __name__ == '__main__':
    main()
