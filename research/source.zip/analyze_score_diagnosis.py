"""Score-gap and recorded-policy diagnosis; no counterfactual win claims."""
from collections import Counter, defaultdict
import gzip
import json
from pathlib import Path
import numpy as np
from agent_code.q_fighter.features import describe, blast

ROOT = Path(__file__).parent
OUT = ROOT / 'experiments/score_diagnosis_v1'


def read_rows(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


def group(row):
    enemy = max((a for n, a in row['agents'].items() if n != 'q_fighter'), key=lambda a: a['score'])
    return ('dead' if not row['survived'] else 'alive_loss' if row['score'] < enemy['score']
            else 'alive_tie' if row['score'] == enemy['score'] else 'alive_win'), enemy


def main():
    all_rows = [r for p in sorted((ROOT / 'experiments/gamma_fresh_v1/gamma_09').glob('seed_*.rounds.jsonl')) for r in read_rows(p)]
    aggregate = Counter()
    gaps = Counter()
    for row in all_rows:
        category, enemy = group(row)
        aggregate[category] += 1
        if category == 'alive_loss':
            q = row['agents']['q_fighter']
            gaps['coins'] += enemy.get('coins', 0) - q.get('coins', 0)
            gaps['kills'] += enemy.get('kills', 0) - q.get('kills', 0)
            gaps['outcollected'] += enemy.get('coins', 0) > q.get('coins', 0)
            gaps['outkilled'] += enemy.get('kills', 0) > q.get('kills', 0)
            gaps['zero_kills'] += q.get('kills', 0) == 0
    rows = read_rows(OUT / 'match.rounds.jsonl')
    reference = read_rows(ROOT / 'experiments/gamma_fresh_v1/gamma_09/seed_105001.rounds.jsonl')
    def stable(data):
        for row in data:
            for agent in row['agents'].values():
                agent.pop('time', None)
        return data
    assert stable(rows) == stable(reference)
    by_round = {r['round']: r for r in rows}
    counters = defaultdict(Counter)
    examples = defaultdict(list)
    rounds = defaultdict(Counter)
    history = defaultdict(list)
    with gzip.open(OUT / 'score_frames.jsonl.gz', 'rt') as handle:
        for line in handle:
            frame = json.loads(line)
            category, _ = group(by_round[frame['round']])
            if category != 'alive_loss':
                continue
            phase = 'late' if frame['step'] > 200 else 'early'
            c = counters[phase]
            rc = rounds[frame['round']]
            c['steps'] += 1
            c[frame['chosen']] += 1
            c['no_coins_no_crates'] += frame['visible_coins'] == 0 and frame['crates_remaining'] == 0
            c['visible_coins'] += frame['visible_coins'] > 0
            c['safe_attack_opportunity'] += frame['info']['safe'][5] and frame['info']['enemy_hits'] > 0
            own = next(a for a in frame['actions'] if a['agent'] == 'q_fighter')
            placed = 'BOMB_DROPPED' in own['events']
            if placed:
                c['bombs'] += 1
                if frame['info']['enemy_hits']:
                    c['bomb_with_enemy_on_ray'] += 1
                    state = frame['state']
                    s = {**state, 'field': np.array(state['field']), 'explosion_map': np.array(state['explosion_map'])}
                    pos = tuple(state['self'][3])
                    ray = set(blast(s['field'], pos))
                    targets = [o for o in state['others'] if tuple(o[3]) in ray]
                    escapable = []
                    for target in targets:
                        hypothetical = {**s, 'self': (*target[:3], tuple(target[3])),
                            'others': [state['self']] + [o for o in state['others'] if o[0] != target[0]],
                            'bombs': [(tuple(p), t) for p, t in state['bombs']] + [(pos, 4)]}
                        escapable.append(bool(describe(hypothetical)['safe'][:5].any()))
                    c['targeted_bombs_all_targets_static_escape'] += all(escapable)
            if phase == 'late':
                rc['steps'] += 1
                rc[frame['chosen']] += 1
                rc['no_resources'] += frame['visible_coins'] == 0 and frame['crates_remaining'] == 0
                rc['attack_opportunities'] += frame['info']['safe'][5] and frame['info']['enemy_hits'] > 0
                rc['coins'] += frame['events'].count('COIN_COLLECTED')
                rc['kills'] += frame['events'].count('KILLED_OPPONENT')
                positions = history[frame['round']]
                position = frame['state']['self'][3]
                if len(positions) >= 2 and position == positions[-2] and position != positions[-1]:
                    c['two_step_return'] += 1
                    rc['two_step_return'] += 1
                positions.append(position)
            if frame['info']['safe'][5] and frame['info']['enemy_hits'] > 0 and frame['chosen'] != 'BOMB':
                c['declined_safe_attack'] += 1
                candidates = np.array(frame['info']['safe'], dtype=bool)
                raw = np.array(frame['q'])
                adjusted = np.array(frame['adjusted_q'])
                c['declined_bomb_raw_q_strict_best'] += bool(raw[5] > max(raw[:5][candidates[:5]], default=-np.inf))
                c['removing_bomb_cost_makes_bomb_strict_best'] += bool(adjusted[5] + 1 > max(adjusted[:5][candidates[:5]], default=-np.inf))
                if len(examples['declined_attack']) < 6 and phase == 'late':
                    examples['declined_attack'].append({'round': frame['round'], 'step': frame['step'],
                        'action': frame['chosen'], 'q': frame['q'], 'adjusted_q': frame['adjusted_q'],
                        'safe': frame['info']['safe'], 'state': frame['state']})
    result = {'all_300_round_outcomes': aggregate, 'alive_loss_score_gap_to_top_opponent': gaps,
        'diagnostic_rounds': len(rows), 'diagnostic_outcomes': Counter(group(r)[0] for r in rows),
        'reference_exact_except_time': True, 'alive_loss_actions': counters, 'alive_loss_late_by_round': rounds,
        'examples': examples}
    (OUT / 'score_analysis.json').write_text(json.dumps(result, indent=2))
    print(json.dumps({k: v for k, v in result.items() if k not in ['examples', 'alive_loss_late_by_round']}, indent=2))


if __name__ == '__main__':
    main()
