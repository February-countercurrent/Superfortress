"""Verify that only episodes with an actual guard intervention can diverge."""
from pathlib import Path
from experiment_tree_fqi import read, rows
from experiment_tree_fqi_batches import save

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'experiments/tree_fqi_coin_v1'


def main():
    assert read(OUT/'status.json')['phase']=='complete'
    results={}; unchanged=0
    for scene in ('mixed','strong'):
        before=rows(OUT/'evaluation/pilot'/(scene+'.rounds.jsonl'))
        after=rows(OUT/'evaluation/coin'/(scene+'.rounds.jsonl'))
        interventions=read(OUT/'evaluation/coin'/(scene+'.timing.json'))['interventions']['details']
        rounds={r['round'] for r in interventions}
        affected=[]
        for a,b in zip(before,after):
            assert a['round']==b['round'] and a['map_hash']==b['map_hash']
            if a['round'] not in rounds:
                assert a['action_sha256']==b['action_sha256']
                for metric in ('score','win','survived','tie_for_first','steps'):
                    assert a[metric]==b[metric]
                unchanged+=1
            else:
                assert a['action_sha256']!=b['action_sha256']
                affected.append(dict(round=a['round'],
                    interventions=[r for r in interventions if r['round']==a['round']],
                    before={**{k:a[k] for k in ('score','win','survived')},
                        **{k:a['agents']['tree_fqi'].get(k,0) for k in ('coins','kills','suicides','move_collisions')}},
                    after={**{k:b[k] for k in ('score','win','survived')},
                        **{k:b['agents']['tree_fqi'].get(k,0) for k in ('coins','kills','suicides','move_collisions')}}))
        results[scene]=affected
    focal=read(OUT/'focal_replay.json')['candidate_observations']
    assert [r['step'] for r in focal]==[68,69,70,71]
    assert [r['selected'] for r in focal]==[4,4,2,2]
    assert focal[2]['prior_waits']==2 and focal[3]['score']==focal[2]['score']+1
    assert focal[3]['position']==[7,2] and [7,2] not in focal[3]['coins']
    assert not any(r['changed'] for r in rows(OUT/'mechanism/coin/strong.policy.jsonl')
                   if r['round']==38 and r['step']<70)
    value=dict(unintervened_games=unchanged,unintervened_actions_and_outcomes_identical=True,
        focal_wait_reduced_from_27_to_2=True,affected_games=results,
        note='Direct next-step coin collection does not imply a larger final score or a win; full interaction changes after an intervention.')
    save(OUT/'intervention_audit.json',value)
    print(value)


if __name__=='__main__':
    main()
