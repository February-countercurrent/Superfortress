"""Two further matched training seeds; common fresh maps for all three pairs."""
import json
from pathlib import Path
import shutil
import sys
import numpy as np
from experiment_linear import ENV
from agent_code.q_linear.callbacks import BLOCKS
from agent_code.q_linear.features import ACTIONS
import run_fighter_experiment as runner

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'experiments/linear_multiseed_v1'
SEEDS = [27001, 28001, 29001]
EVAL = [('mixed', ['rule_based_agent', 'coin_collector_agent', 'peaceful_agent'], 37002),
        ('strong', ['rule_based_agent'] * 3, 37003)]


def main():
    OUT.mkdir(parents=True, exist_ok=False)
    workspace = OUT / 'workspace'
    shutil.copytree(ROOT, workspace, ignore=shutil.ignore_patterns(
        '.git', 'experiments', 'release', 'logs', '__pycache__'))
    (workspace / 'logs').mkdir(exist_ok=True)
    runner.ROOT = workspace
    config = dict(training_seeds=SEEDS, new_training_seeds=SEEDS[1:],
        rounds_per_training=300, evaluation_rounds=100,
        evaluation_seeds=[e[2] for e in EVAL], environment=ENV, blocks=BLOCKS,
        python=sys.version, numpy=np.__version__,
        design='First seed reuses both frozen v1 checkpoints. Two new zero-initialized matched pairs. All evaluated on common fresh maps; no seed selection.',
        limits='Three training seeds only; evaluation seeds and initial positions shared, trajectories differ. No automatic promotion.')
    (OUT / 'config.json').write_text(json.dumps(config, indent=2))
    results = {}
    def record(folder, label, model, opponents, rounds, seed, agent, train=False):
        key = f'{folder.name}/{label}'
        (OUT / 'status.json').write_text(json.dumps(dict(phase=key)))
        results[key] = runner.run(folder, label, model, opponents, rounds, seed, train, agent, environment=ENV)
        (OUT / 'summary.json').write_text(json.dumps(results, indent=2))
    try:
        for seed in SEEDS:
            folder = OUT / f'seed_{seed}'
            folder.mkdir()
            for agent, label, version in [('q_linear', 'linear', 5), ('q_fighter', 'table', 4)]:
                model = folder / f'{label}.json'
                if seed == 27001:
                    shutil.copy2(ROOT / f'experiments/linear_v1/{label}.json', model)
                else:
                    data = dict(version=version, actions=list(ACTIONS), episodes=0, q={}, prior={}, visits={})
                    if version == 5:
                        data['blocks'] = BLOCKS
                    model.write_text(json.dumps(data))
                    shutil.copy2(model, folder / f'{label}_initial.json')
                    record(folder, label + '_training', model, EVAL[0][1], 300, seed, agent, True)
                for scenario, opponents, eval_seed in EVAL:
                    record(folder, label + '_' + scenario, model, opponents, 100, eval_seed, agent)
        folder = OUT / 'reference'
        folder.mkdir()
        for scenario, opponents, seed in EVAL:
            record(folder, 'final_' + scenario, workspace / 'agent_code/q_final/model.json', opponents, 100, seed, 'q_final')
        (OUT / 'status.json').write_text(json.dumps(dict(phase='analyzing')))
        from analyze_linear_multiseed import main as analyze
        analyze()
        (OUT / 'status.json').write_text(json.dumps(dict(phase='complete')))
    except Exception as exc:
        (OUT / 'status.json').write_text(json.dumps(dict(phase='failed', error=repr(exc))))
        raise


if __name__ == '__main__':
    main()
