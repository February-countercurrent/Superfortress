"""Paired offline policy ranking on identical historical crate observations."""
import gzip
import hashlib
import json
from pathlib import Path
import numpy as np
from agent_code.q_dynamic.callbacks import active_tiles as global_tiles
from agent_code.q_conditioned.callbacks import active_tiles as conditional_tiles

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'experiments/conditioned_v1'
NAMES = ['initial', 'control', 'conditioned']


def main():
    for filename in ['features.py', 'escape.py', 'dynamic.py']:
        paths = [ROOT / f'agent_code/{agent}/{filename}' for agent in ['q_dynamic','q_conditioned']]
        assert paths[0].read_bytes() == paths[1].read_bytes()
    results = {}
    for seed in [27001,28001,29001]:
        folder = OUT / f'seed_{seed}'
        paths = [folder/'control_initial.json',folder/'control.json',folder/'conditioned.json']
        weights = [{tuple(map(int,k.split(','))):np.array(v) for k,v in json.loads(p.read_text())['q'].items()} for p in paths]
        samples = []
        with gzip.open(ROOT / f'experiments/resource_diagnosis_v1/seed_{seed}/score_frames.jsonl.gz','rt') as handle:
            for line in handle:
                f = json.loads(line)
                info = f['info']
                if info['target'] != 2 or info['threatened'] or info['yield'] <= 0 or not f['candidate_mask'][5]:
                    continue
                key = tuple(info['key'])
                mask = np.array(f['candidate_mask'],dtype=bool)
                costs = np.array(f['costs'])
                rows = []
                for i,w in enumerate(weights):
                    tiles = conditional_tiles(key) if i==2 else global_tiles(key)
                    blocks = np.array([w.get(t,np.zeros(6)) for t in tiles])
                    q = blocks.sum(axis=0)
                    if i==0:
                        np.testing.assert_allclose(q,f['q'],atol=1e-10,rtol=1e-10)
                    scores = q-costs
                    best = mask & np.isclose(scores, scores[mask].max())
                    competitors = mask.copy()
                    competitors[5] = False
                    strongest_other = int(np.argmax(np.where(competitors,scores,-np.inf)))
                    rows.append(dict(bomb_in_best=bool(best[5]), bomb_probability=float(best[5]/best.sum()),
                        bomb_margin=float(scores[5]-scores[strongest_other]),
                        bias_bomb_minus_competitor=float(blocks[0,5]-blocks[0,strongest_other]),
                        other_blocks_bomb_minus_competitor=float((blocks[1:,5]-blocks[1:,strongest_other]).sum()),
                        best_actions=np.flatnonzero(best).tolist(), strongest_other=strongest_other))
                samples.append(dict(round=f['round'],step=f['step'],key=key,mask=mask.tolist(),costs=costs.tolist(),policies=rows))
        unique = {}
        for sample in samples:
            # One weight per exact decision context to expose loop frequency bias.
            signature = (sample['key'],tuple(sample['mask']),tuple(sample['costs']))
            unique.setdefault(signature,sample)
        def aggregate(data):
            return {name:{metric:float(np.mean([s['policies'][i][metric] for s in data]))
                for metric in ['bomb_probability','bomb_margin','bias_bomb_minus_competitor','other_blocks_bomb_minus_competitor']}
                for i,name in enumerate(NAMES)}
        reversals = []
        for s in unique.values():
            a,b,c = s['policies']
            if b['bomb_in_best'] != c['bomb_in_best'] and len(reversals)<6:
                reversals.append(s)
        results[str(seed)] = dict(opportunities=len(samples),unique_contexts=len(unique),
            observation_weighted=aggregate(samples),unique_context_weighted=aggregate(list(unique.values())),
            conditioned_loses_control_bomb_count=sum(s['policies'][1]['bomb_in_best'] and not s['policies'][2]['bomb_in_best'] for s in samples),
            conditioned_gains_control_bomb_count=sum(not s['policies'][1]['bomb_in_best'] and s['policies'][2]['bomb_in_best'] for s in samples),
            examples=reversals,checkpoint_sha256={n:hashlib.sha256(p.read_bytes()).hexdigest() for n,p in zip(NAMES,paths)})
    results['limitations'] = ('Offline action rankings on old trajectories, not new game outcomes or proof that BOMB is optimal. '
        'Step weighting repeats oscillatory states; unique context weighting is provided too. '
        'Individual block contributions are parameterization-dependent and redundant. '
        'Training paths diverged; this does not isolate the causal effect of one weight update.')
    (OUT/'decision_comparison.json').write_text(json.dumps(results,indent=2))
    print(json.dumps({k:{n:v for n,v in d.items() if n not in ['examples','checkpoint_sha256']} for k,d in results.items() if isinstance(d,dict)},indent=2))


if __name__ == '__main__':
    main()
