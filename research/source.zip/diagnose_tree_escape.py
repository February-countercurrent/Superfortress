"""Reproduce frozen joint-tree games before designing escape interventions."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
import gzip
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

from experiment_tree_fqi import read, rows, SCENES
from experiment_tree_fqi_batches import clean_environment, save
from finalize_guard_release import digest, framework

ROOT = Path(__file__).resolve().parent
PREVIOUS = ROOT/'experiments/tree_tactical_v3'
OUT = ROOT/'experiments/tree_escape_diagnosis_v1'
MODEL = PREVIOUS/'selected/model.pkl'
SEEDS = dict(mixed=567102,strong=567103)


def compact(r):
    return dict(step=r['step'],position=r['state']['self'][3],action=r['action'],
        q=[round(x,3) for x in r['q']],safe=r['safe'],mask=r['mask'],
        fallback=r['fallback'],threatened=r['threatened'],geometry=r['geometry'],
        bombs=r['state']['bombs'],others=[o[3] for o in r['state']['others']],
        after=r['after'])


def analyze(path):
    with gzip.open(path,'rt',encoding='utf-8') as f: rr=[json.loads(s) for s in f]
    deaths=[]
    for r in rr:
        if not r['after']['dead']: continue
        history=[x for x in rr if x['round']==r['round'] and x['step']<=r['step']]
        bombs=[x['step'] for x in history if 'BOMB_DROPPED' in x['after']['events']]
        deaths.append(dict(round=r['round'],step=r['step'],suicide='KILLED_SELF' in r['after']['events'],
            last_bomb_step=bombs[-1] if bombs else None,window=[compact(x) for x in history[-9:]]))
    return dict(actions=len(rr),deaths=deaths,
        threatened_actions=sum(x['threatened'] for x in rr),
        threatened_waits=sum(x['threatened'] and x['action']==4 for x in rr),
        threatened_fallback=sum(x['threatened'] and x['fallback'] for x in rr),
        no_static_escape=sum(not any(x['safe']) for x in rr))


def main():
    OUT.mkdir(parents=True,exist_ok=False)
    start=time.monotonic()
    def status(phase,**kwargs):
        save(OUT/'status.json',dict(phase=phase,pid=os.getpid(),
            updated_at=datetime.now(timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-start,**kwargs))
        print(phase,kwargs,flush=True)
    try:
        status('preparing')
        protected=read(PREVIOUS/'data_config.json')['protected_sha256'].copy()
        for directory in (PREVIOUS,ROOT/'agent_code/tree_tactical'):
            for p in directory.rglob('*'):
                if p.is_file() and '__pycache__' not in p.parts and 'logs' not in p.parts:
                    protected[str(p.relative_to(ROOT))]=digest(p)
        for name in ('CURRENT_SUBMISSION.json','CURRENT_CANDIDATE.json',
                     'release/Superfortress_v1/final-project-agent-code.zip'):
            protected[name]=digest(ROOT/name)
        assert all(digest(ROOT/n)==h for n,h in protected.items())
        assert digest(MODEL)=='397045e64700cb64b3413c1145c3ace4bad258e53ed8db2657feaed8d1ce5ed9'
        names=['trace_tree_escape_match.py','diagnose_tree_escape.py',
               'TREE_ESCAPE_DIAGNOSIS_PLAN.md','run_tree_fqi_match.py']
        locked={n:digest(ROOT/n) for n in names}
        save(OUT/'config.json',dict(seeds=SEEDS,rounds=60,policy_seed=42,
            model_sha256=digest(MODEL),protected_sha256=protected,source_sha256=locked))
        for scene in SCENES:
            workspace=OUT/'workspaces'/scene
            framework(workspace)
            for name in names[:2]+['run_tree_fqi_match.py']:
                shutil.copy2(ROOT/name,workspace/name)
            shutil.copytree(ROOT/'agent_code/tree_tactical',workspace/'agent_code/tree_fqi',
                ignore=shutil.ignore_patterns('__pycache__','logs','model.pkl'))
            shutil.copy2(MODEL,workspace/'agent_code/tree_fqi/model.pkl')
        def replay(scene):
            folder=OUT/'replay'/scene; folder.mkdir(parents=True)
            workspace=OUT/'workspaces'/scene
            cmd=[sys.executable,'-X','utf8','trace_tree_escape_match.py','--trace',str(folder/'trace.jsonl.gz'),
                 '--agent','tree_fqi','--model',str(workspace/'agent_code/tree_fqi/model.pkl'),
                 '--output',str(folder/'match.json'),'--rounds','60','--seed',str(SEEDS[scene]),
                 '--policy-seed','42','--opponents',*SCENES[scene]]
            with (folder/'run.log').open('w',encoding='utf-8') as log:
                subprocess.run(cmd,cwd=workspace,env=clean_environment(),stdout=log,stderr=subprocess.STDOUT,
                               check=True,timeout=1800)
            before=rows(PREVIOUS/'holdout/joint'/f'{scene}.rounds.jsonl')
            after=rows(folder/'match.rounds.jsonl')
            assert len(before)==len(after)==60
            for a,b in zip(before,after):
                for key in ('round','map_hash','action_sha256','score','win','survived','steps'):
                    assert a[key]==b[key],(scene,a['round'],key)
            assert read(folder/'match.latency.json')['over_500ms']==0
            analysis=analyze(folder/'trace.jsonl.gz')
            assert analysis['actions']==sum(x['agents']['tree_fqi']['steps'] for x in after)
            assert sum(d['suicide'] for d in analysis['deaths'])==sum(x['agents']['tree_fqi'].get('suicides',0) for x in after)
            save(folder/'analysis.json',analysis)
            return analysis
        status('replaying',games=120)
        analyses={}
        with ThreadPoolExecutor(max_workers=2) as pool:
            tasks={pool.submit(replay,s):s for s in SCENES}
            for task in as_completed(tasks):
                scene=tasks[task];analyses[scene]=task.result()
                status('replaying',completed=list(analyses))
        save(OUT/'diagnosis.json',analyses)
        assert all(digest(ROOT/n)==h for n,h in protected.items())
        assert all(digest(ROOT/n)==h for n,h in locked.items())
        save(OUT/'verification.json',dict(verified=True,identical_games=120,
            protected_files=len(protected),protected_unchanged=True,sources_unchanged=True))
        status('diagnosis_complete',verified=True)
    except Exception as e:
        status('failed',error=repr(e));raise


if __name__=='__main__': main()
