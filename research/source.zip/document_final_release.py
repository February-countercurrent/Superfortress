"""Create portable reproduction instructions and final evaluation tables."""
import json
from pathlib import Path
import shutil
import numpy as np

ROOT = Path(__file__).parent.resolve()
P = ROOT / 'experiments/final_selection_v1'
R = ROOT / 'release/final_v1'
m = json.loads((R / 'manifest.json').read_text())
results = json.loads((P / 'results.json').read_text())
held = json.loads((P / 'holdout.json').read_text())
mode = m['selected_mode']
for phase in ['strong', 'mixed', 'duel', 'holdout']:
    rows = [[json.loads(x) for x in (P / v / f'{phase}.rounds.jsonl').read_text().splitlines()] for v in ['full', 'off']]
    assert len(rows[0]) == len(rows[1])
    assert all(a['map_hash'] == b['map_hash'] for a, b in zip(*rows))
    if phase == 'holdout':
        indices = np.random.default_rng(982).integers(len(rows[0]), size=(20000, len(rows[0])))
        stats = {}
        for key in ['score', 'win', 'survived']:
            d = np.array([float(b[key]) - float(a[key]) for a, b in zip(*rows)])
            stats[key] = {'off_minus_full': float(d.mean()), 'interval95': np.quantile(d[indices].mean(axis=1), [.025, .975]).tolist()}
(R / 'final_comparison.json').write_text(json.dumps({'validation': results, 'holdout': held, 'holdout_paired_bootstrap': stats}, indent=2))
repro = R / 'reproduction'
repro.mkdir(exist_ok=True)
shutil.copy2(ROOT / 'run_fighter_match.py', repro / 'run_fighter_match.py')
shutil.copy2(P / mode / 'holdout.rounds.jsonl', repro / 'expected_holdout.rounds.jsonl')
for name in ['config.json', 'selection.json', 'results.json', 'holdout.json']:
    shutil.copy2(P / name, repro / name)
shutil.copy2(ROOT / 'finalize_agent.py', repro / 'finalize_agent.py')
table = '\n'.join(f"| {v} | {r['mean_score']:.2f} | {r['win_rate']:.1%} | {r['survival_rate']:.1%} | {r['suicide_rate']:.1%} |" for v,r in held.items())
readme = f'''# Frozen Bomberman agent: q_final

Selected mode: **{mode}**. One inference-only tabular Q-learning agent. No training, network calls or multiprocessing during inference. AI-assisted implementation; student review and understanding remain necessary.

## Submission

`final-project-agent-code.zip` contains exactly one `q_final/` directory with callbacks, helper modules, policy.json and model.json. Do not add experiments, logs or reports. Nothing has been uploaded or submitted automatically.

Copy the unzipped `q_final` directory into the official framework's `agent_code/` directory. Keep its name for exact reproduction. Use Python 3.10.9; tested package versions are in requirements-eval.txt. Framework commit: `0f55c1d207e586e6fe6db95e64302ed32281e370` of https://github.com/ukoethe/bomberman_rl.

From the framework root:

```powershell
python -m pip install -r PATH_TO_RELEASE/requirements-eval.txt
python main.py play --no-gui --agents q_final rule_based_agent rule_based_agent rule_based_agent --scenario classic --n-rounds 10 --seed 135001
```

The ordinary game command is a smoke/demo run, not exact table reproduction: official opponents initialize their RNG differently. For exact evaluation, copy reproduction/run_fighter_match.py into the framework root, then run:

```powershell
python run_fighter_match.py --agent q_final --model agent_code/q_final/model.json --output final_reproduction.json --rounds 100 --seed 135001 --opponents rule_based_agent rule_based_agent rule_based_agent
```

Use a new output filename each run; the harness appends per-round JSONL. Compare final_reproduction.rounds.jsonl with reproduction/expected_holdout.rounds.jsonl, ignoring only agent time fields. Compare the full 100-round sequence from a fresh process: the agent's RNG starts at42 and advances across rounds. Partial reruns of later rounds need not match.

The harness uses the unchanged official rules, resetting map/opponent RNG per round. It records agent statistics and does not train. Reproduction matches are conditioned on the tested Python/NumPy/framework environment; wall-clock times are not expected to match.

## Frozen policy

- 16-feature tabular Q table, 14-feature resource prior fallback.
- Six actions, timed bomb safety mask, escape-distance and opponent-contest costs.
- Agent tie-breaking seed42; no epsilon exploration. Cost mode {mode}; details in q_final/policy.json.
- Reads only sibling model.json/policy.json. QF_* environment variables cannot change final inference.
- No training callbacks included. Use archived experiment source for retraining; do not run this submission with --train.

## Selection and final test

Both fixed candidates evaluated for40 rounds each against three rule agents, mixed opponents, and one rule agent. Selection maximized equal-weight mean strict-win rate across the three scenarios; ties by mean score, exact ties retain full. Selection was frozen before the following new100-map four-player test; no model switched after seeing it.

| Candidate | Score | Strict win | Survival | Suicide |
|---|---:|---:|---:|---:|
{table}

See final_comparison.json for all scenarios and paired confidence intervals. These compare fixed trained weights, not multiple independent training runs. Candidate evaluation uses fixed tie seed42; earlier experimental scores with other tie seeds are not interchangeable.

## Provenance and integrity

The weights originate from q_fighter's weak-opponent300-round model, then the selected learning_curve_v1 seed1501 continuation (+3000), then gamma_v1/gamma_09 continuation (+300, gamma0.9):3600 combat rounds, with an earlier resource-policy prior. Source model SHA256: `{m['files']['q_final/model.json']}`.

Training lineage and historical source/checkpoints remain in the project experiments directories; manifest.json records the source path. This release guarantees a frozen inference artifact and documents evaluation replay. It does not claim a one-command bit-identical reconstruction of the entire earlier training curriculum from scratch.

manifest.json lists the SHA256 of every submitted file; archive.json records the zip digest. The archive uses fixed entry timestamps. verification/ contains packaged smoke equality and sampled timing checks. Timings are measurements, not universal worst-case bounds.

This is the single-agent code submission. It does not complete the separate project report or its requirement to compare different model methods.
'''
(R / 'README.md').write_text(readme, encoding='utf-8')
print(json.dumps({'selected': mode, 'holdout': held, 'paired': stats}, indent=2))
