"""Verify map pairing and summarize the one-time frozen-model holdout."""
import argparse
import json
from pathlib import Path

import numpy as np


def read_rows(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('experiment', type=Path)
    args = parser.parse_args()
    p = args.experiment
    selection = json.loads((p / 'selection.json').read_text())
    for name in ('death_25', 'death_50'):
        for matchup in ('duel', 'four_player'):
            a = read_rows(p / f'baseline_{matchup}.rounds.jsonl')
            b = read_rows(p / f'{name}_{matchup}.rounds.jsonl')
            assert [r['map_hash'] for r in a] == [r['map_hash'] for r in b], 'Unpaired validation maps'
    a = read_rows(p / 'holdout_baseline.rounds.jsonl')
    if selection['selected'] == 'baseline':
        report = {'selected': 'baseline', 'holdout_rounds': len(a),
                  'note': 'No challenger qualified. Only baseline was evaluated on the holdout; no model-difference estimate is available.'}
        (p / 'holdout_analysis.json').write_text(json.dumps(report, indent=2))
        print(json.dumps(report, indent=2))
        return
    b = a if selection['selected'] == 'baseline' else read_rows(p / 'holdout_selected.rounds.jsonl')
    assert [r['map_hash'] for r in a] == [r['map_hash'] for r in b], 'Unpaired holdout maps'
    delta = np.array([y['score'] - x['score'] for x, y in zip(a, b)], dtype=float)
    rng = np.random.default_rng(20260919)
    means = delta[rng.integers(0, len(delta), size=(10000, len(delta)))].mean(axis=1)
    report = {'selected': selection['selected'], 'paired_rounds': len(delta),
              'mean_score_difference': float(delta.mean()),
              'paired_bootstrap_95_percent_interval': np.quantile(means, [.025, .975]).tolist(),
              'note': 'Uncertainty across these evaluation rounds only; not across independent training runs.'}
    (p / 'holdout_analysis.json').write_text(json.dumps(report, indent=2))
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
