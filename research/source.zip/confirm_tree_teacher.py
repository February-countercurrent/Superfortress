"""Fixed 600-map independent confirmation of the retained teacher-tree weights."""
from concurrent.futures import ThreadPoolExecutor,as_completed
from datetime import datetime,timezone
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import numpy as np

from experiment_tree_fqi import SCENES,read,rows,summarize
from experiment_tree_fqi_batches import save,clean_environment
from finalize_guard_release import digest,framework

ROOT=Path(__file__).resolve().parent
PRIOR=ROOT/'experiments/tree_teacher_v1'
OUT=ROOT/'experiments/tree_teacher_confirmation_v1'
SEEDS={1:dict(mixed=597002,strong=597003),2:dict(mixed=597102,strong=597103),
       3:dict(mixed=597202,strong=597203)}
MODELS={'baseline':ROOT/'agent_code/tree_guard/model.pkl','teacher':PRIOR/'fit/model.pkl'}
EXPECTED={'baseline':'397045e64700cb64b3413c1145c3ace4bad258e53ed8db2657feaed8d1ce5ed9',
          'teacher':'b549995f80ab880bb3b64720bebf9d5db7f5186dcf71c67a15423174fe22bea1'}
ARMS=tuple(MODELS)
JOBS=[(batch,scene,arm) for batch in SEEDS for scene in SCENES for arm in ARMS]


def job_name(batch,scene,arm):return f'batch_{batch}_{scene}_{arm}'


def run(batch,scene,arm):
    name=job_name(batch,scene,arm);workspace=OUT/'workspaces'/name
    output=OUT/'evaluation'/f'batch_{batch}'/arm/(scene+'.json')
    output.parent.mkdir(parents=True,exist_ok=True)
    assert not output.with_suffix('.rounds.jsonl').exists()
    model=workspace/'agent_code/tree_fqi/model.pkl';tick=time.monotonic()
    with output.with_suffix('.log').open('w',encoding='utf-8') as log:
        subprocess.run([sys.executable,'-X','utf8','run_tree_fqi_match.py','--agent','tree_fqi',
            '--model',str(model),'--output',str(output),'--rounds','100','--seed',str(SEEDS[batch][scene]),
            '--policy-seed','42','--opponents',*SCENES[scene]],cwd=workspace,env=clean_environment(),
            stdout=log,stderr=subprocess.STDOUT,check=True,timeout=3600)
    assert digest(model)==EXPECTED[arm]
    assert b'Traceback' not in output.with_suffix('.log').read_bytes()
    rr=rows(output.with_suffix('.rounds.jsonl'));assert len(rr)==100
    latency=read(output.with_suffix('.latency.json'));assert latency['over_500ms']==0
    result=dict(batch=batch,scene=scene,arm=arm,games=100,seed=SEEDS[batch][scene],policy_seed=42,
        seconds=time.monotonic()-tick,latency=latency,model_sha256=digest(model))
    save(output.with_suffix('.timing.json'),result)
    return result


def comparisons(strata,seed):
    """Strata contain paired candidate/control records; retain sample weights."""
    rng=np.random.default_rng(seed);result={}
    sizes=np.array([len(c) for c,b in strata]);weights=sizes/sizes.sum()
    for metric in ('win','score'):
        differences=[np.array([float(c[metric])-float(b[metric]) for c,b in zip(candidate,base)])
                     for candidate,base in strata]
        boot=sum(w*d[rng.integers(0,len(d),(10000,len(d)))].mean(axis=1)
                 for w,d in zip(weights,differences))
        result[metric]=dict(difference=float(sum(w*d.mean() for w,d in zip(weights,differences))),
            paired_95ci=np.quantile(boot,[.025,.975]).tolist())
    candidate_only=baseline_only=both=neither=0
    for candidate,baseline in strata:
        for c,b in zip(candidate,baseline):
            candidate_only+=bool(c['win'] and not b['win'])
            baseline_only+=bool(b['win'] and not c['win'])
            both+=bool(c['win'] and b['win'])
            neither+=bool(not c['win'] and not b['win'])
    result['paired_wins']=dict(candidate_only=candidate_only,baseline_only=baseline_only,both=both,neither=neither)
    return result


def analyze(forbidden):
    data={};seen=set()
    for batch in SEEDS:
        data[batch]={}
        for scene in SCENES:
            data[batch][scene]={}
            for arm in ARMS:
                rr=rows(OUT/'evaluation'/f'batch_{batch}'/arm/(scene+'.rounds.jsonl'))
                assert len(rr)==100 and [r['round'] for r in rr]==list(range(1,101))
                assert all(r['seed']==SEEDS[batch][scene] and r['policy_seed']==42 for r in rr)
                hashes={r['map_hash'] for r in rr}
                assert len(hashes)==100 and not hashes&forbidden
                data[batch][scene][arm]=rr
            base=data[batch][scene]['baseline'];candidate=data[batch][scene]['teacher']
            assert [r['map_hash'] for r in base]==[r['map_hash'] for r in candidate]
            maps={r['map_hash'] for r in base};assert not seen&maps;seen.update(maps)
    assert len(seen)==600
    by_scene={};by_batch={};combined={};pooled={}
    for arm in ARMS:
        by_scene[arm]={s:summarize(sum([data[b][s][arm] for b in SEEDS],[]),'tree_fqi') for s in SCENES}
        by_batch[arm]={str(b):summarize(sum([data[b][s][arm] for s in SCENES],[]),'tree_fqi') for b in SEEDS}
        rr=sum([data[b][s][arm] for b in SEEDS for s in SCENES],[])
        combined[arm]=summarize(rr,'tree_fqi')
        previous=sum([rows(PRIOR/'evaluation'/arm/(s+'.rounds.jsonl')) for s in SCENES],[])
        pooled[arm]=summarize(previous+rr,'tree_fqi')
    strata=[(data[b][s]['teacher'],data[b][s]['baseline']) for b in SEEDS for s in SCENES]
    primary=comparisons(strata,597900)
    historical=[(rows(PRIOR/'evaluation/teacher'/(s+'.rounds.jsonl')),
                 rows(PRIOR/'evaluation/baseline'/(s+'.rounds.jsonl'))) for s in SCENES]
    cumulative=comparisons(historical+strata,597901)
    result=dict(primary=dict(games_per_arm=600,by_scene=by_scene,by_batch=by_batch,
        combined=combined,teacher_minus_baseline=primary),
        descriptive_cumulative=dict(games_per_arm=720,combined=pooled,teacher_minus_baseline=cumulative),
        verified_new_paired_maps=600,prior_unique_maps=len(forbidden))
    save(OUT/'analysis.json',result)
    b,c=combined['baseline'],combined['teacher']
    positive=(c['totals']['win']>b['totals']['win'] and c['mean_score']>b['mean_score']
              and c['totals']['suicides']<=b['totals']['suicides'])
    strong=positive and primary['win']['paired_95ci'][0]>0
    decision=dict(recommend_upgrade=strong,positive_but_uncertain=positive and not strong,
        win_interval_supports_improvement=primary['win']['paired_95ci'][0]>0,
        candidate_retained=True,default_tree_unchanged=True,submission_unchanged=True,
        status='supported_upgrade' if strong else 'positive_uncertain' if positive else 'upgrade_not_supported',
        basis='New600-map primary sample only; initial120 and cumulative720 are descriptive')
    save(OUT/'decision.json',decision)
    return result,decision


def main():
    OUT.mkdir(parents=True,exist_ok=False);tick=time.monotonic()
    def status(phase,**kw):
        save(OUT/'status.json',dict(phase=phase,pid=os.getpid(),elapsed_seconds=time.monotonic()-tick,
            updated_at=datetime.now(timezone.utc).isoformat(),**kw));print(phase,kw,flush=True)
    try:
        status('preparing')
        assert read(PRIOR/'verification.json')['verified']
        prior=read(PRIOR/'config.json');protected={**prior['protected_sha256'],**prior['source_sha256']}
        for p in PRIOR.rglob('*'):
            if p.is_file() and '__pycache__' not in p.parts and 'logs' not in p.parts:
                protected[str(p.relative_to(ROOT))]=digest(p)
        assert all(digest(ROOT/n)==h for n,h in protected.items())
        assert all(digest(p)==EXPECTED[a] for a,p in MODELS.items())
        current=read(ROOT/'CURRENT_TREE_RESEARCH.json')
        assert all(digest(ROOT/n)==h for n,h in current['code_sha256'].items())
        teacher=read(PRIOR/'candidate.json')
        assert all(digest(ROOT/n)==h for n,h in teacher['code_sha256'].items())
        retained=ROOT/'retained_candidates/tree_teacher_v1.json'
        assert not retained.exists()
        save(retained,dict(retained_by_user=True,user_instruction='保留我们进行下一步',
            retained_at=datetime.now(timezone.utc).isoformat(),model=str(MODELS['teacher'].relative_to(ROOT)),
            model_sha256=EXPECTED['teacher'],source_candidate='experiments/tree_teacher_v1/candidate.json',
            next_step='Frozen independent600-map paired confirmation',current_default_replaced=False))
        protected[str(retained.relative_to(ROOT))]=digest(retained)
        names=['confirm_tree_teacher.py','TREE_TEACHER_CONFIRMATION_PLAN.md','run_tree_fqi_match.py',
               'experiment_tree_fqi.py','experiment_tree_fqi_batches.py','finalize_guard_release.py']
        locked={n:digest(ROOT/n) for n in names}
        locked.update(current['code_sha256'])
        for name in locked:
            target=OUT/'sources'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/name,target)
        forbidden=set();prior_files=0
        for path in (ROOT/'experiments').rglob('*.rounds.jsonl'):
            if OUT in path.parents or 'workspaces' in path.parts:continue
            prior_files+=1
            forbidden.update(r['map_hash'] for r in rows(path) if 'map_hash' in r)
        save(OUT/'config.json',dict(protected_sha256=protected,source_sha256=locked,
            models=EXPECTED,seeds=SEEDS,policy_seed=42,rounds_per_scene_per_batch=100,
            games_per_arm=600,primary_bootstrap_seed=597900,cumulative_bootstrap_seed=597901,
            bootstrap_samples=10000,workers=4,training=False,prior_result_files=prior_files,
            prior_unique_maps=len(forbidden),initial120_not_primary=True))
        for batch,scene,arm in JOBS:
            workspace=OUT/'workspaces'/job_name(batch,scene,arm);framework(workspace)
            shutil.copy2(ROOT/'run_tree_fqi_match.py',workspace/'run_tree_fqi_match.py')
            shutil.copytree(ROOT/'agent_code/tree_guard',workspace/'agent_code/tree_fqi',
                ignore=shutil.ignore_patterns('__pycache__','logs','model.pkl'))
            shutil.copy2(MODELS[arm],workspace/'agent_code/tree_fqi/model.pkl')
            assert all(digest(workspace/'agent_code/tree_fqi'/Path(n).name)==h for n,h in current['code_sha256'].items())
        status('evaluating',agent_games=1200,paired_maps=600,completed_jobs=[])
        timings={}
        with ThreadPoolExecutor(max_workers=4) as pool:
            tasks={pool.submit(run,*job):job for job in JOBS}
            for task in as_completed(tasks):
                job=tasks[task];name=job_name(*job);timings[name]=task.result()
                save(OUT/'timings.json',timings)
                status('evaluating',agent_games=1200,completed_jobs=list(timings),completed_games=100*len(timings))
        result,decision=analyze(forbidden)
        assert all(digest(ROOT/n)==h for n,h in protected.items())
        assert all(digest(ROOT/n)==h for n,h in locked.items())
        assert all(digest(p)==EXPECTED[a] for a,p in MODELS.items())
        for batch,scene,arm in JOBS:
            path=OUT/'workspaces'/job_name(batch,scene,arm)/'agent_code/tree_fqi'
            assert digest(path/'model.pkl')==EXPECTED[arm]
            assert all(digest(path/Path(n).name)==h for n,h in current['code_sha256'].items())
        result_files={str(p.relative_to(OUT)):digest(p) for p in (OUT/'evaluation').rglob('*.jsonl')}
        save(OUT/'verification.json',dict(verified=True,protected_files=len(protected),protected_unchanged=True,
            sources_unchanged=True,identical_inference_code=True,models_frozen=True,
            paired_new_maps=600,completed_agent_games=1200,all_predeclared_batches_completed=True,
            inference_over_500ms=0,result_sha256=result_files))
        status('complete',verified=True,win_rates={a:r['win_rate'] for a,r in result['primary']['combined'].items()},**decision)
    except Exception as e:status('failed',error=repr(e));raise


if __name__=='__main__':main()
