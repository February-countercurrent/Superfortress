"""Read-only full-round recorder, including delayed credit after own death."""
import argparse
import gzip
import json
from pathlib import Path
import sys

import numpy as np


def encode(value):
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    raise TypeError(type(value).__name__)


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--agent', required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--model', type=Path, required=True)
    p.add_argument('--rounds', type=int, default=60)
    p.add_argument('--seed', type=int, required=True)
    p.add_argument('--opponents', nargs='+', required=True)
    args = p.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    from environment import BombeRLeWorld as World
    original = {name: getattr(World, name) for name in ('new_round', 'poll_and_run_agents',
        'perform_agent_action', 'update_bombs', 'evaluate_explosions', 'do_step')}
    full = gzip.open(args.output / 'frames.jsonl.gz', 'wt', encoding='utf-8')

    def new_round(world):
        original['new_round'](world)
        world.audit_bombs, world.audit_explosions = {}, {}
        world.audit_frame = None

    def poll(world):
        world.audit_frame = dict(round=world.round, step=world.step,
            state=world.get_state_for_agent(world.agents[0]), actions=[], hits=[])
        original['poll_and_run_agents'](world)

    def perform(world, agent, action):
        before = agent.x, agent.y
        n = len(agent.events)
        original['perform_agent_action'](world, agent, action)
        for bomb in world.bombs:
            if bomb not in world.audit_bombs:
                world.audit_bombs[bomb] = dict(owner=bomb.owner.name, position=(bomb.x, bomb.y), placed=world.step)
        world.audit_frame['actions'].append(dict(agent=agent.name, before=before,
            action=action, after=(agent.x, agent.y), events=list(agent.events[n:])))

    def bombs(world):
        exploding = [b for b in world.bombs if b.timer <= 0]
        n = len(world.explosions)
        original['update_bombs'](world)
        for explosion, bomb in zip(world.explosions[n:], exploding):
            world.audit_explosions[explosion] = world.audit_bombs[bomb]

    def explosions(world):
        for explosion in world.explosions:
            if explosion.is_dangerous():
                for agent in world.active_agents:
                    if not agent.dead and (agent.x, agent.y) in explosion.blast_coords:
                        world.audit_frame['hits'].append(dict(**world.audit_explosions[explosion],
                            victim=agent.name, victim_position=(agent.x, agent.y),
                            suicide=agent is explosion.owner))
        original['evaluate_explosions'](world)

    def step(world, user_input='WAIT'):
        original['do_step'](world, user_input)
        world.audit_frame['after'] = {a.name: dict(position=(a.x, a.y), dead=a.dead,
            score=a.score, statistics=dict(a.statistics)) for a in world.agents}
        full.write(json.dumps(world.audit_frame, default=encode) + '\n')

    for name, function in [('new_round', new_round), ('poll_and_run_agents', poll),
        ('perform_agent_action', perform), ('update_bombs', bombs), ('evaluate_explosions', explosions), ('do_step', step)]:
        setattr(World, name, function)
    import run_occupancy_match
    sys.argv = ['run_occupancy_match.py', '--agent', args.agent, '--model', str(args.model),
        '--output', str(args.output / 'match.json'), '--rounds', str(args.rounds), '--seed', str(args.seed),
        '--opponents', *args.opponents]
    try:
        run_occupancy_match.main()
    finally:
        full.close()


if __name__ == '__main__':
    main()
