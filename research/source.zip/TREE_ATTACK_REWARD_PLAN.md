# Fixed narrow attack-reward ablation

User instruction: 下一步, following the unsuccessful 34-feature experiment.
One 28-feature candidate; only a training shaping term changes.

The baseline joint reward already subtracts the 1.5-per-enemy BOMB bonus for
enemies with at least two geometric exits. This experiment additionally removes
exactly 1.5 only when all of the following are true at the recorded decision:

- The executed action is BOMB and the existing static shield marks BOMB safe.
- No crate is on its blast ray, and exactly one enemy is on that ray.
- That enemy has zero/one geometric exit (so its old bonus was still present).
- The verified timed category says its escape remains possible (reduced first
  actions or unchanged), and the static shortest route off the ray is 1/2 moves.

Use the six diagnostic columns previously appended in tree_timed_v1 to label
the existing transitions; they are NOT model inputs here. The actual fit and
deployed agent remain 28-dimensional. Preserve attacks that close all modeled
escape paths, already-trapped categories, multi-target attacks, longer routes,
crate/attack combinations and every other action. All actual kill/coin/crate
and death event rewards, approach shaping and action costs remain unchanged.
This removes an existing bonus; it introduces no new bonus or punishment scale.

Sample audit before fitting: 311 affected transitions, of which 265 are in the
320 training episodes and 46 in the 80 diagnostic episodes. Both subsets use
the original episode-modulo-five split. Keep every original array except the
raw reward r unchanged; joint fitting then subtracts the original open bonus
as before. Assert selected open_attack_bonus=0 to avoid double removal.

Reuse the exact same 400 behavior games /137811 transitions, with verified
28/34 prefixes and prior full-game action-hash reproduction. No new collection
or mixing of failed 34-feature weights. Fit from zero Q using the unchanged
fit_tree_tactical.py joint mode: 20 iterations, gamma.9, 6x32 trees, depth12,
leaf8, max_features1., seed537001, D4 augmentation/mean inference, jobs2.
Fixed iteration20, no checkpoint or hyperparameter selection.

Control: retained 28-feature teacher b549995f80ab880bb3b64720bebf9d5db7f5186dcf71c67a15423174fe22bea1.
Inference source, dynamic safety, retreat, policy RNG and tree capacity match.
Fresh paired maps: mixed seed617002 x60, strong617003 x60, policyseed42.
Use official initial-map generation to exclude all historical map hashes before
evaluation; verify actual maps afterward. Four isolated jobs, single-thread
prediction per agent; run all240 agent-games regardless of partial outcomes.
Paired stratified bootstrap10000, seed617900. Report scene/pooled strict wins,
scores, coins, kills, suicides, survival, bombs, invalid actions and latency.
Positive-screen criterion: more wins AND higher score with no more suicides;
separately report whether the win CI excludes zero. No automatic adoption.

This is one hypothesis about a coarse shaping proxy, not proof that misses are
valueless. Escapable bombs can still force movement or obtain kills. Its effect
on useful attacks and total score must be measured. Historical test scores are
not the comparator for this new batch. Preserve all old models and submissions.
