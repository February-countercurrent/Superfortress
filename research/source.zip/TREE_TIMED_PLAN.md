# Frozen timed-feature retraining experiment

User instruction: 重新训练. Implements TREE_ATTACK_NEXT_PLAN.md.

One candidate: 34 features, with the original 28-feature prefix unchanged.
Codes and multi-target priority are specified in agent_code/tree_timed/README.md.
Only feature representation changes. Dynamic safety, WAIT retreat, action RNG,
quality-adjusted reward, training split and ExtraTrees capacity remain fixed.

Replay all original 400 behavior games and add descriptors outside timed act:
random mixed seed537001 (global1..100), random mixed537101 (101..200),
frozen q_guard mixed537201 policy42 (201..300), random strong567001 (301..400).
Random policy seed equals map seed. Copy every old array exactly from
experiments/tree_teacher_v1/data after checking actions and feature prefixes.
New next features come from the actual next decision; terminal next features
are zero. Verify all complete game action hashes against their original runs.

Before full replay, test geometry, all8 D4 transforms, checkpoint predictions,
2 observed random games, 2 observed teacher games, and 2 old-model games using
the extended decoder/callbacks. No test outcome may select or tune parameters.

Fit from zero Q: 320 fit /80 diagnostic games (episode modulo5), seed537001,
20 FQI iterations, gamma0.9, six heads x32 ExtraTrees, depth12, leaf8,
max_features1.0, D4 augmentation and mean inference, 2 offline fit jobs.
Use iteration20 regardless of intermediate RMSE. Preserve final model hash.

Paired evaluation: frozen teacher weights b549995f80ab880bb3b64720bebf9d5db7f5186dcf71c67a15423174fe22bea1
versus new weights; 60 mixed maps seed607002, 60 strong maps seed607003,
policyseed42. Precompute initial maps using official build_arena and check
against all historical recorded map hashes before evaluation. No early stop.
Four isolated offline evaluation jobs, single-thread prediction per agent.

Report strict wins, scores, coins, kills, suicides, survival, invalid actions,
and inference latency. Paired stratified bootstrap10000, seed607900.
Promising = more wins and higher score without more suicides; separately
report whether the win difference interval excludes zero. No automatic adoption.
Original submitted Superfortress and both retained research weights are protected.
