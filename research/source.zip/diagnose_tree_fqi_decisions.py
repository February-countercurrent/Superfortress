"""Replay all previous strong-opponent games before designing an intervention."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
import gzip
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

import numpy as np

from experiment_tree_fqi import read, rows
from experiment_tree_fqi_batches import clean_environment, save
from finalize_guard_release import digest, framework

ROOT = Path(__file__).resolve().parent
PREVIOUS = ROOT/'experiments/tree_fqi_random_v1'
OUT = ROOT/'experiments/tree_fqi_decisions_v1'
MODELS = {'random': PREVIOUS/'fit/model.pkl',
          'pilot': ROOT/'experiments/tree_fqi_v1/fit/model.pkl'}


def analyze_trace(path):
    with gzip.open(path, 'rt', encoding='utf-8') as handle:
        rr = [json.loads(line) for line in handle]
    assert len({r['round'] for r in rr}) == 60
    x = np.array([r['key'] for r in rr])
    mask = np.array([r['mask'] for r in rr], bool)
    action = np.array([r['action'] for r in rr])
    calm = ~np.array([r['threatened'] for r in rr])
    progress = np.array([r['progress'] for r in rr])
    context = {
        'all': np.ones(len(rr), bool),
        'calm': calm,
        'threatened': ~calm,
        'calm_progress_available': calm & ((progress > 0) & mask[:, :4]).any(axis=1),
        'calm_attack_bomb_available': calm & mask[:, 5] & (x[:, 14] > 0),
        'calm_attack_bomb_enemy_few_exits': calm & mask[:, 5] & (x[:, 14] > 0)
            & (np.array([r['enemy_exits'] for r in rr]) <= 1),
        'calm_crate_bomb_no_enemy': calm & mask[:, 5] & (x[:, 14] == 0) & (x[:, 11] > 0),
    }
    policies = {}
    for name in MODELS:
        q = np.array([r['q'][name] for r in rr])
        best = np.isclose(q, np.where(mask, q, -np.inf).max(axis=1)[:, None]) & mask
        weights = best / best.sum(axis=1)[:, None]
        policies[name] = (q, weights)
    result = {}
    for label, selected in context.items():
        count = int(selected.sum())
        result[label] = dict(observations=count,
            actual_actions=np.bincount(action[selected], minlength=6).tolist())
        for name, (q, weights) in policies.items():
            subset = selected & mask[:, 5]
            bomb_gap = q[:, 5] - np.where(mask[:, :5], q[:, :5], -np.inf).max(axis=1)
            finite = subset & np.isfinite(bomb_gap)
            result[label][name] = dict(
                greedy_probabilities=weights[selected].mean(axis=0).tolist() if count else None,
                bomb_advantage_quantiles=np.quantile(bomb_gap[finite], [.1,.5,.9]).tolist() if finite.any() else None)
    waits = []
    run = []
    for row in rr:
        if row['action'] == 4 and not row['threatened']:
            if run and (row['round'] != run[-1]['round'] or row['step'] != run[-1]['step']+1
                        or row['position'] != run[-1]['position']):
                waits.append(run); run=[]
            run.append(row)
        elif run:
            waits.append(run); run=[]
    if run: waits.append(run)
    long = sorted((r for r in waits if len(r)>=3), key=len, reverse=True)
    examples=[]
    for run in long[:10]:
        r = run[0]
        examples.append(dict(round=r['round'], start=r['step'], length=len(run),
            position=r['position'], target=r['target'], distance=r['distance'],
            bomb_ready=r['bomb_ready'], enemy_hits=r['enemy_hits'], bombs=r['bombs'],
            q=r['q'], key=r['key'], mask=r['mask']))
    return dict(actions=len(rr), contexts=result,
        calm_wait_runs_ge3=len(long), calm_wait_steps_in_runs_ge3=sum(map(len,long)),
        longest_calm_wait=max(map(len,waits),default=0), wait_examples=examples)


def main():
    OUT.mkdir(parents=True, exist_ok=False)
    started = time.monotonic()
    def status(phase, **kwargs):
        save(OUT/'status.json', dict(phase=phase, pid=os.getpid(),
            updated_at=datetime.now(timezone.utc).isoformat(), elapsed_seconds=time.monotonic()-started, **kwargs))
        print(phase, kwargs, flush=True)
    try:
        status('preparing')
        protected = read(PREVIOUS/'config.json')['protected_sha256'].copy()
        assert all(digest(ROOT/n)==h for n,h in protected.items())
        for path in PREVIOUS.rglob('*'):
            if path.is_file() and '__pycache__' not in path.parts:
                protected[str(path.relative_to(ROOT))] = digest(path)
        sources = ['trace_tree_fqi_match.py', 'diagnose_tree_fqi_decisions.py',
                   'run_tree_fqi_match.py', 'TREE_FQI_DECISIONS_PLAN.md']
        locked = {n:digest(ROOT/n) for n in sources}
        save(OUT/'config.json', dict(stage='diagnostic_replay', seed=547003, games_per_arm=60,
            policy_seed=42, protected_sha256=protected, source_sha256=locked,
            model_sha256={a:digest(p) for a,p in MODELS.items()},
            note='Existing development maps, no new performance claim; all games including wins and losses.'))
        for arm, model in MODELS.items():
            workspace=OUT/'workspaces'/arm
            framework(workspace)
            for name in ('run_tree_fqi_match.py', 'trace_tree_fqi_match.py'):
                shutil.copy2(ROOT/name, workspace/name)
            shutil.copytree(ROOT/'agent_code/tree_fqi', workspace/'agent_code/tree_fqi',
                ignore=shutil.ignore_patterns('__pycache__','logs','model.pkl'))
            shutil.copy2(model, workspace/'agent_code/tree_fqi/model.pkl')
        def replay(arm):
            folder=OUT/'replay'/arm; folder.mkdir(parents=True)
            workspace=OUT/'workspaces'/arm
            command=[sys.executable,'-X','utf8','trace_tree_fqi_match.py',
                '--trace',str(folder/'trace.jsonl.gz'), '--pilot-model',str(MODELS['pilot']),
                '--random-model',str(MODELS['random']), '--agent','tree_fqi',
                '--model',str(workspace/'agent_code/tree_fqi/model.pkl'),
                '--output',str(folder/'strong.json'), '--rounds','60', '--seed','547003',
                '--policy-seed','42','--opponents',*(['rule_based_agent']*3)]
            with (folder/'run.log').open('w',encoding='utf-8') as log:
                subprocess.run(command,cwd=workspace,env=clean_environment(),stdout=log,
                    stderr=subprocess.STDOUT,check=True,timeout=1800)
            original=rows(PREVIOUS/'evaluation'/arm/'strong.rounds.jsonl')
            current=rows(folder/'strong.rounds.jsonl')
            assert len(original)==len(current)==60
            for a,b in zip(original,current):
                for key in ('round','map_hash','action_sha256','score','win','survived','steps'):
                    assert a[key]==b[key], (arm,a['round'],key)
            assert read(folder/'strong.latency.json')['over_500ms']==0
            analysis=analyze_trace(folder/'trace.jsonl.gz')
            assert analysis['actions']==sum(r['agents']['tree_fqi']['steps'] for r in current)
            save(folder/'analysis.json',analysis)
            return analysis
        status('replaying',games=120)
        analyses={}
        with ThreadPoolExecutor(max_workers=2) as pool:
            tasks={pool.submit(replay,a):a for a in MODELS}
            for task in as_completed(tasks):
                arm=tasks[task]; analyses[arm]=task.result()
                status('replaying',completed=list(analyses))
        save(OUT/'diagnosis.json',analyses)
        assert all(digest(ROOT/n)==h for n,h in protected.items())
        assert all(digest(ROOT/n)==h for n,h in locked.items())
        save(OUT/'verification.json',dict(verified=True,action_hashes_identical_games=120,
            protected_unchanged=True,protected_files=len(protected),sources_unchanged=True))
        status('diagnosis_complete',verified=True)
    except Exception as e:
        status('failed',error=repr(e)); raise


if __name__=='__main__':
    main()
