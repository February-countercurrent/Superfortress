"""Frozen three-seed linear Q checkpoints, paired dynamic-filter evaluation."""
import hashlib
import json
from pathlib import Path
import shutil
import sys
import numpy as np
import run_fighter_experiment as runner

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'experiments/dynamic_v1'
SEEDS = [27001, 28001, 29001]


def analyze(rounds=60):
    summary = json.loads((OUT / 'summary.json').read_text())
    result = {}
    rng = np.random.default_rng(47004)
    for scenario in ['mixed', 'strong']:
        deltas = {k: [] for k in ['win', 'score', 'survived', 'suicides']}
        per_seed = []
        for seed in SEEDS:
            folder = OUT / f'seed_{seed}'
            rows = {name: [json.loads(line) for line in (folder / f'{name}_{scenario}.rounds.jsonl').read_text().splitlines()]
                    for name in ['q_linear', 'q_dynamic']}
            assert all(len(r) == rounds for r in rows.values())
            maps = [r['map_hash'] for r in rows['q_linear']]
            assert maps == [r['map_hash'] for r in rows['q_dynamic']]
            if per_seed:
                assert maps == previous_maps
            previous_maps = maps
            entry = dict(seed=seed)
            for metric in deltas:
                def value(row, agent):
                    return row['agents'][agent].get('suicides', 0) if metric == 'suicides' else row[metric]
                d = [float(value(a, 'q_dynamic')) - float(value(b, 'q_linear'))
                     for a, b in zip(rows['q_dynamic'], rows['q_linear'])]
                deltas[metric].append(d)
                entry[metric] = float(np.mean(d))
            per_seed.append(entry)
        seed_ix = rng.integers(0, 3, (10000, 3))
        map_ix = rng.integers(0, rounds, (10000, rounds))
        diff = {}
        for metric, d in deltas.items():
            a = np.array(d)
            boot = a[seed_ix[:, :, None], map_ix[:, None, :]].mean(axis=(1, 2))
            diff[metric] = dict(mean=float(a.mean()), exploratory_95ci=np.percentile(boot, [2.5, 97.5]).tolist())
        means = {agent: {metric: float(np.mean([summary[f'seed_{seed}/{agent}_{scenario}'][metric] for seed in SEEDS]))
                        for metric in ['strict_win_rate', 'mean_score', 'suicide_rate', 'survival_rate', 'mean_action_ms']}
                 for agent in ['q_linear', 'q_dynamic']}
        result[scenario] = dict(means=means, differences=diff, per_seed=per_seed)
    result['limitations'] = f'Three frozen training seeds, shared {rounds} maps per scenario. Exploratory two-way bootstrap. No automatic promotion.'
    (OUT / 'analysis.json').write_text(json.dumps(result, indent=2))
    return result


def main():
    OUT.mkdir(parents=True, exist_ok=False)
    workspace = OUT / 'workspace'
    shutil.copytree(ROOT, workspace, ignore=shutil.ignore_patterns('.git', 'experiments', 'release', 'logs', '__pycache__'))
    (workspace / 'logs').mkdir(exist_ok=True)
    runner.ROOT = workspace
    hashes = {}
    for seed in SEEDS:
        folder = OUT / f'seed_{seed}'
        folder.mkdir()
        model = folder / 'model.json'
        shutil.copy2(ROOT / f'experiments/linear_multiseed_v1/seed_{seed}/linear.json', model)
        hashes[str(seed)] = hashlib.sha256(model.read_bytes()).hexdigest()
    (OUT / 'config.json').write_text(json.dumps(dict(training=False, seeds=SEEDS, rounds=60,
        evaluation_seeds=[47002, 47003], sha256=hashes, python=sys.version, numpy=np.__version__,
        filter='One nearby opponent at a time, radius 6, one legal move then stationary. Collision modeled as staying. Filter while threatened or for BOMB; fallback to original safe set if none robust.',
        limitations='Does not model simultaneous opponent moves, future moves, or new enemy bombs; no safety guarantee. No learned feature or weight changes.'), indent=2))
    results = {}
    try:
        for seed in SEEDS:
            folder = OUT / f'seed_{seed}'
            model = folder / 'model.json'
            for scenario, opponents, eval_seed in [
                ('mixed', ['rule_based_agent', 'coin_collector_agent', 'peaceful_agent'], 47002),
                ('strong', ['rule_based_agent'] * 3, 47003)]:
                for agent in ['q_linear', 'q_dynamic']:
                    label = f'{agent}_{scenario}'
                    key = f'{folder.name}/{label}'
                    (OUT / 'status.json').write_text(json.dumps(dict(phase=key)))
                    results[key] = runner.run(folder, label, model, opponents, 60, eval_seed, agent=agent)
                    assert hashlib.sha256(model.read_bytes()).hexdigest() == hashes[str(seed)]
                    (OUT / 'summary.json').write_text(json.dumps(results, indent=2))
        (OUT / 'status.json').write_text(json.dumps(dict(phase='analyzing')))
        analyze()
        (OUT / 'status.json').write_text(json.dumps(dict(phase='complete')))
    except Exception as exc:
        (OUT / 'status.json').write_text(json.dumps(dict(phase='failed', error=repr(exc))))
        raise


if __name__ == '__main__':
    main()
