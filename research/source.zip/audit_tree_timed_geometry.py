"""Compare optimized descriptors to the independent per-enemy diagnostic."""
import gzip
import json
from pathlib import Path
import time
import numpy as np
from analyze_tree_attack import restore,enemy_escape
from agent_code.tree_timed.timed import descriptors
from agent_code.tree_timed.features import DELTAS,blast
from agent_code.tree_timed.model import transform_keys
from agent_code.tree_timed.timed import timed_key
from agent_code.tree_timed.symmetry_maps import PERMUTATIONS
from test_tree_tactical import transformed_state
from experiment_tree_fqi_batches import save
from finalize_guard_release import digest

ROOT=Path(__file__).resolve().parent


def reference(state):
    pos=state['self'][3];occupied={p for p,_ in state['bombs']}|{o[3] for o in state['others']}
    codes=[];distances=[]
    for i,p in enumerate([pos]+[(pos[0]+dx,pos[1]+dy) for dx,dy in DELTAS]):
        s=dict(state,self=(*state['self'][:3],p))
        targets=[o for o in state['others'] if o[3] in blast(state['field'],p)]
        descriptions=[enemy_escape(s,o) for o in targets]
        if i==0:distances=[5 if e['static_steps_off_ray']<0 else min(e['static_steps_off_ray'],4) for e in descriptions]
        if state['field'][p]!=0 or p in occupied:code=5
        elif not descriptions:code=0
        elif any(d['viable_first_actions']==0<d['viable_first_actions_without_bomb'] for d in descriptions):code=2
        elif any(0<d['viable_first_actions']<d['viable_first_actions_without_bomb'] for d in descriptions):code=3
        elif any(d['viable_first_actions_without_bomb']==0 for d in descriptions):code=1
        else:code=4
        codes.append(code)
    return codes+[max(distances,default=0)]


def main():
    source=ROOT/'experiments/tree_attack_diagnosis_v1/replay/batch_1_teacher/trace.jsonl.gz'
    count=0;timing=[]
    with gzip.open(source,'rt',encoding='utf-8') as f:
        for index,line in enumerate(f):
            if index%257:continue
            r=json.loads(line)
            if r['decision'] is None:continue
            s=restore(r['decision']['state']);tick=time.perf_counter()
            expected=descriptors(s);timing.append(1000*(time.perf_counter()-tick))
            np.testing.assert_array_equal(expected,reference(s))
            key=timed_key(s)
            if count<16:
                for p in PERMUTATIONS:
                    np.testing.assert_array_equal(timed_key(transformed_state(s,p)),transform_keys([key],p)[0])
            count+=1
            if count==80:break
    assert count==80
    result=dict(verified=True,states=80,full_d4_states=16,source_sha256=digest(source),
        script_sha256=digest(Path(__file__)),feature_ms_mean=float(np.mean(timing)),
        feature_ms_max=float(max(timing)),note='Existing diagnostic states used only for arithmetic invariants, not fitting or selecting settings.')
    save(ROOT/'experiments/tree_timed_v1/geometry_audit.json',result)
    print(result)


if __name__=='__main__':main()
